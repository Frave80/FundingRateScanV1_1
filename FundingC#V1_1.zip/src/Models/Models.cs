using System.Text.Json.Serialization;
// rev: fusione Colab + gemme PRO

namespace FundingRateScan.Models;

/// <summary>
/// Configurazione API per un singolo exchange. Le chiavi sono opzionali:
/// quasi tutti gli endpoint di market data (funding, volumi, open interest)
/// sono pubblici. Le chiavi servono solo per limiti di rate piu' alti.
/// </summary>
public class ExchangeApiConfig
{
    public string Name { get; set; } = "";
    public bool Enabled { get; set; } = true;
    public string ApiKey { get; set; } = "";
    public string ApiSecret { get; set; } = "";
    public string Passphrase { get; set; } = "";
}

/// <summary>
/// Impostazioni complete dell'applicazione, persistite su disco in JSON.
/// </summary>
public class AppSettings
{
    public List<ExchangeApiConfig> Exchanges { get; set; } = new();
    public ScanParameters LastParameters { get; set; } = new();
    public OnChain.Models.OnChainSettings OnChain { get; set; } = new();
    public Gems.GemHunterSettings GemHunter { get; set; } = new();
    public Meme.MemeScoringSettings MemeScoring { get; set; } = new();
}

/// <summary>
/// Parametri scelti dall'utente nella finestra di scaricamento.
/// </summary>
public class ScanParameters
{
    /// <summary>Soglia minima di funding APR (annualizzato, %) per considerare una coin "affollata long".</summary>
    public double FundingAprThreshold { get; set; } = 10.0;

    /// <summary>Percentuale minima di periodi con funding positivo (longs che pagano) nello storico.</summary>
    public double MinPersistencePct { get; set; } = 60.0;

    /// <summary>Giorni di storico da analizzare per persistenza, volumi e open interest.</summary>
    public int LookbackDays { get; set; } = 30;

    /// <summary>Numero massimo di coin candidate da arricchire con dati storici.</summary>
    public int TopN { get; set; } = 150;

    /// <summary>Crescita minima del volume (% tra prima e seconda meta' del periodo) per il pattern attivo.</summary>
    public double VolGrowthMinPct { get; set; } = 5.0;

    /// <summary>Crescita minima dell'open interest (% tra prima e seconda meta' del periodo) per il pattern attivo.</summary>
    public double OiGrowthMinPct { get; set; } = 5.0;

    /// <summary>Volume minimo 24h in USD per filtrare coin illiquide.</summary>
    public double MinVolumeUsd { get; set; } = 1_000_000;
}

/// <summary>Punto temporale generico (timestamp + valore).</summary>
public struct TrendPoint
{
    public DateTime Time;
    public double Value;
    public TrendPoint(DateTime t, double v) { Time = t; Value = v; }
}

/// <summary>
/// Dati di mercato grezzi di un singolo contratto perpetuo su un exchange.
/// </summary>
public class CoinMarket
{
    public string Exchange { get; set; } = "";
    public string Symbol { get; set; } = "";   // simbolo nativo dell'exchange (es. BTCUSDT)
    public string Base { get; set; } = "";      // asset base normalizzato (es. BTC)

    /// <summary>Funding rate corrente (frazione per intervallo, es. 0.0001 = 0.01%).</summary>
    public double FundingRate { get; set; }

    /// <summary>Durata in ore di un intervallo di funding (8 per la maggior parte dei CEX, 1 per Hyperliquid).</summary>
    public double FundingIntervalHours { get; set; } = 8.0;

    public double Volume24hUsd { get; set; }
    public double OpenInterestUsd { get; set; }
    public double LastPrice { get; set; }

    // Storico (riempito solo per le candidate, durante l'arricchimento)
    public List<TrendPoint> FundingHistory { get; set; } = new();
    public List<TrendPoint> OiHistory { get; set; } = new();
    public List<TrendPoint> VolumeHistory { get; set; } = new();

    /// <summary>Funding annualizzato in percentuale.</summary>
    public double FundingApr => FundingRate * (24.0 / FundingIntervalHours) * 365.0 * 100.0;
}

/// <summary>Classificazione assegnata a una coin in base ai pattern.</summary>
public enum Classification
{
    Neutral,      // sotto soglia
    Watch,        // funding persistente ma volumi/OI non ancora confermati
    PatternActive // funding persistente + volumi crescenti + open interest crescente
}

/// <summary>
/// Risultato aggregato per asset base, mostrato in tabella.
/// </summary>
public class CoinResult
{
    public string Base { get; set; } = "";
    public string Name { get; set; } = "";               // nome completo (es. Bitcoin), da CoinGecko
    public string Exchanges { get; set; } = "";          // elenco exchange che quotano la coin
    public string RepresentativeExchange { get; set; } = "";
    public string RepresentativeSymbol { get; set; } = "";

    public double FundingApr { get; set; }
    public double FundingRateRaw { get; set; }
    public double Volume24hUsd { get; set; }
    public double OpenInterestUsd { get; set; }
    public double LastPrice { get; set; }

    // Metriche derivate dallo storico
    public double PersistencePct { get; set; }   // % periodi con funding positivo
    public double VolGrowthPct { get; set; }      // crescita volume (prima vs seconda meta')
    public double OiGrowthPct { get; set; }       // crescita open interest
    public int FundingSamples { get; set; }
    public bool Enriched { get; set; }

    // M3 — % di periodi dello storico con funding annualizzato sopra la soglia "estrema":
    // misura la PERSISTENZA dell'estremo (leva pericolosa strutturale, non episodica),
    // coerente col predittore di crash basato sul funding cumulato.
    public double ExtremeFundingPersistencePct { get; set; }

    // M6 — affidabilità del dato di open interest: true quando i valori di OI dei vari
    // exchange divergono molto (possibile misreporting), così il segnale va letto con cautela.
    public bool OiLowReliability { get; set; }

    public Classification Classification { get; set; } = Classification.Neutral;

    // ---- Fusione con la selezione Python (Colab) -------------------------
    /// <summary>Origine della coin: "Nativo", "Colab" o "Entrambi".</summary>
    public string Source { get; set; } = "Nativo";

    /// <summary>Status assegnato dalla pipeline Colab (OPPORTUNITÀ, ESPLOSA, POMPATA, DELUSA, WATCH, STABILE).</summary>
    public string ColabStatus { get; set; } = "";

    /// <summary>APR medio sull'intero periodo Colab (%). Null se la coin non è stata selezionata dal Colab.</summary>
    public double? ColabAprMedio { get; set; }

    /// <summary>APR medio ultimi 30 giorni dalla pipeline Colab (%).</summary>
    public double? ColabApr30 { get; set; }

    /// <summary>Riferimento al mercato usato per l'arricchimento storico.</summary>
    [JsonIgnore]
    public CoinMarket? Representative { get; set; }
}
