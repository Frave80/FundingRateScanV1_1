using FundingRateScan.Models;

namespace FundingRateScan.Services;

/// <summary>Punteggio accademico di una coin con scomposizione per fattore.</summary>
public sealed class AcademicScore
{
    public CoinResult Coin { get; set; } = null!;
    public double Composite { get; set; }     // combinazione z-score grezza
    public double Score0to100 { get; set; }   // rank percentile nel set (0..100)

    public double ZFunding { get; set; }
    public double ZPersistence { get; set; }
    public double ZOi { get; set; }
    public double ZVolume { get; set; }
    public double ZLiquidity { get; set; }

    public string Rationale { get; set; } = "";
}

/// <summary>
/// Selezione delle coin più promettenti con criteri accademici: modello fattoriale
/// cross-sezionale. Ogni fattore viene standardizzato (z-score) sull'universo delle
/// candidate e combinato con pesi derivati dalla letteratura sui perpetual futures:
///  - Carry (funding APR): pressione/affollamento dei long;
///  - Persistenza: stabilità/auto-correlazione del segnale di funding;
///  - Momentum di Open Interest: partecipazione crescente (conferma del trend);
///  - Momentum di Volume: conferma di liquidità reale dietro il movimento;
///  - Liquidità (log volume 24h): filtro qualità che penalizza il rumore delle micro-cap.
/// Il punteggio finale è il rank percentile del composito: robusto e confrontabile.
/// </summary>
public static class AcademicScorer
{
    // Pesi del modello (priori accademici: carry e persistenza primari)
    private const double WFunding = 0.30;
    private const double WPersistence = 0.25;
    private const double WOi = 0.20;
    private const double WVolume = 0.15;
    private const double WLiquidity = 0.10;

    public static List<AcademicScore> Rank(IEnumerable<CoinResult> coins)
    {
        var list = coins.ToList();
        if (list.Count == 0) return new List<AcademicScore>();

        var funding = list.Select(c => c.FundingApr).ToArray();
        var persist = list.Select(c => c.PersistencePct).ToArray();
        var oi = list.Select(c => c.OiGrowthPct).ToArray();
        var vol = list.Select(c => c.VolGrowthPct).ToArray();
        var liq = list.Select(c => Math.Log10(Math.Max(1.0, c.Volume24hUsd))).ToArray();

        var (mF, sF) = MeanStd(funding);
        var (mP, sP) = MeanStd(persist);
        var (mO, sO) = MeanStd(oi);
        var (mV, sV) = MeanStd(vol);
        var (mL, sL) = MeanStd(liq);

        var scored = new List<AcademicScore>();
        for (int i = 0; i < list.Count; i++)
        {
            var s = new AcademicScore
            {
                Coin = list[i],
                ZFunding = Z(funding[i], mF, sF),
                ZPersistence = Z(persist[i], mP, sP),
                ZOi = Z(oi[i], mO, sO),
                ZVolume = Z(vol[i], mV, sV),
                ZLiquidity = Z(liq[i], mL, sL),
            };
            s.Composite = WFunding * s.ZFunding + WPersistence * s.ZPersistence
                        + WOi * s.ZOi + WVolume * s.ZVolume + WLiquidity * s.ZLiquidity;
            s.Rationale = BuildRationale(s);
            scored.Add(s);
        }

        // Rank percentile sul composito (0..100)
        var ordered = scored.OrderBy(s => s.Composite).ToList();
        int n = ordered.Count;
        for (int rank = 0; rank < n; rank++)
            ordered[rank].Score0to100 = n == 1 ? 100.0 : Math.Round(rank / (double)(n - 1) * 100.0, 1);

        return scored.OrderByDescending(s => s.Composite).ToList();
    }

    private static string BuildRationale(AcademicScore s)
    {
        var factors = new (string name, double z)[]
        {
            ("carry funding", s.ZFunding),
            ("persistenza", s.ZPersistence),
            ("momentum OI", s.ZOi),
            ("momentum volume", s.ZVolume),
            ("liquidità", s.ZLiquidity),
        };
        var top = factors.Where(f => f.z > 0).OrderByDescending(f => f.z).Take(3).ToList();
        if (top.Count == 0) return "Tutti i fattori sotto la media del gruppo.";
        return "Punti di forza: " + string.Join(", ", top.Select(f => $"{f.name} (z={f.z:+0.0;-0.0})"));
    }

    private static (double mean, double std) MeanStd(double[] x)
    {
        if (x.Length == 0) return (0, 0);
        double mean = x.Average();
        if (x.Length < 2) return (mean, 0);
        double var = x.Sum(v => (v - mean) * (v - mean)) / (x.Length - 1);
        return (mean, Math.Sqrt(var));
    }

    private static double Z(double x, double mean, double std)
        => std > 1e-9 ? (x - mean) / std : 0.0;
}
