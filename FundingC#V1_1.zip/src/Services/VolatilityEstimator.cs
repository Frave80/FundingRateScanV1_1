using FundingRateScan.Models;

namespace FundingRateScan.Services;

/// <summary>Esito della stima di volatilità per una coin.</summary>
public sealed class VolatilityEstimate
{
    /// <summary>Probabilità (%) di almeno un episodio di alta volatilità entro 30/60/120 giorni.</summary>
    public double P30 { get; set; }
    public double P60 { get; set; }
    public double P120 { get; set; }

    /// <summary>Rischio giornaliero stimato (%/giorno) di un episodio di alta volatilità.</summary>
    public double DailyHazardPct { get; set; }

    /// <summary>Punteggio composito (z) usato per la stima.</summary>
    public double Score { get; set; }

    /// <summary>Motivazioni (contributi positivi/negativi al punteggio).</summary>
    public List<string> Reasons { get; } = new();

    public static string Label(double p) => p switch
    {
        >= 70 => "Molto alta",
        >= 50 => "Alta",
        >= 30 => "Media",
        >= 15 => "Moderata",
        _ => "Bassa"
    };
}

/// <summary>
/// Stima euristica della probabilità di "alta volatilità" (movimento brusco /
/// squeeze, ben oltre l'oscillazione tipica) su orizzonti di 30, 60 e 120 giorni.
///
/// Modello: punteggio composito dai segnali disponibili (funding APR, persistenza,
/// crescita open interest e volume, metriche storiche Colab) → rischio giornaliero
/// (hazard) tramite sigmoide → probabilità cumulata P(T) = 1 − (1 − h)^T.
///
/// NOTA: è una stima probabilistica/euristica a scopo di ricerca, non una
/// previsione né un consiglio finanziario.
/// </summary>
public static class VolatilityEstimator
{
    // Hazard giornaliero minimo/massimo (frazione/giorno).
    private const double HazardMin = 0.002;   // ~0.2%/giorno: coin "tranquilla"
    private const double HazardMax = 0.030;   // ~3.0%/giorno: leva molto affollata

    public static VolatilityEstimate Estimate(CoinResult r)
    {
        var e = new VolatilityEstimate();

        // ---- Contributi normalizzati -------------------------------------
        // Funding APR: 0% → 0, 100% APR → 1 (saturazione a 1.5).
        double funding = Math.Clamp(Math.Max(r.FundingApr, r.ColabApr30 ?? 0) / 100.0, 0, 1.5);

        // Persistenza del funding positivo (0..1). Se non disponibile (solo Colab), neutra 0.5.
        double persistence = r.Enriched ? Math.Clamp(r.PersistencePct / 100.0, 0, 1) : 0.5;

        // Crescita open interest: accumulo di leva. +50% → 1 (clamp −1..1.5).
        double oi = r.Enriched ? Math.Clamp(r.OiGrowthPct / 50.0, -1, 1.5) : 0;

        // Crescita volume: interesse in aumento. +50% → 1 (clamp −1..1.5).
        double vol = r.Enriched ? Math.Clamp(r.VolGrowthPct / 50.0, -1, 1.5) : 0;

        // Storico Colab: APR medio alto e a lungo = pressione strutturale.
        double colab = 0;
        if (r.ColabAprMedio.HasValue) colab += Math.Clamp(r.ColabAprMedio.Value / 60.0, 0, 1) * 0.6;
        colab += r.ColabStatus switch
        {
            "OPPORTUNITÀ" => 0.40,   // funding alto recente senza reazione prezzo → molla carica
            "WATCH" => 0.25,
            "POMPATA" => 0.15,
            "ESPLOSA" => 0.10,   // gran parte del movimento già avvenuto
            "STABILE" => 0.10,
            "DELUSA" => 0.05,
            _ => 0
        };

        // ---- Punteggio composito → hazard ---------------------------------
        double z = -2.2
                   + 2.2 * funding
                   + 1.3 * persistence
                   + 1.1 * oi
                   + 0.7 * vol
                   + 0.8 * colab;

        double sig = 1.0 / (1.0 + Math.Exp(-z));
        double h = HazardMin + (HazardMax - HazardMin) * sig;

        e.Score = Math.Round(z, 2);
        e.DailyHazardPct = Math.Round(h * 100.0, 2);
        e.P30 = Cum(h, 30);
        e.P60 = Cum(h, 60);
        e.P120 = Cum(h, 120);

        // ---- Motivazioni ---------------------------------------------------
        if (funding >= 0.5) e.Reasons.Add($"Funding APR elevato ({Math.Max(r.FundingApr, r.ColabApr30 ?? 0):N1}%): long molto affollati → rischio squeeze.");
        else if (funding >= 0.15) e.Reasons.Add($"Funding APR moderato ({Math.Max(r.FundingApr, r.ColabApr30 ?? 0):N1}%): pressione long presente.");
        else e.Reasons.Add("Funding APR contenuto: pressione di leva limitata.");

        if (r.Enriched)
        {
            if (persistence >= 0.8) e.Reasons.Add($"Persistenza {r.PersistencePct:N0}%: i long pagano da molto tempo (pressione strutturale).");
            else if (persistence >= 0.6) e.Reasons.Add($"Persistenza {r.PersistencePct:N0}%: funding positivo nella maggioranza dei periodi.");
            if (oi >= 0.3) e.Reasons.Add($"Open interest in crescita ({r.OiGrowthPct:+0.0;-0.0}%): accumulo di leva → movimenti bruschi più probabili.");
            else if (oi <= -0.3) e.Reasons.Add($"Open interest in calo ({r.OiGrowthPct:+0.0;-0.0}%): la leva si sta scaricando.");
            if (vol >= 0.3) e.Reasons.Add($"Volume in crescita ({r.VolGrowthPct:+0.0;-0.0}%): interesse in aumento.");
        }
        else
            e.Reasons.Add("Coin selezionata solo dalla pipeline Colab: persistenza/Δvolumi/ΔOI nativi non disponibili (assunti neutri).");

        if (r.ColabStatus == "OPPORTUNITÀ")
            e.Reasons.Add("Status Colab OPPORTUNITÀ: funding alto recente senza reazione del prezzo → tensione accumulata.");
        else if (!string.IsNullOrEmpty(r.ColabStatus))
            e.Reasons.Add($"Status Colab {r.ColabStatus} (APR medio storico {r.ColabAprMedio ?? 0:N1}%).");

        return e;
    }

    /// <summary>P(almeno un evento entro T giorni) = 1 − (1 − h)^T, in %.</summary>
    private static double Cum(double h, int days) =>
        Math.Round((1.0 - Math.Pow(1.0 - h, days)) * 100.0, 1);
}
