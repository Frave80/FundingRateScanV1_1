using FundingRateScan.Models;
using FundingRateScan.Services.Exchanges;

namespace FundingRateScan.Services;

/// <summary>
/// Orchestratore della scansione:
/// 1) scarica i dati correnti da tutti gli exchange abilitati;
/// 2) aggrega per asset base;
/// 3) filtra le coin con funding APR sopra soglia (affollamento long);
/// 4) arricchisce le candidate con lo storico (funding, volumi, open interest);
/// 5) calcola i trend e classifica.
/// </summary>
public class ScanService
{
    private readonly List<IExchangeClient> _clients;

    public ScanService(IEnumerable<ExchangeApiConfig> enabledConfigs)
    {
        _clients = new List<IExchangeClient>();
        foreach (var cfg in enabledConfigs.Where(c => c.Enabled))
        {
            var client = CreateClient(cfg.Name);
            if (client != null) _clients.Add(client);
        }
    }

    /// <summary>Factory di un client exchange dal nome (usato anche dal dettaglio coin).</summary>
    public static IExchangeClient? CreateClient(string name) => name switch
    {
        "Binance" => new BinanceClient(),
        "Bybit" => new BybitClient(),
        "OKX" => new OkxClient(),
        "Bitget" => new BitgetClient(),
        "Gate.io" => new GateioClient(),
        "HTX" => new HtxClient(),
        "Hyperliquid" => new HyperliquidClient(),
        _ => null
    };

    public IReadOnlyList<string> EnabledExchanges => _clients.Select(c => c.Name).ToList();

    public async Task<List<CoinResult>> RunAsync(ScanParameters p, IProgress<string> log, CancellationToken ct)
    {
        // Carica in parallelo la mappa simbolo → nome completo (CoinGecko).
        var namesTask = CoinNameProvider.EnsureLoadedAsync(log, ct);

        // --- Fase 1: download dati correnti in parallelo ---------------------
        log.Report($"Avvio scansione su {_clients.Count} exchange...");
        var allMarkets = new List<CoinMarket>();
        var fetchTasks = _clients.Select(async c =>
        {
            try
            {
                var markets = await c.FetchMarketsAsync(ct);
                log.Report($"  [{c.Name}] {markets.Count} contratti perpetui");
                return markets;
            }
            catch (OperationCanceledException) when (ct.IsCancellationRequested) { throw; }
            catch (Exception ex)
            {
                log.Report($"  [{c.Name}] errore: {ex.Message}");
                return (IReadOnlyList<CoinMarket>)Array.Empty<CoinMarket>();
            }
        });
        foreach (var batch in await Task.WhenAll(fetchTasks))
            allMarkets.AddRange(batch);

        log.Report($"Totale contratti raccolti: {allMarkets.Count}");
        if (allMarkets.Count == 0)
        {
            log.Report("Nessun dato ricevuto. Controlla connessione / eventuali geo-blocchi.");
            return new List<CoinResult>();
        }

        // --- Fase 2: aggregazione per asset base -----------------------------
        var results = new List<CoinResult>();
        foreach (var grp in allMarkets.GroupBy(m => m.Base))
        {
            var members = grp.ToList();
            // Rappresentante = exchange con volume maggiore (storico piu' affidabile)
            var rep = members.OrderByDescending(m => m.Volume24hUsd).First();

            // M6 — Open interest robusto: la somma ingenua fra venue eterogenei è esposta al
            // misreporting dell'OI da parte di alcuni exchange. Si usa quindi l'OI del
            // rappresentante (venue a volume maggiore, piu' affidabile); se manca, si ripiega
            // sulla somma. Si segnala bassa affidabilita' quando i valori divergono molto
            // (il massimo supera 3× la mediana dei venue con OI > 0).
            var oiVals = members.Select(m => m.OpenInterestUsd).Where(v => v > 0).OrderBy(v => v).ToList();
            double oiRobust = rep.OpenInterestUsd > 0 ? rep.OpenInterestUsd : members.Sum(m => m.OpenInterestUsd);
            bool oiLowRel = false;
            if (oiVals.Count >= 2)
            {
                double median = oiVals[oiVals.Count / 2];
                if (median > 0 && oiVals[^1] > 3.0 * median) oiLowRel = true;
            }

            results.Add(new CoinResult
            {
                Base = grp.Key,
                Exchanges = string.Join(", ", members.Select(m => m.Exchange).Distinct()),
                RepresentativeExchange = rep.Exchange,
                RepresentativeSymbol = rep.Symbol,
                FundingApr = members.Average(m => m.FundingApr),
                FundingRateRaw = rep.FundingRate,
                Volume24hUsd = members.Sum(m => m.Volume24hUsd),
                OpenInterestUsd = oiRobust,
                OiLowReliability = oiLowRel,
                LastPrice = rep.LastPrice,
                Representative = rep,
            });
        }

        // Assegna i nomi completi (attende il caricamento CoinGecko se non pronto).
        try { await namesTask; } catch { /* best-effort */ }
        foreach (var r in results)
            r.Name = CoinNameProvider.GetName(r.Base);

        // --- Fase 3: filtro candidate (affollamento long) --------------------
        var candidates = results
            .Where(r => r.FundingApr >= p.FundingAprThreshold && r.Volume24hUsd >= p.MinVolumeUsd)
            .OrderByDescending(r => r.FundingApr)
            .Take(p.TopN)
            .ToList();

        log.Report($"Coin sopra soglia funding ({p.FundingAprThreshold:0.#}% APR) e volume minimo: {candidates.Count}");

        // --- Fase 4: arricchimento storico delle candidate -------------------
        int done = 0;
        using var sem = new SemaphoreSlim(6); // limita le richieste concorrenti
        var enrichTasks = candidates.Select(async r =>
        {
            await sem.WaitAsync(ct);
            try
            {
                var client = _clients.FirstOrDefault(c => c.Name == r.RepresentativeExchange);
                if (client != null && r.Representative != null)
                    await client.EnrichHistoryAsync(r.Representative, p.LookbackDays, ct);
                ComputeMetrics(r, p);
            }
            catch (OperationCanceledException) when (ct.IsCancellationRequested) { throw; }
            catch { /* coin singola fallita: la lasciamo senza arricchimento */ }
            finally
            {
                sem.Release();
                int n = System.Threading.Interlocked.Increment(ref done);
                if (n % 10 == 0 || n == candidates.Count)
                    log.Report($"  Arricchimento storico {n}/{candidates.Count}...");
            }
        });
        await Task.WhenAll(enrichTasks);

        // --- Fase 5: classificazione finale ----------------------------------
        foreach (var r in candidates)
            Classify(r, p);

        var patternActive = candidates.Count(r => r.Classification == Classification.PatternActive);
        var watch = candidates.Count(r => r.Classification == Classification.Watch);
        log.Report($"Risultati: {patternActive} con pattern attivo, {watch} da osservare.");

        return candidates
            .OrderByDescending(r => r.Classification)
            .ThenByDescending(r => r.FundingApr)
            .ToList();
    }

    /// <summary>Calcola persistenza, crescita volume e crescita OI dallo storico.</summary>
    private static void ComputeMetrics(CoinResult r, ScanParameters p)
    {
        var m = r.Representative;
        if (m == null) return;

        var cutoff = DateTime.UtcNow.AddDays(-p.LookbackDays);

        var fundings = m.FundingHistory.Where(t => t.Time >= cutoff).Select(t => t.Value).ToList();
        if (fundings.Count == 0) fundings = m.FundingHistory.Select(t => t.Value).ToList();
        r.FundingSamples = fundings.Count;
        if (fundings.Count > 0)
            r.PersistencePct = 100.0 * fundings.Count(v => v > 0) / fundings.Count;

        r.VolGrowthPct = HalfOverHalfGrowth(m.VolumeHistory, cutoff);
        r.OiGrowthPct = HalfOverHalfGrowth(m.OiHistory, cutoff);

        // BUG-CORE-005 — cadenza di funding: invece di assumere un intervallo fisso (8h),
        // si deriva la cadenza reale dai timestamp dello storico. Alcune coin liquidano ogni
        // 4h o 1h: con un fattore fisso il loro APR risulterebbe incomparabile con le altre.
        // Il rappresentante (exchange a volume maggiore) guida il valore mostrato, coerentemente
        // con prezzo e funding grezzo della riga, anch'essi basati sul rappresentante.
        var hours = MedianGapHours(m.FundingHistory);
        if (hours is > 0.4 and < 24.5)
        {
            m.FundingIntervalHours = hours.Value;
            r.FundingApr = m.FundingApr;     // APR ricalcolato con la cadenza corretta
            r.FundingRateRaw = m.FundingRate;
        }

        // M3 — persistenza dell'estremo: quota di periodi il cui funding ANNUALIZZATO supera la
        // soglia "estrema". Distingue una leva pericolosa strutturale (estremo ricorrente) da un
        // picco episodico, coerente col predittore di crash basato sul funding cumulato.
        if (fundings.Count > 0)
        {
            double annFactor = (24.0 / m.FundingIntervalHours) * 365.0 * 100.0;
            r.ExtremeFundingPersistencePct =
                100.0 * fundings.Count(v => v * annFactor >= CoinVerdictEvaluator.ExtremeFundingApr) / fundings.Count;
        }

        if (m.OpenInterestUsd > 0) r.OpenInterestUsd = Math.Max(r.OpenInterestUsd, m.OpenInterestUsd);
        r.Enriched = true;
    }

    /// <summary>Mediana dell'intervallo (in ore) fra timestamp consecutivi dello storico funding; null se insufficiente.</summary>
    private static double? MedianGapHours(List<TrendPoint> history)
    {
        if (history.Count < 3) return null;
        var ts = history.OrderBy(t => t.Time).Select(t => t.Time).ToList();
        var gaps = new List<double>();
        for (int i = 1; i < ts.Count; i++)
        {
            double g = (ts[i] - ts[i - 1]).TotalHours;
            if (g > 0) gaps.Add(g);
        }
        if (gaps.Count == 0) return null;
        gaps.Sort();
        return gaps[gaps.Count / 2];
    }

    /// <summary>
    /// Variazione % tra la media della prima meta' e quella della seconda meta'
    /// della serie temporale. Positivo = trend crescente.
    /// </summary>
    private static double HalfOverHalfGrowth(List<TrendPoint> series, DateTime cutoff)
    {
        var s = series.Where(t => t.Time >= cutoff).OrderBy(t => t.Time).Select(t => t.Value).ToList();
        if (s.Count < 4) s = series.OrderBy(t => t.Time).Select(t => t.Value).ToList();
        if (s.Count < 4) return 0;

        int half = s.Count / 2;
        double first = s.Take(half).Average();
        double second = s.Skip(half).Average();
        if (first <= 0) return 0;
        return (second - first) / first * 100.0;
    }

    /// <summary>
    /// Classificazione pura: puo' essere richiamata quando l'utente sposta gli
    /// indicatori regolabili, senza riscaricare i dati.
    /// </summary>
    public static void Classify(CoinResult r, ScanParameters p)
    {
        bool fundingPressure = r.FundingApr >= p.FundingAprThreshold
                               && r.PersistencePct >= p.MinPersistencePct;

        if (!fundingPressure)
        {
            r.Classification = Classification.Neutral;
            return;
        }

        // M2 — Il verdetto prevale: una coin in "Trappola" (funding estremo → rischio
        // reversal / liquidazione a cascata) NON deve risultare nella classe positiva
        // "Pattern attivo". Viene retrocessa a "Da osservare".
        if (CoinVerdictEvaluator.Evaluate(r, p).Verdict == CoinVerdict.Trappola)
        {
            r.Classification = Classification.Watch;
            return;
        }

        // M1/M9 — La conferma "sana" del pattern è il VOLUME (partecipazione reale).
        // L'open interest in crescita NON è una conferma direzionale: in cripto l'OI
        // aggregato segnala ampiezza/concentrazione di posizioni, non la direzione.
        // Quindi non è più un requisito del pattern; confluisce nel rischio/volatilità
        // attesa (Verdetto / VolatilityEstimator).
        bool volUp = r.VolGrowthPct >= p.VolGrowthMinPct;
        r.Classification = volUp ? Classification.PatternActive : Classification.Watch;
    }
}
