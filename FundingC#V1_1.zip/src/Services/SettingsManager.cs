using System.Text.Json;
using FundingRateScan.Models;

namespace FundingRateScan.Services;

/// <summary>
/// Carica/salva le impostazioni in %APPDATA%\FundingRateScan\settings.json.
/// </summary>
public static class SettingsManager
{
    private static readonly string Dir =
        Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData), "FundingRateScan");
    private static readonly string FilePath = Path.Combine(Dir, "settings.json");

    private static readonly JsonSerializerOptions JsonOpts = new() { WriteIndented = true };

    /// <summary>Elenco di tutti gli exchange supportati, usato per inizializzare le impostazioni.</summary>
    public static readonly string[] SupportedExchanges =
    {
        "Binance", "Bybit", "OKX", "Bitget", "Gate.io", "HTX", "Hyperliquid"
    };

    public static AppSettings Load()
    {
        AppSettings settings;
        try
        {
            if (File.Exists(FilePath))
                settings = JsonSerializer.Deserialize<AppSettings>(File.ReadAllText(FilePath)) ?? new AppSettings();
            else
                settings = new AppSettings();
        }
        catch
        {
            settings = new AppSettings();
        }

        // Assicura che esista una config per ogni exchange supportato
        foreach (var name in SupportedExchanges)
        {
            if (!settings.Exchanges.Any(e => e.Name == name))
                settings.Exchanges.Add(new ExchangeApiConfig { Name = name, Enabled = true });
        }
        // Rimuove eventuali exchange non piu' supportati
        settings.Exchanges = settings.Exchanges.Where(e => SupportedExchanges.Contains(e.Name)).ToList();

        // Assicura che esista una config per ogni provider della caccia gemme PRO
        foreach (var (name, _, _) in Gems.GemProviders.Catalog)
        {
            if (!settings.GemHunter.Providers.Any(p => p.Name == name))
                settings.GemHunter.Providers.Add(new Gems.GemProviderConfig { Name = name, Enabled = true });
        }
        settings.GemHunter.Providers = settings.GemHunter.Providers
            .Where(p => Gems.GemProviders.Catalog.Any(c => c.Name == p.Name)).ToList();

        return settings;
    }

    public static void Save(AppSettings settings)
    {
        try
        {
            Directory.CreateDirectory(Dir);
            File.WriteAllText(FilePath, JsonSerializer.Serialize(settings, JsonOpts));
        }
        catch
        {
            // Persistenza best-effort: un errore di scrittura non deve bloccare l'app.
        }
    }
}
