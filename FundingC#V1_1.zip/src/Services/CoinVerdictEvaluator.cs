using System.Drawing;
using FundingRateScan.Models;

namespace FundingRateScan.Services;

/// <summary>Giudizio di sintesi su una coin, oltre alla classificazione di funding.</summary>
public enum CoinVerdict
{
    Incerta,           // dati insufficienti o segnali deboli/contrastanti
    Buona,             // pressione long confermata e sostenibile
    SqueezeProbabile,  // long affollati persistenti, leva in accumulo → possibile squeeze
    Trappola           // valori estremi → rischio reversal / liquidazione a cascata
}

/// <summary>Esito del verdetto con etichette, esplosività attesa, motivazioni e fonti.</summary>
public sealed class VerdictResult
{
    public CoinVerdict Verdict { get; set; }

    /// <summary>Etichetta estesa (es. "TRAPPOLA — rischio cascata di liquidità").</summary>
    public string Label { get; set; } = "";

    /// <summary>Etichetta compatta per la tabella (es. "⚠ Trappola").</summary>
    public string ShortLabel { get; set; } = "";

    /// <summary>Colore del badge (coerente fra tabella e finestra Dettagli).</summary>
    public Color BadgeColor { get; set; } = Color.Gray;

    /// <summary>Esplosività attesa nel breve termine (movimento/momentum).</summary>
    public string ExplosivitaBreve { get; set; } = "";

    /// <summary>Esplosività attesa nel lungo termine (pressione strutturale).</summary>
    public string ExplosivitaLungo { get; set; } = "";

    public bool SqueezeRisk { get; set; }
    public bool TrapRisk { get; set; }

    /// <summary>Motivazioni in italiano con i valori reali della coin.</summary>
    public List<string> Motivazioni { get; } = new();

    /// <summary>Riferimenti scientifici che fondano il giudizio (citazioni brevi).</summary>
    public List<string> Fonti { get; } = new();
}

/// <summary>
/// Emette un verdetto sintetico — BUONA / SQUEEZE PROBABILE / TRAPPOLA / INCERTA — che
/// AFFIANCA (non sostituisce) la classificazione di funding, indicando se una coin offre
/// esplosività sostenibile (breve/lungo) oppure se valori estremi la rendono una trappola
/// con rischio di reversal / liquidazione a cascata.
///
/// Fondamento (cfr. documentazione V2 e bibliografia):
///  - Un open interest in forte crescita con funding estremo concorde segnala accumulo
///    eccessivo di long → condizioni da reversal / liquidazione a cascata
///    (rif. [9] OI/funding/liquidation 2025–2026; [12] Zhang, code del funding in crisi).
///  - La bassa liquidità aumenta la manipolabilità e l'inaffidabilità del segnale
///    (rif. [7] La Morgia et al., ACM TOIT 2023).
///  - Carry e persistenza del funding misurano l'affollamento dei long
///    (rif. [1] Ackerer; [2] MDPI Mathematics 2026).
///
/// Supporto di ricerca probabilistico, non un consiglio finanziario. Soglie come costanti
/// interne: nessun nuovo pannello di impostazioni.
/// </summary>
public static class CoinVerdictEvaluator
{
    // Funding APR (%) oltre il quale i long sono così affollati da configurare la "zona trappola".
    // Pubblica: usata anche da ScanService per la persistenza dell'estremo (M3).
    public const double ExtremeFundingApr = 150.0;
    // M3 — quota di periodi sopra soglia estrema oltre la quale l'estremo è "persistente"
    // (leva pericolosa strutturale, non episodica): scatta la trappola anche se il funding
    // istantaneo è temporaneamente rientrato.
    private const double ExtremePersistencePct = 25.0;
    // Crescita open interest (%) considerata "forte" (accumulo di leva concorde).
    private const double VeryHighOiGrowth = 25.0;
    // Momentum (ΔVolume/ΔOI %) sopra cui l'esplosività di breve è considerata elevata.
    private const double StrongMomentum = 15.0;

    // Colori coerenti col resto dell'app.
    private static readonly Color CGood = Color.FromArgb(0, 120, 40);
    private static readonly Color CSqueeze = Color.FromArgb(200, 120, 0);
    private static readonly Color CTrap = Color.Firebrick;
    private static readonly Color CUnknown = Color.Gray;

    public static VerdictResult Evaluate(CoinResult r, ScanParameters p)
    {
        var v = new VerdictResult();

        double funding = Math.Max(r.FundingApr, r.ColabApr30 ?? 0);
        bool enriched = r.Enriched;
        bool persistent = enriched && r.PersistencePct >= p.MinPersistencePct;
        bool volConfirmed = enriched && r.VolGrowthPct >= p.VolGrowthMinPct;
        bool oiConfirmed = enriched && r.OiGrowthPct >= p.OiGrowthMinPct;
        bool oiStrong = enriched && r.OiGrowthPct >= VeryHighOiGrowth;
        bool strongMomentum = enriched && r.VolGrowthPct >= StrongMomentum && r.OiGrowthPct >= StrongMomentum;
        bool lowLiquidity = r.Volume24hUsd > 0 && r.Volume24hUsd < p.MinVolumeUsd * 2.0;

        // M3 — l'estremo può essere istantaneo (funding corrente) o persistente nello storico.
        bool extremePersistent = enriched && r.ExtremeFundingPersistencePct >= ExtremePersistencePct;
        bool extremeFunding = funding >= ExtremeFundingApr || extremePersistent;
        bool fundingPositive = funding >= p.FundingAprThreshold;
        double elevatedThreshold = Math.Max(30.0, p.FundingAprThreshold * 2.0);
        bool fundingElevated = funding >= elevatedThreshold && !extremeFunding;

        // ---------------------------------------------------------------- TRAPPOLA
        if (extremeFunding)
        {
            v.Verdict = CoinVerdict.Trappola;
            v.TrapRisk = true;
            v.Label = "TRAPPOLA — rischio reversal / liquidazione a cascata";
            v.ShortLabel = "⚠ Trappola";
            v.BadgeColor = CTrap;
            v.ExplosivitaBreve = "Alta ma direzione a rischio (possibile reversal violento)";
            v.ExplosivitaLungo = "Bassa: configurazione non sostenibile";

            if (funding >= ExtremeFundingApr)
                v.Motivazioni.Add($"Funding APR estremo ({funding:N1}% ≥ {ExtremeFundingApr:N0}%): long iper-affollati, " +
                                  "tipica zona di accumulo eccessivo che precede inversioni nette.");
            if (extremePersistent)
                v.Motivazioni.Add($"Estremo PERSISTENTE: {r.ExtremeFundingPersistencePct:N0}% dei periodi sopra la soglia " +
                                  "estrema → leva pericolosa strutturale (non un picco episodico), coerente col funding cumulato che predice i crash.");
            if (oiStrong)
                v.Motivazioni.Add($"Open interest in forte crescita ({r.OiGrowthPct:+0.0;-0.0}%) concorde col funding estremo: " +
                                  "accumulo di leva long → condizioni da liquidazione a cascata.");
            if (enriched && !volConfirmed)
                v.Motivazioni.Add($"Volume non in conferma ({r.VolGrowthPct:+0.0;-0.0}%): pressione di leva senza " +
                                  "partecipazione reale crescente (divergenza che spesso precede una correzione).");
            if (lowLiquidity)
                v.Motivazioni.Add($"Liquidità contenuta (volume 24h {r.Volume24hUsd:N0}$ vicino alla soglia minima): " +
                                  "asset più manipolabile, segnale meno affidabile.");
            if (r.OiLowReliability)
                v.Motivazioni.Add("Affidabilità OI ridotta: forte divergenza dell'open interest fra exchange (possibile misreporting) — leggere il dato con cautela.");
            if (!enriched)
                v.Motivazioni.Add("Storico flussi non disponibile (solo selezione Colab): giudizio basato sul solo funding estremo, da confermare.");

            v.Fonti.Add("[9] OI crescente + funding estremo concorde → reversal/liquidazione a cascata (2025–2026).");
            v.Fonti.Add("[12] Zhang — code del funding rate in regime di crisi/liquidazione (SSRN, 2026).");
            if (lowLiquidity || r.OiLowReliability)
                v.Fonti.Add("[7] La Morgia et al. — bassa liquidità = alta manipolabilità (ACM TOIT, 2023).");
            return v;
        }

        // ------------------------------------------------------ dati insufficienti
        if (!enriched)
        {
            v.Verdict = CoinVerdict.Incerta;
            v.BadgeColor = CUnknown;
            v.Label = "INCERTA — dati di flusso insufficienti";
            v.ShortLabel = "– Incerta";
            v.ExplosivitaBreve = "Non valutabile";
            v.ExplosivitaLungo = "Non valutabile";
            v.Motivazioni.Add("Coin selezionata solo dalla pipeline Colab: persistenza, Δvolume e ΔOI nativi non disponibili.");
            if (fundingPositive)
                v.Motivazioni.Add($"Pressione funding presente ({funding:N1}%), ma non confermabile dai flussi reali.");
            v.Fonti.Add("[2] MDPI Mathematics 2026 — l'OI rank è una misura stabile dell'attività perp (qui assente).");
            return v;
        }

        // --------------------------------------------------------------- BUONA
        // M1/M9 — La conferma "sana" è il VOLUME (partecipazione reale). L'OI non è più
        // un requisito (in cripto è ampiezza/concentrazione, non direzione): entra solo
        // come fattore di rischio/volatilità.
        if (fundingPositive && persistent && volConfirmed && !lowLiquidity)
        {
            v.Verdict = CoinVerdict.Buona;
            v.BadgeColor = CGood;
            v.Label = "BUONA — pressione long confermata e sostenibile";
            v.ShortLabel = "● Buona";
            v.SqueezeRisk = fundingElevated || oiStrong;
            v.ExplosivitaBreve = (r.VolGrowthPct >= StrongMomentum)
                ? "Alta: volume in forte crescita (partecipazione reale confermata)"
                : "Media: volume in conferma";
            v.ExplosivitaLungo = "Alta: pressione strutturale persistente con liquidità adeguata";

            v.Motivazioni.Add($"Funding APR {funding:N1}% (sopra soglia {p.FundingAprThreshold:N1}%) senza valori estremi: pressione long presente ma non da panico.");
            v.Motivazioni.Add($"Persistenza {r.PersistencePct:N0}% (≥ {p.MinPersistencePct:N0}%): i long pagano da tempo → pressione strutturale.");
            v.Motivazioni.Add($"Conferma SANA dai volumi: Δvolume {r.VolGrowthPct:+0.0;-0.0}% in crescita = partecipazione reale, non solo leva.");
            if (oiConfirmed)
                v.Motivazioni.Add($"Open interest {r.OiGrowthPct:+0.0;-0.0}%: in cripto segnala concentrazione/ampiezza (volatilità attesa), NON la direzione — qui entro livelli non estremi.");
            if (fundingElevated)
                v.Motivazioni.Add("Funding elevato: oltre all'esplosività, un rischio di squeeze (movimento brusco) da monitorare.");
            if (r.OiLowReliability)
                v.Motivazioni.Add("Nota: affidabilità OI ridotta (divergenza fra exchange) — peso dell'open interest ridimensionato.");
            v.Fonti.Add("[1] Ackerer — dominanza dei perpetui e pricing in funzione del funding (arXiv:2310.11771).");
            v.Fonti.Add("[2] OI in cripto = ampiezza/concentrazione, non direzione (OI & directionality, 2025–2026).");
            return v;
        }

        // ----------------------------------------------------- SQUEEZE PROBABILE
        if (persistent && (oiConfirmed || oiStrong) && fundingElevated)
        {
            v.Verdict = CoinVerdict.SqueezeProbabile;
            v.BadgeColor = CSqueeze;
            v.SqueezeRisk = true;
            v.Label = "SQUEEZE PROBABILE — long affollati, leva in accumulo";
            v.ShortLabel = "◐ Squeeze";
            v.ExplosivitaBreve = "Alta: condizioni da movimento brusco (squeeze)";
            v.ExplosivitaLungo = "Media: dipende dalla conferma dei volumi";

            v.Motivazioni.Add($"Funding APR elevato ({funding:N1}%) e persistenza {r.PersistencePct:N0}%: long molto affollati.");
            v.Motivazioni.Add($"Open interest in crescita ({r.OiGrowthPct:+0.0;-0.0}%): accumulo di leva = maggiore AMPIEZZA attesa (volatilità/squeeze), non un segnale di direzione.");
            if (!volConfirmed)
                v.Motivazioni.Add($"Volume non ancora pienamente in conferma ({r.VolGrowthPct:+0.0;-0.0}%): senza partecipazione reale crescente il movimento può risolversi in reversal anziché in esplosività sana.");
            if (r.OiLowReliability)
                v.Motivazioni.Add("Affidabilità OI ridotta: divergenza fra exchange (possibile misreporting) — peso dell'open interest ridimensionato.");
            v.Fonti.Add("[9] Lettura congiunta di funding, OI e liquidazioni per identificare i reversal (2025–2026).");
            v.Fonti.Add("[2] OI in cripto = ampiezza/concentrazione, non direzione (OI & directionality, 2025–2026).");
            return v;
        }

        // --------------------------------------------------------------- INCERTA
        v.Verdict = CoinVerdict.Incerta;
        v.BadgeColor = CUnknown;
        v.Label = "INCERTA — segnali parziali o non confermati";
        v.ShortLabel = "– Incerta";
        v.ExplosivitaBreve = "Bassa/Media: flussi non confermati";
        v.ExplosivitaLungo = persistent ? "Media: persistenza presente ma flussi deboli" : "Bassa";
        if (fundingPositive)
            v.Motivazioni.Add($"Pressione funding presente ({funding:N1}%) ma senza la combinazione persistenza + volume + OI richiesta per un giudizio netto.");
        else
            v.Motivazioni.Add($"Funding contenuto ({funding:N1}%): pressione di leva limitata.");
        if (!persistent) v.Motivazioni.Add($"Persistenza {r.PersistencePct:N0}% sotto soglia ({p.MinPersistencePct:N0}%).");
        if (!volConfirmed) v.Motivazioni.Add($"Δvolume {r.VolGrowthPct:+0.0;-0.0}% sotto soglia.");
        if (!oiConfirmed) v.Motivazioni.Add($"Δopen interest {r.OiGrowthPct:+0.0;-0.0}% sotto soglia.");
        v.Fonti.Add("[2] MDPI Mathematics 2026 — segnali perp affidabili solo con OI/volume in conferma.");
        return v;
    }
}
