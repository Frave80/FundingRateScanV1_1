using System.Net.Http;
using System.Text;
using System.Text.Json;
// rev: header personalizzati + GetStatusAsync

namespace FundingRateScan.Services;

/// <summary>
/// Wrapper su HttpClient con timeout, retry leggero e parsing JSON.
/// Un'unica istanza statica e' condivisa da tutti i client exchange.
/// </summary>
public static class HttpHelper
{
    private static readonly HttpClient _client = CreateClient();

    private static HttpClient CreateClient()
    {
        var handler = new HttpClientHandler
        {
            AutomaticDecompression = System.Net.DecompressionMethods.GZip
                                    | System.Net.DecompressionMethods.Deflate
        };
        var c = new HttpClient(handler) { Timeout = TimeSpan.FromSeconds(25) };
        c.DefaultRequestHeaders.Add("User-Agent", "FundingRateScan/1.0");
        c.DefaultRequestHeaders.Add("Accept", "application/json");
        return c;
    }

    /// <summary>
    /// GET che restituisce un JsonDocument, o null in caso di errore.
    /// Il chiamante e' responsabile del Dispose del documento.
    /// </summary>
    public static async Task<JsonDocument?> GetJsonAsync(string url, CancellationToken ct)
    {
        for (int attempt = 0; attempt < 3; attempt++)   // 3 tentativi: dà margine al backoff sul 429
        {
            try
            {
                using var resp = await _client.GetAsync(url, ct).ConfigureAwait(false);
                if (!resp.IsSuccessStatusCode)
                {
                    // 4xx definitivo (geo-block, simbolo inesistente): inutile riprovare.
                    if (IsPermanent(resp.StatusCode)) return null;
                    // 429 (rate limit) o 5xx: attesa crescente (backoff) e nuovo tentativo.
                    await Task.Delay(500 * (attempt + 1), ct).ConfigureAwait(false);
                    continue;
                }
                var stream = await resp.Content.ReadAsStreamAsync(ct).ConfigureAwait(false);
                return await JsonDocument.ParseAsync(stream, default, ct).ConfigureAwait(false);
            }
            catch (OperationCanceledException) when (ct.IsCancellationRequested)
            {
                throw;
            }
            catch
            {
                await Task.Delay(300, ct).ConfigureAwait(false);
            }
        }
        return null;
    }

    /// <summary>
    /// GET con header personalizzati (es. X-API-KEY dei provider a chiave).
    /// Restituisce un JsonDocument o null; il chiamante fa il Dispose.
    /// </summary>
    public static async Task<JsonDocument?> GetJsonAsync(string url,
        IReadOnlyDictionary<string, string>? headers, CancellationToken ct)
    {
        if (headers == null || headers.Count == 0)
            return await GetJsonAsync(url, ct).ConfigureAwait(false);

        for (int attempt = 0; attempt < 3; attempt++)   // 3 tentativi: dà margine al backoff sul 429
        {
            try
            {
                using var req = new HttpRequestMessage(HttpMethod.Get, url);
                foreach (var kv in headers)
                    req.Headers.TryAddWithoutValidation(kv.Key, kv.Value);
                using var resp = await _client.SendAsync(req, ct).ConfigureAwait(false);
                if (!resp.IsSuccessStatusCode)
                {
                    if (IsPermanent(resp.StatusCode)) return null;
                    // 429 (rate limit) o 5xx: attesa crescente (backoff) e nuovo tentativo.
                    await Task.Delay(500 * (attempt + 1), ct).ConfigureAwait(false);
                    continue;
                }
                var stream = await resp.Content.ReadAsStreamAsync(ct).ConfigureAwait(false);
                return await JsonDocument.ParseAsync(stream, default, ct).ConfigureAwait(false);
            }
            catch (OperationCanceledException) when (ct.IsCancellationRequested)
            {
                throw;
            }
            catch
            {
                await Task.Delay(300, ct).ConfigureAwait(false);
            }
        }
        return null;
    }

    /// <summary>
    /// Stato HTTP di un URL (HEAD, con fallback GET se HEAD non supportato).
    /// Restituisce 0 in caso di errore di rete. Usato per verificare se una
    /// pagina (es. CoinMarketCap) esiste prima di aprirla nel browser.
    /// </summary>
    public static async Task<int> GetStatusAsync(string url, CancellationToken ct)
    {
        try
        {
            using var req = new HttpRequestMessage(HttpMethod.Head, url);
            using var resp = await _client.SendAsync(req, HttpCompletionOption.ResponseHeadersRead, ct).ConfigureAwait(false);
            int code = (int)resp.StatusCode;
            if (code == 405 || code == 501)   // HEAD non supportato → riprova con GET
            {
                using var req2 = new HttpRequestMessage(HttpMethod.Get, url);
                using var resp2 = await _client.SendAsync(req2, HttpCompletionOption.ResponseHeadersRead, ct).ConfigureAwait(false);
                return (int)resp2.StatusCode;
            }
            return code;
        }
        catch (OperationCanceledException) when (ct.IsCancellationRequested) { throw; }
        catch { return 0; }
    }

    /// <summary>POST con corpo JSON (usato da Hyperliquid).</summary>
    public static async Task<JsonDocument?> PostJsonAsync(string url, string jsonBody, CancellationToken ct)
    {
        for (int attempt = 0; attempt < 3; attempt++)   // 3 tentativi: dà margine al backoff sul 429
        {
            try
            {
                using var content = new StringContent(jsonBody, Encoding.UTF8, "application/json");
                using var resp = await _client.PostAsync(url, content, ct).ConfigureAwait(false);
                if (!resp.IsSuccessStatusCode)
                {
                    if (IsPermanent(resp.StatusCode)) return null;
                    // 429 (rate limit) o 5xx: attesa crescente (backoff) e nuovo tentativo.
                    await Task.Delay(500 * (attempt + 1), ct).ConfigureAwait(false);
                    continue;
                }
                var stream = await resp.Content.ReadAsStreamAsync(ct).ConfigureAwait(false);
                return await JsonDocument.ParseAsync(stream, default, ct).ConfigureAwait(false);
            }
            catch (OperationCanceledException) when (ct.IsCancellationRequested)
            {
                throw;
            }
            catch
            {
                await Task.Delay(300, ct).ConfigureAwait(false);
            }
        }
        return null;
    }

    /// <summary>Lettura sicura di un double da una proprieta' JSON che puo' essere stringa o numero.</summary>
    public static double GetDouble(JsonElement el, string prop)
    {
        if (!el.TryGetProperty(prop, out var v)) return 0;
        return ParseDouble(v);
    }

    public static double ParseDouble(JsonElement v)
    {
        switch (v.ValueKind)
        {
            case JsonValueKind.Number:
                return v.GetDouble();
            case JsonValueKind.String:
                return double.TryParse(v.GetString(),
                    System.Globalization.NumberStyles.Any,
                    System.Globalization.CultureInfo.InvariantCulture, out var d) ? d : 0;
            default:
                return 0;
        }
    }

    public static long GetLong(JsonElement el, string prop)
    {
        if (!el.TryGetProperty(prop, out var v)) return 0;
        if (v.ValueKind == JsonValueKind.Number) return v.GetInt64();
        if (v.ValueKind == JsonValueKind.String &&
            long.TryParse(v.GetString(), out var l)) return l;
        return 0;
    }

    public static string GetString(JsonElement el, string prop)
        => el.TryGetProperty(prop, out var v) && v.ValueKind == JsonValueKind.String
            ? v.GetString() ?? "" : "";

    /// <summary>
    /// Vero se lo stato HTTP è un errore 4xx DEFINITIVO per cui non ha senso riprovare
    /// (geo-block, simbolo inesistente, ecc.). Il 429 « Too Many Requests » è ESCLUSO:
    /// è un rate limit temporaneo e va ritentato con backoff, non trattato come permanente.
    /// </summary>
    private static bool IsPermanent(System.Net.HttpStatusCode s)
        => (int)s >= 400 && (int)s < 500 && s != System.Net.HttpStatusCode.TooManyRequests;
}
