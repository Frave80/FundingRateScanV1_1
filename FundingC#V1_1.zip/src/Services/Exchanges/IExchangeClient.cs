using FundingRateScan.Models;

namespace FundingRateScan.Services.Exchanges;

/// <summary>
/// Contratto comune per ogni exchange (CEX o DEX).
/// </summary>
public interface IExchangeClient
{
    string Name { get; }

    /// <summary>
    /// Scarica in blocco i dati correnti di tutti i contratti perpetui:
    /// funding rate, volume 24h e (dove disponibile) open interest.
    /// </summary>
    Task<IReadOnlyList<CoinMarket>> FetchMarketsAsync(CancellationToken ct);

    /// <summary>
    /// Arricchisce una singola coin candidata con lo storico di funding,
    /// open interest e volume necessario per il calcolo dei trend.
    /// </summary>
    Task EnrichHistoryAsync(CoinMarket market, int lookbackDays, CancellationToken ct);

    /// <summary>
    /// Scarica lo storico esteso dei funding rate (frazione per intervallo)
    /// per un singolo simbolo, fino a <paramref name="days"/> giorni indietro,
    /// con paginazione. Usato dalla heatmap del dettaglio coin.
    /// </summary>
    Task<List<TrendPoint>> FetchFundingHistoryAsync(string symbol, int days, CancellationToken ct);
}

/// <summary>Utility comuni di normalizzazione simboli.</summary>
public static class SymbolUtils
{
    private static readonly HashSet<string> Stablecoins = new(StringComparer.OrdinalIgnoreCase)
    {
        "USDT","USDC","BUSD","DAI","FRAX","TUSD","USDP","GUSD","USDD","PYUSD",
        "USDE","FDUSD","USDS","CRVUSD","LUSD","SUSD","DOLA","EURS","EURT","USDX"
    };

    public static bool IsStable(string baseAsset) => Stablecoins.Contains(baseAsset);

    /// <summary>Rimuove eventuali prefissi numerici tipo "1000PEPE" -> "PEPE" per il merge cross-exchange.</summary>
    public static string Normalize(string baseAsset)
    {
        var b = baseAsset.ToUpperInvariant();
        foreach (var p in new[] { "1000000", "100000", "10000", "1000", "100" })
            if (b.StartsWith(p) && b.Length > p.Length) return b.Substring(p.Length);
        return b;
    }
}
