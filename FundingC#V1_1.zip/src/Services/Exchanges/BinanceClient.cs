using System.Text.Json;
using FundingRateScan.Models;

namespace FundingRateScan.Services.Exchanges;

/// <summary>Binance USDT-M Futures (CEX). Endpoint pubblici, nessuna chiave richiesta.</summary>
public class BinanceClient : IExchangeClient
{
    public string Name => "Binance";
    private const string Base = "https://fapi.binance.com";

    public async Task<IReadOnlyList<CoinMarket>> FetchMarketsAsync(CancellationToken ct)
    {
        var result = new List<CoinMarket>();

        // 1) Simboli perpetui attivi
        var baseBySymbol = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
        using (var info = await HttpHelper.GetJsonAsync($"{Base}/fapi/v1/exchangeInfo", ct))
        {
            if (info == null) return result;
            if (info.RootElement.TryGetProperty("symbols", out var syms))
            {
                foreach (var s in syms.EnumerateArray())
                {
                    if (HttpHelper.GetString(s, "contractType") != "PERPETUAL") continue;
                    if (HttpHelper.GetString(s, "status") != "TRADING") continue;
                    if (HttpHelper.GetString(s, "quoteAsset") != "USDT") continue;
                    var sym = HttpHelper.GetString(s, "symbol");
                    var baseAsset = HttpHelper.GetString(s, "baseAsset");
                    if (SymbolUtils.IsStable(baseAsset)) continue;
                    baseBySymbol[sym] = baseAsset;
                }
            }
        }

        // 2) Funding corrente
        var fundingBySymbol = new Dictionary<string, double>(StringComparer.OrdinalIgnoreCase);
        using (var prem = await HttpHelper.GetJsonAsync($"{Base}/fapi/v1/premiumIndex", ct))
        {
            if (prem != null && prem.RootElement.ValueKind == JsonValueKind.Array)
                foreach (var p in prem.RootElement.EnumerateArray())
                    fundingBySymbol[HttpHelper.GetString(p, "symbol")] = HttpHelper.GetDouble(p, "lastFundingRate");
        }

        // 3) Ticker 24h (volume in USDT = quoteVolume, prezzo)
        using (var tick = await HttpHelper.GetJsonAsync($"{Base}/fapi/v1/ticker/24hr", ct))
        {
            if (tick == null || tick.RootElement.ValueKind != JsonValueKind.Array) return result;
            foreach (var t in tick.RootElement.EnumerateArray())
            {
                var sym = HttpHelper.GetString(t, "symbol");
                if (!baseBySymbol.TryGetValue(sym, out var baseAsset)) continue;
                result.Add(new CoinMarket
                {
                    Exchange = Name,
                    Symbol = sym,
                    Base = SymbolUtils.Normalize(baseAsset),
                    FundingRate = fundingBySymbol.TryGetValue(sym, out var fr) ? fr : 0,
                    FundingIntervalHours = 8.0,
                    Volume24hUsd = HttpHelper.GetDouble(t, "quoteVolume"),
                    LastPrice = HttpHelper.GetDouble(t, "lastPrice"),
                });
            }
        }
        return result;
    }

    public async Task EnrichHistoryAsync(CoinMarket m, int lookbackDays, CancellationToken ct)
    {
        int limit = Math.Clamp(lookbackDays, 7, 30);

        // Funding history (1 punto ogni 8h -> ~3/giorno)
        using (var fr = await HttpHelper.GetJsonAsync(
            $"{Base}/fapi/v1/fundingRate?symbol={m.Symbol}&limit={limit * 3}", ct))
        {
            if (fr != null && fr.RootElement.ValueKind == JsonValueKind.Array)
                foreach (var e in fr.RootElement.EnumerateArray())
                    m.FundingHistory.Add(new TrendPoint(
                        DateTimeOffset.FromUnixTimeMilliseconds(HttpHelper.GetLong(e, "fundingTime")).UtcDateTime,
                        HttpHelper.GetDouble(e, "fundingRate")));
        }

        // Open interest history (valore in USD)
        using (var oi = await HttpHelper.GetJsonAsync(
            $"{Base}/futures/data/openInterestHist?symbol={m.Symbol}&period=1d&limit={limit}", ct))
        {
            if (oi != null && oi.RootElement.ValueKind == JsonValueKind.Array)
                foreach (var e in oi.RootElement.EnumerateArray())
                    m.OiHistory.Add(new TrendPoint(
                        DateTimeOffset.FromUnixTimeMilliseconds(HttpHelper.GetLong(e, "timestamp")).UtcDateTime,
                        HttpHelper.GetDouble(e, "sumOpenInterestValue")));
            if (m.OiHistory.Count > 0)
                m.OpenInterestUsd = m.OiHistory[^1].Value;
        }

        await FetchKlinesVolume(m, limit, ct);
    }

    private async Task FetchKlinesVolume(CoinMarket m, int limit, CancellationToken ct)
    {
        // Volume history dalle candele giornaliere (volume in USDT = quote asset volume, indice 7)
        using (var kl = await HttpHelper.GetJsonAsync(
            $"{Base}/fapi/v1/klines?symbol={m.Symbol}&interval=1d&limit={limit}", ct))
        {
            if (kl != null && kl.RootElement.ValueKind == JsonValueKind.Array)
                foreach (var c in kl.RootElement.EnumerateArray())
                {
                    if (c.ValueKind != JsonValueKind.Array) continue;
                    var arr = c.EnumerateArray().ToArray();
                    if (arr.Length < 8) continue;
                    long openTime = arr[0].GetInt64();
                    double quoteVol = HttpHelper.ParseDouble(arr[7]);
                    m.VolumeHistory.Add(new TrendPoint(
                        DateTimeOffset.FromUnixTimeMilliseconds(openTime).UtcDateTime, quoteVol));
                }
        }
    }

    public async Task<List<TrendPoint>> FetchFundingHistoryAsync(string symbol, int days, CancellationToken ct)
    {
        var result = new List<TrendPoint>();
        long startMs = DateTimeOffset.UtcNow.AddDays(-days).ToUnixTimeMilliseconds();
        long endMs = DateTimeOffset.UtcNow.ToUnixTimeMilliseconds();
        long cursor = startMs;

        for (int page = 0; page < 20; page++)
        {
            using var doc = await HttpHelper.GetJsonAsync(
                $"{Base}/fapi/v1/fundingRate?symbol={symbol}&startTime={cursor}&endTime={endMs}&limit=1000", ct);
            if (doc == null || doc.RootElement.ValueKind != JsonValueKind.Array) break;

            int n = 0;
            long lastTime = cursor;
            foreach (var e in doc.RootElement.EnumerateArray())
            {
                long t = HttpHelper.GetLong(e, "fundingTime");
                result.Add(new TrendPoint(
                    DateTimeOffset.FromUnixTimeMilliseconds(t).UtcDateTime,
                    HttpHelper.GetDouble(e, "fundingRate")));
                lastTime = t;
                n++;
            }
            if (n < 1000) break;
            cursor = lastTime + 1;
        }
        return result;
    }
}
