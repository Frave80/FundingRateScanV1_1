using System.Globalization;
using System.Text.Json;
using FundingRateScan.Models;

namespace FundingRateScan.Services.Exchanges;

/// <summary>Hyperliquid perp (DEX). API pubblica via POST.</summary>
public class HyperliquidClient : IExchangeClient
{
    public string Name => "Hyperliquid";
    private const string Url = "https://api.hyperliquid.xyz/info";

    public async Task<IReadOnlyList<CoinMarket>> FetchMarketsAsync(CancellationToken ct)
    {
        var result = new List<CoinMarket>();
        using var doc = await HttpHelper.PostJsonAsync(Url, "{\"type\":\"metaAndAssetCtxs\"}", ct);
        if (doc == null || doc.RootElement.ValueKind != JsonValueKind.Array) return result;

        var root = doc.RootElement;
        if (root.GetArrayLength() < 2) return result;

        var universe = root[0].TryGetProperty("universe", out var u) && u.ValueKind == JsonValueKind.Array
            ? u.EnumerateArray().ToArray() : Array.Empty<JsonElement>();
        var ctxs = root[1].ValueKind == JsonValueKind.Array
            ? root[1].EnumerateArray().ToArray() : Array.Empty<JsonElement>();

        int n = Math.Min(universe.Length, ctxs.Length);
        for (int i = 0; i < n; i++)
        {
            var name = HttpHelper.GetString(universe[i], "name");
            if (string.IsNullOrEmpty(name) || SymbolUtils.IsStable(name)) continue;

            var ctx = ctxs[i];
            double mark = HttpHelper.GetDouble(ctx, "markPx");
            double oiCoin = HttpHelper.GetDouble(ctx, "openInterest");
            double dayVol = HttpHelper.GetDouble(ctx, "dayNtlVlm");  // gia' in USD
            double funding = HttpHelper.GetDouble(ctx, "funding");   // tasso orario

            result.Add(new CoinMarket
            {
                Exchange = Name,
                Symbol = name,
                Base = SymbolUtils.Normalize(name),
                FundingRate = funding,
                FundingIntervalHours = 1.0,   // Hyperliquid liquida ogni ora
                Volume24hUsd = dayVol,
                OpenInterestUsd = oiCoin * mark,
                LastPrice = mark,
            });
        }
        return result;
    }

    public async Task EnrichHistoryAsync(CoinMarket m, int lookbackDays, CancellationToken ct)
    {
        long startMs = DateTimeOffset.UtcNow.AddDays(-lookbackDays).ToUnixTimeMilliseconds();
        string body = string.Format(CultureInfo.InvariantCulture,
            "{{\"type\":\"fundingHistory\",\"coin\":\"{0}\",\"startTime\":{1}}}", m.Symbol, startMs);

        using var doc = await HttpHelper.PostJsonAsync(Url, body, ct);
        if (doc != null && doc.RootElement.ValueKind == JsonValueKind.Array)
        {
            foreach (var e in doc.RootElement.EnumerateArray())
                m.FundingHistory.Add(new TrendPoint(
                    DateTimeOffset.FromUnixTimeMilliseconds(HttpHelper.GetLong(e, "time")).UtcDateTime,
                    HttpHelper.GetDouble(e, "fundingRate")));
            m.FundingHistory.Sort((a, b) => a.Time.CompareTo(b.Time));
        }
    }

    public async Task<List<TrendPoint>> FetchFundingHistoryAsync(string symbol, int days, CancellationToken ct)
    {
        var result = new List<TrendPoint>();
        long cursor = DateTimeOffset.UtcNow.AddDays(-days).ToUnixTimeMilliseconds();
        long endMs = DateTimeOffset.UtcNow.ToUnixTimeMilliseconds();

        // Funding orario: per periodi lunghi sono molti punti, limitiamo le pagine.
        for (int page = 0; page < 30; page++)
        {
            string body = string.Format(CultureInfo.InvariantCulture,
                "{{\"type\":\"fundingHistory\",\"coin\":\"{0}\",\"startTime\":{1}}}", symbol, cursor);
            using var doc = await HttpHelper.PostJsonAsync(Url, body, ct);
            if (doc == null || doc.RootElement.ValueKind != JsonValueKind.Array) break;

            long last = cursor;
            int n = 0;
            foreach (var e in doc.RootElement.EnumerateArray())
            {
                long t = HttpHelper.GetLong(e, "time");
                if (t > endMs) continue;
                result.Add(new TrendPoint(
                    DateTimeOffset.FromUnixTimeMilliseconds(t).UtcDateTime,
                    HttpHelper.GetDouble(e, "fundingRate")));
                last = t;
                n++;
            }
            if (n < 500) break;       // ultima pagina
            cursor = last + 1;
        }
        result.Sort((a, b) => a.Time.CompareTo(b.Time));
        return result;
    }
}
