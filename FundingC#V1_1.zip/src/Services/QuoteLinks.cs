using System.Diagnostics;
using System.Text;

namespace FundingRateScan.Services;

/// <summary>
/// Apertura della pagina di quotazione di una coin nel browser predefinito.
///
/// Regola di instradamento (richiesta dall'utente):
///  • COIN NUOVE — token on-chain con un URL DEX Screener già noto (gemme, meme,
///    monitor on-chain) → si apre direttamente la pagina DEX Screener del pair;
///  • COIN AFFERMATE — simbolo da exchange centralizzato (scansione funding, Colab)
///    → si prova CoinMarketCap (slug ricavato dal nome) e, se la pagina non esiste,
///    si ripiega sul grafico di TradingView ({SIMBOLO}USDT) o, per le coin senza
///    perpetuo di riferimento, su DEX Screener.
///
/// Centralizzando qui la logica, tutte le finestre di ricerca si comportano allo
/// stesso modo e basta modificare un solo file per cambiare le destinazioni.
/// </summary>
public static class QuoteLinks
{
    // --- Costruttori di URL --------------------------------------------------
    public static string DexSearchUrl(string query) =>
        "https://dexscreener.com/search?q=" + Uri.EscapeDataString(query);

    public static string TradingViewUrl(string symbol) =>
        "https://www.tradingview.com/chart/?symbol=" + Uri.EscapeDataString(symbol.ToUpperInvariant() + "USDT");

    public static string CoinMarketCapUrl(string slug) =>
        $"https://coinmarketcap.com/currencies/{slug}/";

    /// <summary>Apre un URL nel browser predefinito; ignora silenziosamente se non riesce.</summary>
    public static void Open(string url)
    {
        try { Process.Start(new ProcessStartInfo(url) { UseShellExecute = true }); }
        catch { /* browser non disponibile: nessun blocco dell'app */ }
    }

    /// <summary>Apre direttamente una pagina DEX Screener già nota (es. URL del pair di una gemma).</summary>
    public static void OpenDex(string? url)
    {
        if (!string.IsNullOrWhiteSpace(url) && url!.StartsWith("http")) Open(url);
    }

    /// <summary>Apre DEX Screener cercando per contratto o simbolo (coin nuove senza URL pronto).</summary>
    public static void OpenDexSearch(string query) => Open(DexSearchUrl(query));

    /// <summary>
    /// Apre la quotazione di una coin "affermata" (simbolo CEX): prima CoinMarketCap
    /// (verificando che la pagina esista), poi ripiego su TradingView o, se
    /// <paramref name="preferDexFallback"/> è true, su DEX Screener.
    /// È asincrona perché interroga lo stato HTTP della pagina CoinMarketCap.
    /// </summary>
    public static async Task OpenSymbolAsync(string symbol, string? fullName, bool preferDexFallback,
        IProgress<string>? status, CancellationToken ct)
    {
        string name = string.IsNullOrWhiteSpace(fullName) ? symbol : fullName!;
        string slug = Slugify(name);
        string url = CoinMarketCapUrl(slug);

        status?.Report($"Verifico la pagina CoinMarketCap di {symbol}...");
        int code = slug.Length > 0 ? await HttpHelper.GetStatusAsync(url, ct) : 404;

        if (code == 404 || code == 410)
        {
            if (preferDexFallback)
            {
                url = DexSearchUrl(symbol);
                status?.Report($"{symbol} non trovata su CoinMarketCap — apro DEX Screener.");
            }
            else
            {
                url = TradingViewUrl(symbol);
                status?.Report($"{symbol} non trovata su CoinMarketCap — apro TradingView.");
            }
        }
        else status?.Report($"Apro {symbol} su CoinMarketCap.");

        Open(url);
    }

    /// <summary>"Shiba Inu" → "shiba-inu" (slug nello stile degli URL di CoinMarketCap).</summary>
    public static string Slugify(string s)
    {
        var sb = new StringBuilder();
        bool dash = false;
        foreach (var ch in s.Trim().ToLowerInvariant())
        {
            if (char.IsLetterOrDigit(ch)) { sb.Append(ch); dash = false; }
            else if (!dash && sb.Length > 0) { sb.Append('-'); dash = true; }
        }
        return sb.ToString().TrimEnd('-');
    }
}
