namespace FundingRateScan.Colab;

/// <summary>
/// Costanti del CONFIG di FundingRateHeatmap_v8.py (replica fedele per confronto Colab).
/// </summary>
public static class ColabConfig
{
    public const int LookbackDays = 365;
    public static readonly int[] FallbackDays = { 180, 90 };
    public const int TopNCoins = 500;

    public const double HighAprThresh = 30.0;   // APR medio
    public const double HighAprRecent = 20.0;   // APR ultimi 30gg
    public const double PriceReactionPct = 15.0;
    public const int MinDataDays = 3;

    // Intervallo di funding di default per exchange (ore), usato da to_apr quando
    // non si riesce a stimarlo dai timestamp.
    public const double IntervalOkx = 8.0;
    public const double IntervalHyperliquid = 1.0;
    public const double IntervalBitget = 8.0;
    public const double IntervalHtx = 8.0;
    public const double IntervalGate = 8.0;
}

/// <summary>Info coin da CoinGecko (come nel CoinListFetcher Python).</summary>
public sealed class ColabCoin
{
    public string Symbol { get; set; } = "";
    public string Name { get; set; } = "";
    public int Rank { get; set; } = 9999;
    public double PriceUsd { get; set; }
    public double? Change1y { get; set; }
    public double? Change30d { get; set; }
    public double? Change7d { get; set; }
}

/// <summary>Riga della tabella di analisi (come analysis_df Python).</summary>
public sealed class ColabAnalysisRow
{
    public string Symbol { get; set; } = "";
    public string Name { get; set; } = "";
    public string Status { get; set; } = "";
    public double AprMedio { get; set; }
    public double Apr90 { get; set; }
    public double Apr30 { get; set; }
    public double AprPicco { get; set; }
    public double Volatilita { get; set; }
    public double? Pr1a { get; set; }
    public double? Pr30 { get; set; }
    public double? Pr7 { get; set; }
    public double Prezzo { get; set; }
}

/// <summary>
/// DataFrame funding: righe = coin (simbolo), colonne = date giornaliere.
/// Valore = APR medio giornaliero (null = NaN), come fund_df Python.
/// </summary>
public sealed class FundingFrame
{
    public List<DateTime> Dates { get; } = new();                       // indice colonne (UTC, mezzanotte)
    public Dictionary<string, double?[]> Rows { get; } = new();          // simbolo → valori per data
    public Dictionary<string, string> Sources { get; } = new();         // simbolo → exchange usati

    public int ValidCoins => Rows.Values.Count(r => r.Any(v => v.HasValue));
}

/// <summary>Esito completo di una esecuzione "replica Colab".</summary>
public sealed class ColabResult
{
    public FundingFrame Frame { get; set; } = new();
    public List<ColabAnalysisRow> Analysis { get; set; } = new();
    public int ActualDays { get; set; }
    public int CoinsLoaded { get; set; }
    public double AprMean { get; set; }
    public double AprMedian { get; set; }
    public Dictionary<string, int> SourceCounts { get; set; } = new();
}
