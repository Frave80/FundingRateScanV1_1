using System.Text.Json;
using System.Text.RegularExpressions;
using FundingRateScan.Services;

namespace FundingRateScan.Colab;

/// <summary>
/// Replica di CoinListFetcher: top N coin CoinGecko per market cap con variazioni
/// prezzo 1y/30d/7d. Stessa validazione simboli e stessa esclusione stablecoin.
/// </summary>
public static class ColabCoinGecko
{
    private static readonly HashSet<string> Stablecoins = new(StringComparer.OrdinalIgnoreCase)
    {
        "USDT","USDC","BUSD","DAI","FRAX","TUSD","USDP","GUSD","USDD","PYUSD",
        "USDE","FDUSD","USDS","CRVUSD","LUSD","SUSD","DOLA","AGEUR","EURS","EURT",
        "XSGD","USDB","USDX"
    };

    private static readonly Regex Valid = new("^[0-9A-Z.]{2,10}$", RegexOptions.Compiled);

    private static bool IsValid(string sym)
    {
        if (Stablecoins.Contains(sym)) return false;
        if (sym.Contains('_') || sym.Length > 10) return false;
        return Valid.IsMatch(sym);
    }

    public static async Task<List<ColabCoin>> FetchAsync(int topN, IProgress<string> log, CancellationToken ct)
    {
        log.Report($"CoinGecko top {topN} coin + variazioni prezzo...");
        var coins = new List<ColabCoin>();
        int page = 1;

        while (coins.Count < topN)
        {
            var url = "https://api.coingecko.com/api/v3/coins/markets?vs_currency=usd" +
                      $"&order=market_cap_desc&per_page=250&page={page}&sparkline=false" +
                      "&price_change_percentage=1y,30d,7d";
            using var doc = await HttpHelper.GetJsonAsync(url, ct);
            if (doc == null || doc.RootElement.ValueKind != JsonValueKind.Array) break;

            int batch = 0;
            foreach (var c in doc.RootElement.EnumerateArray())
            {
                batch++;
                var sym = HttpHelper.GetString(c, "symbol").ToUpperInvariant();
                if (!IsValid(sym)) continue;
                coins.Add(new ColabCoin
                {
                    Symbol = sym,
                    Name = HttpHelper.GetString(c, "name"),
                    Rank = (int)(GetNullableDouble(c, "market_cap_rank") ?? 9999),
                    PriceUsd = GetNullableDouble(c, "current_price") ?? 0.0,
                    Change1y = GetNullableDouble(c, "price_change_percentage_1y_in_currency"),
                    Change30d = GetNullableDouble(c, "price_change_percentage_30d_in_currency"),
                    Change7d = GetNullableDouble(c, "price_change_percentage_7d_in_currency"),
                });
                if (coins.Count >= topN) break;
            }
            if (batch == 0) break;
            page++;
            await Task.Delay(1500, ct);   // come time.sleep(1.5) del Python
        }

        log.Report($"  {coins.Count} coin ottenuti");
        return coins.Take(topN).ToList();
    }

    private static double? GetNullableDouble(JsonElement el, string prop)
    {
        if (!el.TryGetProperty(prop, out var v)) return null;
        if (v.ValueKind == JsonValueKind.Null) return null;
        if (v.ValueKind == JsonValueKind.Number) return v.GetDouble();
        if (v.ValueKind == JsonValueKind.String &&
            double.TryParse(v.GetString(), System.Globalization.NumberStyles.Any,
                System.Globalization.CultureInfo.InvariantCulture, out var d)) return d;
        return null;
    }
}
