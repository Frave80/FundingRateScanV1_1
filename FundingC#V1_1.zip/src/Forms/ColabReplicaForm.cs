using System.Globalization;
using System.Text;
using FundingRateScan.Colab;

namespace FundingRateScan.Forms;

/// <summary>
/// Replica fedele del programma Python (FundingRateHeatmap_v8.py) per confrontare
/// i dati con Colab: stessi exchange, stesso storico, stessa classificazione.
/// Esporta la tabella di analisi e il DataFrame funding (coin × data) in CSV.
/// </summary>
public sealed class ColabReplicaForm : AppForm
{
    private static readonly CultureInfo Ci = CultureInfo.InvariantCulture;

    private CancellationTokenSource? _cts;
    private ColabResult? _result;

    private NumericUpDown _numTopN = null!;
    private ComboBox _cmbLookback = null!;
    private Button _btnRun = null!, _btnStop = null!, _btnExportAnalysis = null!, _btnExportFrame = null!;
    private Label _banner = null!;
    private ToolStripStatusLabel _status = null!;
    private ToolStripProgressBar _progress = null!;
    private DataGridView _grid = null!;
    private TextBox _log = null!;

    public ColabReplicaForm()
    {
        BuildUi();
    }

    private void BuildUi()
    {
        Text = "Replica Python (Colab) — Funding Rate Heatmap v8";
        StartPosition = FormStartPosition.CenterParent;
        ClientSize = new Size(1200, 740);
        MinimumSize = new Size(900, 560);
        Font = new Font("Segoe UI", 9f);

        BuildGrid();        // Fill
        BuildBanner();      // Top
        BuildToolbar();     // Top
        BuildLog();         // Bottom
        BuildStatusBar();   // Bottom
    }

    private void BuildToolbar()
    {
        var p = new Panel { Dock = DockStyle.Top, Height = 44, Padding = new Padding(8, 7, 8, 6) };

        var lblTop = new Label { Text = "Top N coin:", Location = new Point(8, 11), AutoSize = true };
        _numTopN = new NumericUpDown { Location = new Point(86, 8), Size = new Size(80, 24), Minimum = 10, Maximum = 500, Value = 500, Increment = 50 };

        var lblLb = new Label { Text = "Lookback:", Location = new Point(182, 11), AutoSize = true };
        _cmbLookback = new ComboBox { Location = new Point(252, 7), Size = new Size(150, 24), DropDownStyle = ComboBoxStyle.DropDownList };
        _cmbLookback.Items.AddRange(new object[] { "365 → 180 → 90 (default)", "180 → 90", "90" });
        _cmbLookback.SelectedIndex = 0;

        _btnRun = new Button { Text = "Avvia replica", Location = new Point(416, 7), Size = new Size(120, 28) };
        _btnRun.Click += (_, _) => Run();
        _btnStop = new Button { Text = "Interrompi", Location = new Point(542, 7), Size = new Size(95, 28), Enabled = false };
        _btnStop.Click += (_, _) => _cts?.Cancel();

        _btnExportAnalysis = new Button { Text = "Esporta analisi CSV", Location = new Point(660, 7), Size = new Size(150, 28), Enabled = false };
        _btnExportAnalysis.Click += (_, _) => ExportAnalysis();
        _btnExportFrame = new Button { Text = "Esporta DataFrame CSV", Location = new Point(816, 7), Size = new Size(170, 28), Enabled = false };
        _btnExportFrame.Click += (_, _) => ExportFrame();

        p.Controls.AddRange(new Control[] { lblTop, _numTopN, lblLb, _cmbLookback, _btnRun, _btnStop, _btnExportAnalysis, _btnExportFrame });
        Controls.Add(p);
    }

    private void BuildBanner()
    {
        _banner = new Label
        {
            Dock = DockStyle.Top, Height = 30, TextAlign = ContentAlignment.MiddleLeft,
            Padding = new Padding(10, 0, 0, 0), BackColor = Color.FromArgb(17, 24, 39), ForeColor = Color.Gainsboro,
            Font = new Font("Consolas", 9.5f), Text = "Pronto. Avvia la replica per ricostruire i dati di Colab."
        };
        Controls.Add(_banner);
    }

    private void BuildGrid()
    {
        _grid = new DataGridView
        {
            Dock = DockStyle.Fill, ReadOnly = true, AllowUserToAddRows = false, RowHeadersVisible = false,
            AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill, SelectionMode = DataGridViewSelectionMode.FullRowSelect,
            MultiSelect = false, BackgroundColor = SystemColors.Window, BorderStyle = BorderStyle.None,
            EnableHeadersVisualStyles = false
        };
        _grid.ColumnHeadersDefaultCellStyle.BackColor = Color.FromArgb(40, 44, 60);
        _grid.ColumnHeadersDefaultCellStyle.ForeColor = Color.White;
        _grid.ColumnHeadersDefaultCellStyle.Font = UiFonts.Bold9;

        AddCol("Sym", 60, null);
        AddCol("Nome", 130, null);
        AddCol("Stato", 110, null);
        AddCol("APR Medio", 90, "N1");
        AddCol("APR 90gg", 85, "N1");
        AddCol("APR 30gg", 85, "N1");
        AddCol("APR Picco", 85, "N1");
        AddCol("σ Vol", 70, "N1");
        AddCol("Prezzo", 90, null);
        AddCol("Var 1a", 80, "N1");
        AddCol("Var 30gg", 80, "N1");
        AddCol("Var 7gg", 80, "N1");

        // Doppio clic sulla riga → apre la quotazione della coin. Le coin della replica
        // Colab sono top-500 per capitalizzazione (affermate): CoinMarketCap, con ripiego
        // su TradingView se la pagina non esiste.
        _grid.CellDoubleClick += (_, e) =>
        {
            if (e.RowIndex < 0) return;
            var row = _grid.Rows[e.RowIndex];
            string sym = Convert.ToString(row.Cells[0].Value) ?? "";
            string name = Convert.ToString(row.Cells[1].Value) ?? "";
            if (sym.Length > 0)
                _ = Services.QuoteLinks.OpenSymbolAsync(sym, name, preferDexFallback: false,
                    new Progress<string>(s => _status.Text = s), CancellationToken.None);
        };

        Controls.Add(_grid);
    }

    private void AddCol(string header, int w, string? fmt)
    {
        var c = new DataGridViewTextBoxColumn { HeaderText = header, FillWeight = w };
        if (fmt != null)
        {
            c.DefaultCellStyle.Format = fmt;
            c.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            c.DefaultCellStyle.FormatProvider = Ci;
        }
        _grid.Columns.Add(c);
    }

    private void BuildLog()
    {
        _log = new TextBox
        {
            Dock = DockStyle.Bottom, Multiline = true, ReadOnly = true, Height = 130, ScrollBars = ScrollBars.Vertical,
            BackColor = Color.FromArgb(20, 22, 30), ForeColor = Color.Gainsboro, Font = new Font("Consolas", 9f)
        };
        Controls.Add(_log);
    }

    private void BuildStatusBar()
    {
        var strip = new StatusStrip();
        _status = new ToolStripStatusLabel { Spring = true, TextAlign = ContentAlignment.MiddleLeft };
        _progress = new ToolStripProgressBar { Style = ProgressBarStyle.Marquee, Visible = false, Width = 150 };
        strip.Items.Add(_status);
        strip.Items.Add(_progress);
        Controls.Add(strip);
    }

    // ============================================================== Logica
    private async void Run()
    {
        if (_cts != null) return;
        int[] fallback = _cmbLookback.SelectedIndex switch
        {
            1 => new[] { 180, 90 },
            2 => new[] { 90 },
            _ => new[] { 365, 180, 90 },
        };
        var service = new ColabService((int)_numTopN.Value, fallback);

        _cts = new CancellationTokenSource();
        SetBusy(true);
        _log.Clear();
        var progress = new Progress<string>(AppendLog);

        try
        {
            _status.Text = "Replica in corso...";
            _result = await service.RunAsync(progress, _cts.Token);
            FillGrid(_result);
            _banner.Text = _result.CoinsLoaded > 0
                ? $"Dati caricati: {_result.CoinsLoaded} coin | Periodo effettivo: {_result.ActualDays} giorni | " +
                  $"APR medio: {_result.AprMean.ToString("N1", Ci)}% | mediana: {_result.AprMedian.ToString("N1", Ci)}% | " +
                  $"coin classificate: {_result.Analysis.Count}"
                : "Nessun dato disponibile da nessun exchange.";
            _status.Text = "Completato.";
            _btnExportAnalysis.Enabled = _result.Analysis.Count > 0;
            _btnExportFrame.Enabled = _result.Frame.ValidCoins > 0;
        }
        catch (OperationCanceledException)
        {
            _status.Text = "Interrotto."; AppendLog("** Interrotto **");
        }
        catch (Exception ex)
        {
            _status.Text = "Errore."; AppendLog("ERRORE: " + ex.Message);
            MessageBox.Show(this, ex.Message, "Replica Colab", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }
        finally
        {
            _cts.Dispose(); _cts = null;
            SetBusy(false);
        }
    }

    private void FillGrid(ColabResult r)
    {
        _grid.SuspendLayout();
        _grid.Rows.Clear();
        foreach (var a in r.Analysis)
        {
            int i = _grid.Rows.Add(a.Symbol, a.Name, a.Status,
                a.AprMedio, a.Apr90, a.Apr30, a.AprPicco, a.Volatilita,
                a.Prezzo.ToString("G6", Ci),
                a.Pr1a, a.Pr30, a.Pr7);
            _grid.Rows[i].Cells[2].Style.BackColor = StatusColor(a.Status);
            _grid.Rows[i].Cells[2].Style.ForeColor = Color.Black;
        }
        _grid.ResumeLayout();
    }

    private static Color StatusColor(string s) => s switch
    {
        "OPPORTUNITÀ" => Color.FromArgb(173, 232, 244),
        "ESPLOSA" => Color.FromArgb(255, 179, 179),
        "POMPATA" => Color.FromArgb(255, 214, 165),
        "DELUSA" => Color.FromArgb(214, 197, 245),
        "WATCH" => Color.FromArgb(190, 245, 200),
        "STABILE" => Color.FromArgb(225, 225, 225),
        _ => Color.White
    };

    // ============================================================== Export
    private void ExportAnalysis()
    {
        if (_result == null || _result.Analysis.Count == 0) return;
        using var sfd = new SaveFileDialog { Filter = "CSV (*.csv)|*.csv", FileName = $"colab_analysis_{DateTime.Now:yyyyMMdd_HHmm}.csv" };
        if (sfd.ShowDialog(this) != DialogResult.OK) return;

        var sb = new StringBuilder();
        sb.AppendLine("symbol,name,status,apr_medio,apr_90gg,apr_30gg,apr_picco,volatilita,pr_1a,pr_30gg,pr_7gg,prezzo");
        foreach (var a in _result.Analysis)
            sb.AppendLine(string.Join(",",
                Csv(a.Symbol), Csv(a.Name), Csv(a.Status),
                N(a.AprMedio), N(a.Apr90), N(a.Apr30), N(a.AprPicco), N(a.Volatilita),
                a.Pr1a.HasValue ? N(a.Pr1a.Value) : "", a.Pr30.HasValue ? N(a.Pr30.Value) : "",
                a.Pr7.HasValue ? N(a.Pr7.Value) : "", a.Prezzo.ToString(Ci)));
        WriteFile(sfd.FileName, sb.ToString());
    }

    private void ExportFrame()
    {
        if (_result == null || _result.Frame.ValidCoins == 0) return;
        using var sfd = new SaveFileDialog { Filter = "CSV (*.csv)|*.csv", FileName = $"colab_funding_frame_{DateTime.Now:yyyyMMdd_HHmm}.csv" };
        if (sfd.ShowDialog(this) != DialogResult.OK) return;

        var f = _result.Frame;
        var sb = new StringBuilder();
        // intestazione: symbol + date
        sb.Append("symbol");
        foreach (var d in f.Dates) sb.Append(',').Append(d.ToString("yyyy-MM-dd"));
        sb.AppendLine();
        // una riga per coin (solo coin con almeno un dato, come la heatmap)
        foreach (var kv in f.Rows.Where(r => r.Value.Any(v => v.HasValue)))
        {
            sb.Append(Csv(kv.Key));
            foreach (var v in kv.Value)
                sb.Append(',').Append(v.HasValue ? v.Value.ToString(Ci) : "");
            sb.AppendLine();
        }
        WriteFile(sfd.FileName, sb.ToString());
    }

    private void WriteFile(string path, string content)
    {
        try { File.WriteAllText(path, content, new UTF8Encoding(true)); _status.Text = "Esportato: " + path; }
        catch (Exception ex) { MessageBox.Show(this, ex.Message, "Export", MessageBoxButtons.OK, MessageBoxIcon.Error); }
    }

    private static string N(double v) => v.ToString("0.#", Ci);
    private static string Csv(string s) => s.Contains(',') || s.Contains('"') ? $"\"{s.Replace("\"", "\"\"")}\"" : s;

    // ============================================================== Helper
    private void SetBusy(bool busy)
    {
        _btnRun.Enabled = !busy; _numTopN.Enabled = !busy; _cmbLookback.Enabled = !busy;
        _btnStop.Enabled = busy; _progress.Visible = busy;
        if (busy) { _btnExportAnalysis.Enabled = false; _btnExportFrame.Enabled = false; }
    }

    private void AppendLog(string msg)
    {
        if (_log.InvokeRequired) { _log.BeginInvoke(() => AppendLog(msg)); return; }
        _log.AppendText($"[{DateTime.Now:HH:mm:ss}] {msg}{Environment.NewLine}");
    }

    protected override void OnFormClosing(FormClosingEventArgs e)
    {
        _cts?.Cancel();
        base.OnFormClosing(e);
    }
}
