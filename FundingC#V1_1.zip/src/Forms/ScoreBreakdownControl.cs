using FundingRateScan.Meme;

namespace FundingRateScan.Forms;

/// <summary>
/// Visualizza il contributo di ciascuna dimensione al punteggio meme (cap. 10.1):
/// barre orizzontali per Liquidità, Adozione, Derivati, Sociale, più composito,
/// penalità di rischio e copertura. Le dimensioni senza dati sono mostrate come "n.d.".
/// </summary>
public sealed class ScoreBreakdownControl : Control
{
    private MemeScore? _score;

    private static readonly Color Bg = Color.FromArgb(250, 250, 252);
    private static readonly (string name, Color col)[] Dims =
    {
        ("Liquidità & mercato", Color.FromArgb(46, 117, 182)),
        ("Adozione on-chain", Color.FromArgb(0, 153, 102)),
        ("Derivati (funding/OI)", Color.FromArgb(150, 90, 200)),
        ("Momentum sociale", Color.FromArgb(214, 140, 0)),
    };

    public ScoreBreakdownControl()
    {
        SetStyle(ControlStyles.AllPaintingInWmPaint | ControlStyles.UserPaint
                 | ControlStyles.OptimizedDoubleBuffer | ControlStyles.ResizeRedraw, true);
        BackColor = Bg;
        Font = new Font("Segoe UI", 9f);
    }

    public void SetScore(MemeScore? s) { _score = s; Invalidate(); }

    protected override void OnPaint(PaintEventArgs e)
    {
        var g = e.Graphics;
        g.Clear(Bg);
        if (_score == null)
        {
            TextRenderer.DrawText(g, "Seleziona una coin per vedere la scomposizione del punteggio.",
                Font, ClientRectangle, Color.Gray, TextFormatFlags.HorizontalCenter | TextFormatFlags.VerticalCenter);
            return;
        }

        var s = _score;
        int left = 12, top = 12, barX = 170, barW = Math.Max(80, Width - barX - 70);

        using var titleFont = new Font("Segoe UI", 11f, FontStyle.Bold);
        TextRenderer.DrawText(g, $"{s.Candidate.Symbol}  ·  {s.StateSymbol}", titleFont,
            new Point(left, top), StateColor(s.State));
        top += 26;
        using var subFont = new Font("Segoe UI", 9f);
        TextRenderer.DrawText(g, $"Composito {s.Composite:N0}/100   ·   copertura {s.CoveragePct:N0}%   ·   penalità rischio ×{s.RiskPenalty:N2}",
            subFont, new Point(left, top), Color.DimGray);
        top += 26;

        double?[] vals = { s.Liquidity, s.Adoption, s.Derivatives, s.Social };
        for (int i = 0; i < Dims.Length; i++)
        {
            TextRenderer.DrawText(g, Dims[i].name, Font, new Rectangle(left, top, barX - left - 6, 20),
                Color.Black, TextFormatFlags.Left | TextFormatFlags.VerticalCenter | TextFormatFlags.NoPrefix);
            var track = new Rectangle(barX, top + 2, barW, 16);
            using (var tb = new SolidBrush(Color.FromArgb(228, 230, 236))) g.FillRectangle(tb, track);

            if (vals[i].HasValue)
            {
                int w = (int)(barW * Math.Clamp(vals[i]!.Value, 0, 100) / 100.0);
                using var b = new SolidBrush(Dims[i].col);
                g.FillRectangle(b, new Rectangle(barX, top + 2, w, 16));
                TextRenderer.DrawText(g, $"{vals[i]!.Value:N0}", Font, new Point(barX + barW + 6, top),
                    Dims[i].col, TextFormatFlags.Left);
            }
            else
            {
                TextRenderer.DrawText(g, "n.d.", Font, new Point(barX + 4, top),
                    Color.Gray, TextFormatFlags.Left);
            }
            top += 26;
        }

        top += 6;
        if (s.RiskNotes.Count > 0)
        {
            using var rf = new Font("Segoe UI", 8.5f);
            TextRenderer.DrawText(g, "Rischi: " + string.Join(" · ", s.RiskNotes), rf,
                new Rectangle(left, top, Width - left - 10, 40), Color.Firebrick, TextFormatFlags.WordBreak);
            top += 34;
        }
        if (s.Rationale.Count > 0)
        {
            using var rf = new Font("Segoe UI", 8.5f);
            TextRenderer.DrawText(g, string.Join("\n", s.Rationale), rf,
                new Rectangle(left, top, Width - left - 10, Height - top), Color.DimGray, TextFormatFlags.WordBreak);
        }
    }

    private static Color StateColor(MemeState st) => st switch
    {
        MemeState.AltoPotenziale => Color.FromArgb(0, 130, 60),
        MemeState.Emergente => Color.FromArgb(46, 117, 182),
        MemeState.DaOsservare => Color.FromArgb(120, 120, 120),
        _ => Color.Firebrick
    };
}
