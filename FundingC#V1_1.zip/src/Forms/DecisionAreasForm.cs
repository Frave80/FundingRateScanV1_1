using System.Globalization;
using FundingRateScan.Models;
using FundingRateScan.Services;

namespace FundingRateScan.Forms;

/// <summary>
/// Report "Aree decisionali / Priorità" con tre schede:
///  1. Priorità & Aree (operativa vs accademica);
///  2. Coin da monitorare per alta volatilità attesa;
///  3. Coin più promettenti secondo criteri accademici (modello fattoriale).
/// </summary>
public sealed class DecisionAreasForm : AppForm
{
    private static readonly CultureInfo Ci = CultureInfo.InvariantCulture;

    private readonly List<CoinResult> _results;
    private readonly ScanParameters _params;
    private Label _summary = null!;

    public DecisionAreasForm(IEnumerable<CoinResult> results, ScanParameters parameters)
    {
        _params = parameters;
        _results = results.Where(r => r.Classification != Classification.Neutral).ToList();
        BuildUi();
    }

    private void BuildUi()
    {
        Text = "Aree decisionali / Priorità";
        StartPosition = FormStartPosition.CenterParent;
        ClientSize = new Size(1180, 740);
        MinimumSize = new Size(960, 580);
        Font = new Font("Segoe UI", 9f);

        var tabs = new TabControl { Dock = DockStyle.Fill };
        tabs.TabPages.Add(BuildPriorityTab());
        tabs.TabPages.Add(BuildVolatilityTab());
        tabs.TabPages.Add(BuildAcademicTab());
        Controls.Add(tabs);

        BuildSummary();
    }

    // ================================================== Scheda 1: Priorità & Aree
    private TabPage BuildPriorityTab()
    {
        var tab = new TabPage("Priorità & Aree");
        var grid = MakeGrid();
        AddCol(grid, "Pr.", 38, null);
        AddCol(grid, "Priorità", 70, null);
        AddCol(grid, "Area", 90, null);
        AddCol(grid, "Coin", 60, null);
        AddCol(grid, "Nome", 120, null);
        AddCol(grid, "Vol. attesa", 80, null);
        AddCol(grid, "Funding APR", 90, "N1");
        AddCol(grid, "Persist. %", 75, "N0");
        AddCol(grid, "Δ Vol %", 70, "N1");
        AddCol(grid, "Δ OI %", 65, "N1");
        AddCol(grid, "Consiglio", 360, null);

        var assessed = _results
            .Select(r => (r, a: DecisionAdvisor.Evaluate(r, _params)))
            .OrderBy(x => (int)x.a.Priority)
            .ThenByDescending(x => x.a.VolScore)
            .ThenByDescending(x => x.r.FundingApr)
            .ToList();

        foreach (var (r, a) in assessed)
        {
            int i = grid.Rows.Add((int)a.Priority, a.PriorityLabel, a.Area, r.Base, r.Name, a.VolatilityLabel,
                r.FundingApr, r.PersistencePct, r.VolGrowthPct, r.OiGrowthPct, a.Advice);
            var row = grid.Rows[i];
            row.Tag = r;   // riferimento alla coin per l'apertura della quotazione
            row.DefaultCellStyle.BackColor = a.Priority switch
            {
                DecisionPriority.Alta => Color.FromArgb(214, 245, 214),
                DecisionPriority.Media => Color.FromArgb(255, 248, 222),
                _ => Color.FromArgb(238, 234, 246)
            };
            row.Cells[2].Style.ForeColor = a.IsAcademic ? Color.FromArgb(170, 110, 0) : Color.FromArgb(0, 120, 40);
            row.Cells[2].Style.Font = UiFonts.Bold9;
            HighlightVol(row.Cells[5], a.Volatility);
        }

        // riepilogo globale (usato anche nella barra in basso)
        int alta = assessed.Count(x => x.a.Priority == DecisionPriority.Alta);
        int media = assessed.Count(x => x.a.Priority == DecisionPriority.Media);
        int bassa = assessed.Count(x => x.a.Priority == DecisionPriority.Bassa);
        int oper = assessed.Count(x => !x.a.IsAcademic);
        int acad = assessed.Count(x => x.a.IsAcademic);
        int volAlta = assessed.Count(x => x.a.Volatility == VolExpectation.Alta);
        _summaryText = $"Coin: {assessed.Count}  |  Priorità — Alta {alta} · Media {media} · Bassa {bassa}  |  " +
                       $"Aree — Operativa {oper} · Accademica {acad}  |  Alta volatilità attesa: {volAlta}";

        tab.Controls.Add(grid);
        tab.Controls.Add(BuildHeader());
        return tab;
    }

    private Control BuildHeader()
    {
        var header = new Panel { Dock = DockStyle.Top, Height = 138, Padding = new Padding(10, 6, 10, 6), BackColor = Color.FromArgb(247, 248, 251) };
        var rtb = NewInfoBox();
        void Line(string s, Color c, bool bold = false) { rtb.SelectionColor = c; rtb.SelectionFont = new Font("Segoe UI", 9f, bold ? FontStyle.Bold : FontStyle.Regular); rtb.AppendText(s + "\n"); }
        Line("Come leggere le aree (in ordine di priorità operativa):", Color.Black, true);
        Line("● Area OPERATIVA (più concreta) — funding persistente CONFERMATO da volumi e/o open interest crescenti → priorità Alta o Media.", Color.FromArgb(0, 120, 40));
        Line("○ Area ACCADEMICA (più teorica) — pressione funding persistente SENZA conferma di volumi/OI: tesi probabilistica, non confermata dai flussi → priorità Bassa, sola osservazione.", Color.FromArgb(170, 110, 0));
        Line("⚠ Alta volatilità attesa — leva affollata (funding elevato) e persistente con open interest in aumento: rischio di squeeze / movimenti bruschi.", Color.Firebrick, true);
        header.Controls.Add(rtb);
        return header;
    }

    // ============================================ Scheda 2: Da monitorare (volatilità)
    private TabPage BuildVolatilityTab()
    {
        var tab = new TabPage("Da monitorare (volatilità)");
        var grid = MakeGrid();
        AddCol(grid, "Coin", 60, null);
        AddCol(grid, "Nome", 130, null);
        AddCol(grid, "Vol. attesa", 80, null);
        AddCol(grid, "Indice vol.", 75, "N0");
        AddCol(grid, "Funding APR", 90, "N1");
        AddCol(grid, "Persist. %", 75, "N0");
        AddCol(grid, "Δ OI %", 65, "N1");
        AddCol(grid, "Area", 90, null);
        AddCol(grid, "Perché monitorarla", 380, null);

        var watch = _results
            .Select(r => (r, a: DecisionAdvisor.Evaluate(r, _params)))
            .Where(x => x.a.Volatility != VolExpectation.Bassa)
            .OrderByDescending(x => x.a.VolScore)
            .ToList();

        foreach (var (r, a) in watch)
        {
            int i = grid.Rows.Add(r.Base, r.Name, a.VolatilityLabel, Math.Round(a.VolScore * 100),
                r.FundingApr, r.PersistencePct, r.OiGrowthPct, a.Area, VolReason(r, a));
            var row = grid.Rows[i];
            row.Tag = r;   // riferimento alla coin per l'apertura della quotazione
            HighlightVol(row.Cells[2], a.Volatility);
            if (a.Volatility == VolExpectation.Alta) row.DefaultCellStyle.BackColor = Color.FromArgb(255, 235, 235);
        }

        var intro = NewInfoPanel(110);
        var rtb = (RichTextBox)intro.Controls[0];
        void L(string s, Color c, bool b = false) { rtb.SelectionColor = c; rtb.SelectionFont = new Font("Segoe UI", 9f, b ? FontStyle.Bold : FontStyle.Regular); rtb.AppendText(s + "\n"); }
        L("Coin da monitorare — è attesa grande volatilità.", Color.Black, true);
        L("Criterio: long affollati (funding APR elevato) e persistenti con open interest in aumento = accumulo di leva.", Color.DimGray);
        L("Quando la leva è concentrata, un movimento contrario può innescare liquidazioni a catena (squeeze) e quindi escursioni di prezzo ampie.", Color.DimGray);
        L(watch.Count == 0 ? "Nessuna coin con volatilità attesa rilevante nei parametri attuali." : $"{watch.Count(x => x.a.Volatility == VolExpectation.Alta)} ad alta volatilità · {watch.Count(x => x.a.Volatility == VolExpectation.Media)} a volatilità media.", Color.Firebrick, true);

        tab.Controls.Add(grid);
        tab.Controls.Add(intro);
        return tab;
    }

    private static string VolReason(CoinResult r, DecisionAssessment a)
    {
        string baseTxt = $"Funding APR {r.FundingApr:N0}% persistente al {r.PersistencePct:N0}%";
        if (r.OiGrowthPct > 0) baseTxt += $", open interest +{r.OiGrowthPct:N0}%";
        baseTxt += a.Volatility == VolExpectation.Alta
            ? " → leva molto affollata: alto rischio di squeeze e movimenti bruschi."
            : " → leva in accumulo: possibili escursioni di prezzo.";
        if (a.IsAcademic) baseTxt += " (segnale ancora teorico, non confermato dai flussi)";
        return baseTxt;
    }

    // ============================================ Scheda 3: Più promettenti (accademico)
    private TabPage BuildAcademicTab()
    {
        var tab = new TabPage("Più promettenti (accademico)");
        var grid = MakeGrid();
        AddCol(grid, "#", 34, null);
        AddCol(grid, "Coin", 60, null);
        AddCol(grid, "Nome", 120, null);
        AddCol(grid, "Score /100", 75, "N0");
        AddCol(grid, "z Carry", 65, "N2");
        AddCol(grid, "z Persist.", 70, "N2");
        AddCol(grid, "z OI", 60, "N2");
        AddCol(grid, "z Volume", 70, "N2");
        AddCol(grid, "z Liquid.", 65, "N2");
        AddCol(grid, "Motivazione (fattori dominanti)", 360, null);

        var ranked = AcademicScorer.Rank(_results);
        int rank = 1;
        foreach (var s in ranked)
        {
            int i = grid.Rows.Add(rank++, s.Coin.Base, s.Coin.Name, s.Score0to100,
                s.ZFunding, s.ZPersistence, s.ZOi, s.ZVolume, s.ZLiquidity, s.Rationale);
            var row = grid.Rows[i];
            row.Tag = s.Coin;   // riferimento alla coin per l'apertura della quotazione
            // gradiente: i più promettenti in verde
            if (s.Score0to100 >= 80) row.DefaultCellStyle.BackColor = Color.FromArgb(214, 245, 214);
            else if (s.Score0to100 >= 60) row.DefaultCellStyle.BackColor = Color.FromArgb(235, 248, 235);
            row.Cells[3].Style.Font = UiFonts.Bold9;
        }

        var intro = NewInfoPanel(120);
        var rtb = (RichTextBox)intro.Controls[0];
        void L(string s, Color c, bool b = false) { rtb.SelectionColor = c; rtb.SelectionFont = new Font("Segoe UI", 9f, b ? FontStyle.Bold : FontStyle.Regular); rtb.AppendText(s + "\n"); }
        L("Coin più promettenti — selezione con criteri accademici (modello fattoriale cross-sezionale).", Color.Black, true);
        L("Ogni fattore è standardizzato (z-score) sull'universo delle candidate e combinato con pesi da letteratura sui perpetual futures:", Color.DimGray);
        L("   Carry funding 30% · Persistenza 25% · Momentum Open Interest 20% · Momentum Volume 15% · Liquidità (filtro qualità) 10%.", Color.FromArgb(60, 80, 140));
        L("Lo Score /100 è il rank percentile del composito: 100 = la più forte del gruppo. z>0 = sopra la media del gruppo.", Color.DimGray);
        L("È un punteggio relativo e spiegabile, non una raccomandazione di acquisto.", Color.Firebrick);

        tab.Controls.Add(grid);
        tab.Controls.Add(intro);
        return tab;
    }

    // ================================================================= Helper UI
    private string _summaryText = "";

    private void BuildSummary()
    {
        _summary = new Label
        {
            Dock = DockStyle.Bottom, Height = 28, TextAlign = ContentAlignment.MiddleLeft,
            Padding = new Padding(12, 0, 0, 0), BackColor = Color.FromArgb(17, 24, 39), ForeColor = Color.Gainsboro,
            Font = new Font("Consolas", 9.5f), Text = _summaryText
        };
        Controls.Add(_summary);
    }

    private DataGridView MakeGrid()
    {
        var grid = new DataGridView
        {
            Dock = DockStyle.Fill, ReadOnly = true, AllowUserToAddRows = false, RowHeadersVisible = false,
            AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill, SelectionMode = DataGridViewSelectionMode.FullRowSelect,
            MultiSelect = false, BackgroundColor = SystemColors.Window, BorderStyle = BorderStyle.None, EnableHeadersVisualStyles = false,
            ColumnHeadersDefaultCellStyle = { BackColor = Color.FromArgb(40, 44, 60), ForeColor = Color.White, Font = UiFonts.Bold9 }
        };
        // Doppio clic su una riga → apre la quotazione della coin (Tag = CoinResult).
        // Coin del funding scanner: CoinMarketCap con ripiego TradingView (o DEX Screener
        // per quelle senza perpetuo di riferimento).
        grid.CellDoubleClick += (_, e) =>
        {
            if (e.RowIndex < 0 || grid.Rows[e.RowIndex].Tag is not CoinResult r) return;
            bool preferDex = r.Source == "Colab" || string.IsNullOrWhiteSpace(r.RepresentativeSymbol);
            _ = Services.QuoteLinks.OpenSymbolAsync(r.Base, r.Name, preferDex,
                new Progress<string>(s => _summary.Text = s), CancellationToken.None);
        };
        return grid;
    }

    private static void AddCol(DataGridView g, string h, int w, string? fmt)
    {
        var c = new DataGridViewTextBoxColumn { HeaderText = h, FillWeight = w };
        if (fmt != null)
        {
            c.DefaultCellStyle.Format = fmt;
            c.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            c.DefaultCellStyle.FormatProvider = Ci;
        }
        g.Columns.Add(c);
    }

    private static void HighlightVol(DataGridViewCell cell, VolExpectation v)
    {
        if (v == VolExpectation.Alta)
        {
            cell.Style.ForeColor = Color.White;
            cell.Style.BackColor = Color.Firebrick;
            cell.Style.Font = UiFonts.Bold9;
        }
        else if (v == VolExpectation.Media)
            cell.Style.ForeColor = Color.FromArgb(180, 90, 0);
    }

    private static Panel NewInfoPanel(int height)
    {
        var p = new Panel { Dock = DockStyle.Top, Height = height, Padding = new Padding(10, 6, 10, 6), BackColor = Color.FromArgb(247, 248, 251) };
        p.Controls.Add(NewInfoBox());
        return p;
    }

    private static RichTextBox NewInfoBox() => new()
    {
        Dock = DockStyle.Fill, ReadOnly = true, BorderStyle = BorderStyle.None,
        BackColor = Color.FromArgb(247, 248, 251), Font = new Font("Segoe UI", 9f)
    };
}
