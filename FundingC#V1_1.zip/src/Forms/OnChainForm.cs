using System.Globalization;
using FundingRateScan.Models;
using FundingRateScan.Services;
using FundingRateScan.OnChain.Models;
using FundingRateScan.OnChain.Providers;
using FundingRateScan.OnChain.Services;

namespace FundingRateScan.Forms;

/// <summary>
/// OnChain Capital Flow Monitor: traccia trasferimenti, whale wallet, top holder e
/// grandi movimenti in USD di un token, con scoring esplicabile correlato al funding.
/// </summary>
public sealed class OnChainForm : AppForm
{
    private static readonly CultureInfo Ci = CultureInfo.InvariantCulture;

    private readonly AppSettings _settings;
    private OnChainSettings S => _settings.OnChain;
    private CancellationTokenSource? _cts;

    private ComboBox _cmbChain = null!;
    private TextBox _txtContract = null!, _txtSymbol = null!, _log = null!;
    private NumericUpDown _numWhale = null!, _numMillionaire = null!;
    private Button _btnSync = null!, _btnStop = null!, _btnSettings = null!;
    private Label _scoreBanner = null!;
    private ToolStripProgressBar _progress = null!;

    private DataGridView _gridMoves = null!, _gridHolders = null!, _gridWindows = null!, _gridAlerts = null!;
    private Label _ctxMarket = null!, _ctxFunding = null!, _ctxHolders = null!;
    private TextBox _reasons = null!;
    private ComboBox _cmbSeverity = null!;
    private List<WhaleAlert> _alerts = new();

    public OnChainForm(AppSettings settings, string? prefillSymbol = null)
    {
        _settings = settings;
        BuildUi();
        LoadDefaults(prefillSymbol);
    }

    // ====================================================================== UI
    private void BuildUi()
    {
        Text = "OnChain Capital Flow Monitor";
        StartPosition = FormStartPosition.CenterParent;
        ClientSize = new Size(1180, 760);
        MinimumSize = new Size(960, 620);
        Font = new Font("Segoe UI", 9f);

        BuildTabs();        // Fill
        BuildScoreBanner(); // Top
        BuildInputPanel();  // Top
        BuildLog();         // Bottom
        BuildStatusBar();   // Bottom
    }

    private void BuildInputPanel()
    {
        var p = new Panel { Dock = DockStyle.Top, Height = 76, Padding = new Padding(8, 6, 8, 4) };

        var lblChain = new Label { Text = "Chain:", Location = new Point(8, 12), AutoSize = true };
        _cmbChain = new ComboBox { Location = new Point(56, 8), Size = new Size(130, 24), DropDownStyle = ComboBoxStyle.DropDownList };
        foreach (var c in ChainCatalog.Chains) _cmbChain.Items.Add(c.Display);
        _cmbChain.SelectedIndex = 0;

        var lblContract = new Label { Text = "Contract address:", Location = new Point(200, 12), AutoSize = true };
        _txtContract = new TextBox { Location = new Point(310, 8), Size = new Size(380, 24) };
        _txtContract.PlaceholderText = "0x... indirizzo del token";

        var lblSym = new Label { Text = "Simbolo (funding):", Location = new Point(710, 12), AutoSize = true };
        _txtSymbol = new TextBox { Location = new Point(826, 8), Size = new Size(90, 24) };
        _txtSymbol.PlaceholderText = "es. PEPE";

        var lblWhale = new Label { Text = "Whale ≥ USD:", Location = new Point(8, 46), AutoSize = true };
        _numWhale = new NumericUpDown { Location = new Point(94, 42), Size = new Size(110, 24), Minimum = 1000, Maximum = 100_000_000, Increment = 50_000, ThousandsSeparator = true };

        var lblMil = new Label { Text = "Milionario ≥ USD:", Location = new Point(220, 46), AutoSize = true };
        _numMillionaire = new NumericUpDown { Location = new Point(330, 42), Size = new Size(120, 24), Minimum = 1000, Maximum = 1_000_000_000, Increment = 100_000, ThousandsSeparator = true };

        _btnSync = new Button { Text = "Sincronizza", Location = new Point(470, 41), Size = new Size(110, 28) };
        _btnSync.Click += (_, _) => RunSync();
        _btnStop = new Button { Text = "Interrompi", Location = new Point(586, 41), Size = new Size(90, 28), Enabled = false };
        _btnStop.Click += (_, _) => _cts?.Cancel();
        _btnSettings = new Button { Text = "Impostazioni provider...", Location = new Point(686, 41), Size = new Size(160, 28) };
        _btnSettings.Click += (_, _) => OpenSettings();

        p.Controls.AddRange(new Control[] { lblChain, _cmbChain, lblContract, _txtContract, lblSym, _txtSymbol,
            lblWhale, _numWhale, lblMil, _numMillionaire, _btnSync, _btnStop, _btnSettings });
        Controls.Add(p);
    }

    private void BuildScoreBanner()
    {
        _scoreBanner = new Label
        {
            Dock = DockStyle.Top,
            Height = 40,
            TextAlign = ContentAlignment.MiddleLeft,
            Padding = new Padding(12, 0, 0, 0),
            Font = new Font("Segoe UI", 11f, FontStyle.Bold),
            BackColor = Color.FromArgb(245, 246, 250),
            Text = "Punteggio flusso: —",
            Cursor = Cursors.Hand   // cliccabile: apre la quotazione del token monitorato
        };
        // Clic sul banner → apre il token monitorato su DEX Screener (è un token on-chain "nuovo").
        _scoreBanner.Click += (_, _) =>
        {
            var contract = _txtContract.Text.Trim();
            if (contract.Length > 0) Services.QuoteLinks.OpenDexSearch(contract);
        };
        Controls.Add(_scoreBanner);
    }

    private void BuildTabs()
    {
        var tabs = new TabControl { Dock = DockStyle.Fill };

        // Movimenti rilevanti
        var t1 = new TabPage("Movimenti rilevanti");
        _gridMoves = MakeGrid();
        AddCols(_gridMoves, ("Ora", 90), ("USD", 90), ("Quantità", 100), ("Tipo", 100), ("Evidenza", 90),
            ("From", 120), ("Etichetta", 90), ("To", 120), ("Etichetta ", 90), ("Tx", 110));
        t1.Controls.Add(_gridMoves);
        tabs.TabPages.Add(t1);

        // Whale wallet
        var t2 = new TabPage("Whale wallet");
        _gridHolders = MakeGrid();
        AddCols(_gridHolders, ("#", 36), ("Address", 200), ("Tipo", 110), ("Quota %", 80),
            ("Saldo token", 130), ("Valore USD", 130), ("Etichetta", 140));
        t2.Controls.Add(_gridHolders);
        tabs.TabPages.Add(t2);

        // Net flow + scoring
        var t3 = new TabPage("Net flow & score");
        t3.Controls.Add(BuildNetFlowTab());
        tabs.TabPages.Add(t3);

        // Alert
        var t4 = new TabPage("Alert");
        t4.Controls.Add(BuildAlertTab());
        tabs.TabPages.Add(t4);

        Controls.Add(tabs);
    }

    private Control BuildNetFlowTab()
    {
        var host = new Panel { Dock = DockStyle.Fill };

        _gridWindows = MakeGrid();
        _gridWindows.Dock = DockStyle.Top;
        _gridWindows.Height = 170;
        AddCols(_gridWindows, ("Finestra", 90), ("Net In USD", 110), ("Net Out USD", 110),
            ("CEX In", 110), ("CEX Out", 110), ("Whale Buy", 110), ("Whale Sell", 110), ("# Whale", 70));

        var ctx = new Panel { Dock = DockStyle.Top, Height = 96, Padding = new Padding(10, 6, 10, 6) };
        _ctxMarket = new Label { Location = new Point(10, 6), AutoSize = true };
        _ctxFunding = new Label { Location = new Point(10, 34), AutoSize = true };
        _ctxHolders = new Label { Location = new Point(10, 62), AutoSize = true };
        ctx.Controls.AddRange(new Control[] { _ctxMarket, _ctxFunding, _ctxHolders });

        var lblR = new Label { Dock = DockStyle.Top, Height = 22, Text = "Motivazioni del punteggio:", Font = new Font("Segoe UI", 9f, FontStyle.Bold), Padding = new Padding(10, 2, 0, 0) };
        _reasons = new TextBox { Dock = DockStyle.Fill, Multiline = true, ReadOnly = true, ScrollBars = ScrollBars.Vertical, BackColor = Color.White, Font = new Font("Consolas", 9.5f) };

        host.Controls.Add(_reasons);
        host.Controls.Add(lblR);
        host.Controls.Add(ctx);
        host.Controls.Add(_gridWindows);
        return host;
    }

    private Control BuildAlertTab()
    {
        var host = new Panel { Dock = DockStyle.Fill };

        var bar = new Panel { Dock = DockStyle.Top, Height = 34, Padding = new Padding(8, 5, 8, 4) };
        var lbl = new Label { Text = "Severità:", Location = new Point(8, 8), AutoSize = true };
        _cmbSeverity = new ComboBox { Location = new Point(66, 4), Size = new Size(140, 24), DropDownStyle = ComboBoxStyle.DropDownList };
        _cmbSeverity.Items.AddRange(new object[] { "Tutte", "Low+", "Medium+", "High+", "Critical" });
        _cmbSeverity.SelectedIndex = 0;
        _cmbSeverity.SelectedIndexChanged += (_, _) => FillAlerts();
        bar.Controls.Add(lbl); bar.Controls.Add(_cmbSeverity);

        _gridAlerts = MakeGrid();
        AddCols(_gridAlerts, ("Ora", 130), ("Severità", 80), ("Titolo", 240), ("Descrizione", 420), ("Score", 60), ("Tx", 110));

        host.Controls.Add(_gridAlerts);
        host.Controls.Add(bar);
        return host;
    }

    private void BuildLog()
    {
        _log = new TextBox
        {
            Dock = DockStyle.Bottom, Multiline = true, ReadOnly = true, Height = 90,
            ScrollBars = ScrollBars.Vertical, BackColor = Color.FromArgb(20, 22, 30),
            ForeColor = Color.Gainsboro, Font = new Font("Consolas", 9f)
        };
        Controls.Add(_log);
    }

    private void BuildStatusBar()
    {
        var strip = new StatusStrip();
        var lblHost = new ToolStripStatusLabel { Spring = true, TextAlign = ContentAlignment.MiddleLeft };
        _progress = new ToolStripProgressBar { Style = ProgressBarStyle.Marquee, Visible = false, Width = 150 };
        strip.Items.Add(lblHost);
        strip.Items.Add(_progress);
        _statusLabel = lblHost;
        Controls.Add(strip);
    }
    private ToolStripStatusLabel _statusLabel = null!;

    private static DataGridView MakeGrid() => new()
    {
        Dock = DockStyle.Fill,
        ReadOnly = true,
        AllowUserToAddRows = false,
        RowHeadersVisible = false,
        AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill,
        SelectionMode = DataGridViewSelectionMode.FullRowSelect,
        MultiSelect = false,
        BackgroundColor = SystemColors.Window,
        BorderStyle = BorderStyle.None,
    };

    private static void AddCols(DataGridView g, params (string h, int w)[] cols)
    {
        foreach (var (h, w) in cols)
            g.Columns.Add(new DataGridViewTextBoxColumn { HeaderText = h, FillWeight = w });
    }

    // ================================================================ Logica
    private void LoadDefaults(string? prefillSymbol)
    {
        var ci = ChainCatalog.Get(S.DefaultChain);
        int idx = ChainCatalog.Chains.ToList().FindIndex(c => c.Key == ci.Key);
        if (idx >= 0) _cmbChain.SelectedIndex = idx;

        _txtContract.Text = S.LastTokenAddress;
        _txtSymbol.Text = prefillSymbol ?? S.LastSymbol;
        _numWhale.Value = Math.Clamp(S.WhaleUsdThreshold, _numWhale.Minimum, _numWhale.Maximum);
        _numMillionaire.Value = Math.Clamp(S.MillionaireWalletUsdThreshold, _numMillionaire.Minimum, _numMillionaire.Maximum);
    }

    private void OpenSettings()
    {
        using var dlg = new OnChainSettingsForm(S);
        if (dlg.ShowDialog(this) == DialogResult.OK)
        {
            SettingsManager.Save(_settings);
            _numWhale.Value = Math.Clamp(S.WhaleUsdThreshold, _numWhale.Minimum, _numWhale.Maximum);
            _numMillionaire.Value = Math.Clamp(S.MillionaireWalletUsdThreshold, _numMillionaire.Minimum, _numMillionaire.Maximum);
        }
    }

    private async void RunSync()
    {
        var contract = _txtContract.Text.Trim();
        if (!contract.StartsWith("0x") || contract.Length != 42)
        {
            MessageBox.Show(this, "Inserisci un contract address EVM valido (0x... 42 caratteri).",
                "OnChain", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            return;
        }
        if (_cts != null) return;

        var chain = ChainCatalog.Chains[_cmbChain.SelectedIndex];
        var cfg = new TokenMonitorConfig
        {
            ChainKey = chain.Key,
            ChainId = chain.ChainId,
            TokenAddress = contract.ToLowerInvariant(),
            Symbol = _txtSymbol.Text.Trim(),
            WhaleUsdThreshold = _numWhale.Value,
            MillionaireUsdThreshold = _numMillionaire.Value,
            MaxTransfers = S.MaxTransfers,
            TopHolders = S.TopHolders,
            AlertMinScore = S.AlertMinScore,
            Windows = S.TrackWindowsMinutes,
        };

        // Persisti scelte
        S.DefaultChain = chain.Key;
        S.LastTokenAddress = cfg.TokenAddress;
        S.LastSymbol = cfg.Symbol;
        S.WhaleUsdThreshold = cfg.WhaleUsdThreshold;
        S.MillionaireWalletUsdThreshold = cfg.MillionaireUsdThreshold;
        SettingsManager.Save(_settings);

        _cts = new CancellationTokenSource();
        SetBusy(true);
        _log.Clear();

        var progress = new Progress<string>(AppendLog);
        var monitor = new OnChainMonitor(S);

        try
        {
            SetStatus("Sincronizzazione on-chain in corso...");
            var result = await monitor.RunAsync(cfg, progress, _cts.Token);
            Populate(result);
            SetStatus($"Completato — {result.Transfers.Count} trasferimenti, {result.Holders.Count} holder, punteggio {result.Signal.Score} ({result.Signal.Bias}).");
        }
        catch (OperationCanceledException)
        {
            SetStatus("Interrotto.");
            AppendLog("** Interrotto **");
        }
        catch (Exception ex)
        {
            SetStatus("Errore.");
            AppendLog("ERRORE: " + ex.Message);
            MessageBox.Show(this, ex.Message, "OnChain", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }
        finally
        {
            _cts.Dispose(); _cts = null;
            SetBusy(false);
        }
    }

    private void Populate(OnChainResult r)
    {
        // Banner punteggio
        _scoreBanner.Text = $"Punteggio flusso: {r.Signal.Score}   ·   {r.Signal.Bias}";
        _scoreBanner.BackColor = r.Signal.Score switch
        {
            >= 25 => Color.FromArgb(214, 245, 214),
            >= 10 => Color.FromArgb(230, 245, 230),
            <= -10 => Color.FromArgb(250, 222, 222),
            _ => Color.FromArgb(245, 246, 250)
        };

        // Movimenti
        _gridMoves.Rows.Clear();
        foreach (var t in r.Transfers.OrderByDescending(x => x.AmountUsd).Take(400))
        {
            int i = _gridMoves.Rows.Add(
                t.TimestampUtc.ToLocalTime().ToString("dd/MM HH:mm"),
                t.AmountUsd.ToString("N0", Ci),
                t.TokenAmount.ToString("N2", Ci),
                EventText(t.EventType),
                Evidence(t),
                Short(t.FromAddress), t.FromLabel,
                Short(t.ToAddress), t.ToLabel,
                Short(t.TxHash));
            if (t.IsWhaleMovement) _gridMoves.Rows[i].DefaultCellStyle.BackColor = Color.FromArgb(255, 244, 222);
            if (t.EventType == OnChainEventType.CexDeposit) _gridMoves.Rows[i].DefaultCellStyle.ForeColor = Color.Firebrick;
            else if (t.EventType == OnChainEventType.CexWithdrawal) _gridMoves.Rows[i].DefaultCellStyle.ForeColor = Color.SeaGreen;
        }

        // Holder
        _gridHolders.Rows.Clear();
        int rank = 1;
        foreach (var h in r.Holders.OrderByDescending(x => x.SharePct))
        {
            int i = _gridHolders.Rows.Add(rank++, h.Address, WalletTypeText(h.Type),
                h.SharePct.ToString("N2", Ci),
                h.Balance.ToString("N0", Ci),
                h.ValueUsd.ToString("N0", Ci),
                h.Label);
            if (h.ValueUsd >= r.Token.PriceUsd * 0 && h.ValueUsd >= (decimal)_numMillionaire.Value)
                _gridHolders.Rows[i].Cells[5].Style.ForeColor = Color.DarkGreen;
        }

        // Finestre
        _gridWindows.Rows.Clear();
        foreach (var w in r.Windows)
            _gridWindows.Rows.Add(WindowText(w.WindowMinutes),
                w.NetInflowUsd.ToString("N0", Ci), w.NetOutflowUsd.ToString("N0", Ci),
                w.CexInUsd.ToString("N0", Ci), w.CexOutUsd.ToString("N0", Ci),
                w.WhaleBuyUsd.ToString("N0", Ci), w.WhaleSellUsd.ToString("N0", Ci),
                w.WhaleMovements);

        // Contesto
        _ctxMarket.Text = $"Mercato: prezzo {r.Market.PriceUsd.ToString("G6", Ci)} USD · var 24h {r.Market.PriceChange24h:N1}% · liquidità {r.Market.LiquidityUsd:N0} USD · volume 24h {r.Market.Volume24hUsd:N0} USD";
        _ctxFunding.Text = r.Funding.Available
            ? $"Funding: {r.Funding.Apr:N1}% APR (rate {(r.Funding.Rate8h * 100):N4}% / 8h)"
            : "Funding: non disponibile per questo simbolo (inserisci il simbolo del perpetuo).";
        _ctxHolders.Text = $"Holder: nuovi wallet milionari {r.Flow.NewMillionaireWallets} · variazione quota top 10 {r.Flow.Top10HolderShareChangePct:N2} pp";

        _reasons.Text = string.Join(Environment.NewLine, r.Signal.Reasons);

        // Alert
        _alerts = r.Alerts;
        FillAlerts();
    }

    private void FillAlerts()
    {
        if (_gridAlerts == null) return;
        int minSev = _cmbSeverity.SelectedIndex;  // 0=tutte,1=Low+,2=Medium+,3=High+,4=Critical
        _gridAlerts.Rows.Clear();
        foreach (var a in _alerts.Where(a => (int)a.Severity + 1 >= minSev || minSev == 0)
                                  .OrderByDescending(a => a.CreatedAtUtc))
        {
            int i = _gridAlerts.Rows.Add(
                a.CreatedAtUtc.ToLocalTime().ToString("dd/MM/yyyy HH:mm"),
                a.Severity.ToString(), a.Title, a.Description, a.Score, Short(a.TxHash ?? ""));
            _gridAlerts.Rows[i].DefaultCellStyle.BackColor = a.Severity switch
            {
                AlertSeverity.Critical => Color.FromArgb(250, 214, 214),
                AlertSeverity.High => Color.FromArgb(255, 230, 214),
                AlertSeverity.Medium => Color.FromArgb(255, 248, 222),
                _ => Color.White
            };
        }
    }

    // ================================================================ Helper
    private void SetBusy(bool busy)
    {
        _btnSync.Enabled = !busy; _btnSettings.Enabled = !busy;
        _btnStop.Enabled = busy; _progress.Visible = busy;
    }

    private void AppendLog(string msg)
    {
        if (_log.InvokeRequired) { _log.BeginInvoke(() => AppendLog(msg)); return; }
        _log.AppendText($"[{DateTime.Now:HH:mm:ss}] {msg}{Environment.NewLine}");
    }

    private void SetStatus(string s)
    {
        if (InvokeRequired) { BeginInvoke(() => _statusLabel.Text = s); return; }
        _statusLabel.Text = s;
    }

    protected override void OnFormClosing(FormClosingEventArgs e)
    {
        _cts?.Cancel();
        SettingsManager.Save(_settings);
        base.OnFormClosing(e);
    }

    private static string Short(string a)
        => a.Length >= 12 ? $"{a[..6]}…{a[^4..]}" : a;

    private static string Evidence(TokenTransferEvent t)
    {
        var parts = new List<string>();
        if (t.IsWhaleMovement) parts.Add("🐋");
        if (t.IsExchangeRelated) parts.Add("CEX");
        if (t.ToType == WalletType.LiquidityPool || t.FromType == WalletType.LiquidityPool) parts.Add("LP");
        if (t.IsMillionaireWalletMove) parts.Add("💰");
        return string.Join(" ", parts);
    }

    private static string EventText(OnChainEventType e) => e switch
    {
        OnChainEventType.CexDeposit => "Deposito CEX",
        OnChainEventType.CexWithdrawal => "Prelievo CEX",
        OnChainEventType.SwapBuy => "Acquisto DEX",
        OnChainEventType.SwapSell => "Vendita DEX",
        OnChainEventType.Mint => "Mint",
        OnChainEventType.Burn => "Burn",
        _ => "Trasferimento"
    };

    private static string WalletTypeText(WalletType t) => t switch
    {
        WalletType.Exchange => "Exchange",
        WalletType.LiquidityPool => "Liquidity Pool",
        WalletType.Treasury => "Treasury",
        WalletType.Contract => "Contract",
        WalletType.KnownWhale => "Whale nota",
        WalletType.UnknownWhale => "Whale",
        WalletType.SmartMoney => "Smart money",
        WalletType.MarketMaker => "Market maker",
        WalletType.Bridge => "Bridge",
        WalletType.Burn => "Mint/Burn",
        _ => "Sconosciuto"
    };

    private static string WindowText(int min) => min switch
    {
        5 => "5 min", 60 => "1 ora", 240 => "4 ore", 1440 => "24 ore", 10080 => "7 giorni",
        _ => $"{min} min"
    };
}
