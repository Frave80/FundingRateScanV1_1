namespace FundingRateScan.Forms;

/// <summary>
/// Classe base comune a tutte le finestre dell'applicazione. Centralizza due
/// comportamenti richiesti per l'esperienza d'uso:
///
/// 1. APERTURA A PIENO SCHERMO — le finestre ridimensionabili si aprono
///    massimizzate, così l'utente vede subito tutti i dati; può poi ripristinarle
///    o ridimensionarle liberamente. I piccoli dialoghi a dimensione fissa
///    (FormBorderStyle.FixedDialog/FixedSingle) restano alla loro dimensione,
///    perché pensati per una sola schermata di parametri.
///
/// 2. PRIMO PIANO ALL'ATTIVAZIONE — con più finestre non modali aperte e
///    sovrapposte, selezionarne una la porta sempre davanti alle altre, evitando
///    che resti nascosta sotto un'altra finestra.
///
/// Mettendo la logica nel costruttore (via eventi) anziché in override, le
/// finestre derivate che sovrascrivono OnLoad non rischiano di bypassarla.
/// </summary>
public class AppForm : Form
{
    protected AppForm()
    {
        StartPosition = FormStartPosition.CenterScreen;
        Load += OnAppFormLoad;
        Activated += OnAppFormActivated;
    }

    private void OnAppFormLoad(object? sender, EventArgs e)
    {
        bool resizable = FormBorderStyle is FormBorderStyle.Sizable
                                          or FormBorderStyle.SizableToolWindow;
        if (resizable && WindowState == FormWindowState.Normal)
            WindowState = FormWindowState.Maximized;
    }

    private void OnAppFormActivated(object? sender, EventArgs e)
    {
        // Porta in primo piano la finestra appena selezionata (utile quando più
        // finestre non modali sono sovrapposte). Innocuo per i dialoghi modali.
        if (Visible && !IsDisposed)
            BringToFront();
    }
}
