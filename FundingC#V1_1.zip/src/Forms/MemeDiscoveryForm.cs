using System.Globalization;
using FundingRateScan.Gems;
using FundingRateScan.Meme;
using FundingRateScan.Models;
using FundingRateScan.Services;

namespace FundingRateScan.Forms;

/// <summary>
/// Scoperta meme coin ad alto potenziale (Parte II del documento). Riusa la pipeline
/// gemme (DEX Screener + arricchimento sicurezza) come fonte segnali e calcola il
/// punteggio composito a 4 dimensioni con stato meme e copertura. Non modifica
/// ScanService né i client esistenti.
/// </summary>
public sealed class MemeDiscoveryForm : AppForm
{
    private static readonly CultureInfo Ci = CultureInfo.InvariantCulture;

    private readonly AppSettings _settings;
    private MemeScoringSettings S => _settings.MemeScoring;
    private CancellationTokenSource? _cts;

    private NumericUpDown _numMaxMcap = null!, _numMinLiq = null!, _numMaxAge = null!;
    private Button _btnRun = null!, _btnStop = null!;
    private DataGridView _grid = null!;
    private ScoreBreakdownControl _breakdown = null!;
    private TextBox _log = null!;
    private ToolStripStatusLabel _status = null!;
    private ToolStripProgressBar _progress = null!;

    public MemeDiscoveryForm(AppSettings settings)
    {
        _settings = settings;
        BuildUi();
    }

    private void BuildUi()
    {
        Text = "Scoperta meme coin ad alto potenziale";
        StartPosition = FormStartPosition.CenterParent;
        ClientSize = new Size(1280, 760);
        MinimumSize = new Size(1040, 600);
        Font = new Font("Segoe UI", 9f);
        WindowState = FormWindowState.Maximized;   // la finestra si apre a tutto schermo

        BuildSplit();       // Fill
        BuildIntro();       // Top
        BuildFilters();     // Top
        BuildLog();         // Bottom
        BuildStatusBar();   // Bottom
    }

    private void BuildFilters()
    {
        var p = new Panel { Dock = DockStyle.Top, Height = 44, Padding = new Padding(8, 7, 8, 6) };
        var lblMc = new Label { Text = "Max market cap $:", Location = new Point(8, 11), AutoSize = true };
        _numMaxMcap = Num(120, 8, 100_000, 1_000_000_000, 500_000, (decimal)S.MaxMarketCapUsd);
        var lblLiq = new Label { Text = "Min liquidità $:", Location = new Point(266, 11), AutoSize = true };
        _numMinLiq = Num(360, 8, 0, 100_000_000, 5_000, 20_000);
        var lblAge = new Label { Text = "Max età (g):", Location = new Point(496, 11), AutoSize = true };
        _numMaxAge = Num(572, 8, 0, 365, 1, 30); _numMaxAge.ThousandsSeparator = false;

        // Spaziatura uniforme: lo stesso intervallo (gap) separa "Max età" da "Scopri e
        // valuta", "Scopri e valuta" da "Interrompi" e "Interrompi" dalle impostazioni.
        const int gap = 8;
        _btnRun = new Button { Text = "Scopri e valuta", Location = new Point(_numMaxAge.Right + gap, 6), Size = new Size(130, 28) };
        _btnRun.Click += (_, _) => Run();
        _btnStop = new Button { Text = "Interrompi", Location = new Point(_btnRun.Right + gap, 6), Size = new Size(90, 28), Enabled = false };
        _btnStop.Click += (_, _) => _cts?.Cancel();
        var btnSettings = new Button { Text = "Impostazioni punteggio...", Location = new Point(_btnStop.Right + gap, 6), Size = new Size(170, 28) };
        btnSettings.Click += (_, _) => OpenScoringSettings();

        p.Controls.AddRange(new Control[] { lblMc, _numMaxMcap, lblLiq, _numMinLiq, lblAge, _numMaxAge, _btnRun, _btnStop, btnSettings });
        Controls.Add(p);
    }

    private NumericUpDown Num(int x, int y, decimal min, decimal max, decimal inc, decimal val)
        => new() { Location = new Point(x, y), Size = new Size(130, 24), Minimum = min, Maximum = max, Increment = inc, Value = Math.Clamp(val, min, max), ThousandsSeparator = true };

    private void OpenScoringSettings()
    {
        using var dlg = new MemeScoringSettingsForm(S);
        if (dlg.ShowDialog(this) == DialogResult.OK)
        {
            SettingsManager.Save(_settings);
            _numMaxMcap.Value = Math.Clamp((decimal)S.MaxMarketCapUsd, _numMaxMcap.Minimum, _numMaxMcap.Maximum);
        }
    }

    private void BuildIntro()
    {
        var lbl = new Label
        {
            Dock = DockStyle.Top, Height = 22, TextAlign = ContentAlignment.MiddleLeft, Padding = new Padding(10, 0, 0, 0),
            UseMnemonic = false,
            BackColor = Color.FromArgb(247, 248, 251), ForeColor = Color.DimGray, Font = new Font("Segoe UI", 8.5f),
            Text = "Punteggio composito: Liquidità & mercato 30% · Adozione on-chain 30% · Derivati 25% · Momentum sociale 15%, × penalità di rischio. Le dimensioni senza dati sono escluse (vedi copertura)."
        };
        Controls.Add(lbl);
    }

    private void BuildSplit()
    {
        var split = new SplitContainer { Dock = DockStyle.Fill, Orientation = Orientation.Vertical, SplitterDistance = 880 };
        _grid = new DataGridView
        {
            Dock = DockStyle.Fill, ReadOnly = true, AllowUserToAddRows = false, RowHeadersVisible = false,
            AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill, SelectionMode = DataGridViewSelectionMode.FullRowSelect,
            MultiSelect = false, BackgroundColor = SystemColors.Window, BorderStyle = BorderStyle.None, EnableHeadersVisualStyles = false
        };
        _grid.ColumnHeadersDefaultCellStyle.BackColor = Color.FromArgb(40, 44, 60);
        _grid.ColumnHeadersDefaultCellStyle.ForeColor = Color.White;
        _grid.ColumnHeadersDefaultCellStyle.Font = UiFonts.Bold9;

        AddCol("Stato meme", 110, null);
        AddCol("Coin", 60, null);
        AddCol("Nome", 110, null);
        AddCol("Score", 55, "N0");
        AddCol("Liq&Mkt", 60, "N0");
        AddCol("Adoz.", 55, "N0");
        AddCol("Deriv.", 55, "N0");
        AddCol("Social", 55, "N0");
        AddCol("Copert.%", 60, "N0");
        AddCol("Rischio×", 60, "N2");
        AddCol("Età g", 50, "N1");
        AddCol("Market Cap", 90, "N0");

        // Colonna watchlist « ★ »: salva permanentemente la coin meme scelta.
        WatchlistColumn.Attach(_grid, WatchFromRow);

        _grid.SelectionChanged += (_, _) =>
        {
            if (_grid.CurrentRow?.Tag is MemeScore ms) _breakdown.SetScore(ms);
        };
        // Doppio clic → apre la quotazione. Le coin meme sono token nuovi on-chain:
        // si apre direttamente la pagina DEX Screener del pair (o la ricerca per contratto).
        _grid.CellDoubleClick += (_, e) =>
        {
            if (e.RowIndex < 0 || _grid.Rows[e.RowIndex].Tag is not MemeScore ms) return;
            if (!string.IsNullOrWhiteSpace(ms.Candidate.Url)) Services.QuoteLinks.OpenDex(ms.Candidate.Url);
            else Services.QuoteLinks.OpenDexSearch(ms.Candidate.TokenAddress);
        };
        split.Panel1.Controls.Add(_grid);

        _breakdown = new ScoreBreakdownControl { Dock = DockStyle.Fill };
        split.Panel2.Controls.Add(_breakdown);

        Controls.Add(split);
    }

    private void AddCol(string h, int w, string? fmt)
    {
        var c = new DataGridViewTextBoxColumn { HeaderText = h, FillWeight = w };
        if (fmt != null) { c.DefaultCellStyle.Format = fmt; c.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight; c.DefaultCellStyle.FormatProvider = Ci; }
        _grid.Columns.Add(c);
    }

    private void BuildLog()
    {
        _log = new TextBox
        {
            Dock = DockStyle.Bottom, Multiline = true, ReadOnly = true, Height = 86, ScrollBars = ScrollBars.Vertical,
            BackColor = Color.FromArgb(20, 22, 30), ForeColor = Color.Gainsboro, Font = new Font("Consolas", 9f)
        };
        Controls.Add(_log);
    }

    private void BuildStatusBar()
    {
        var strip = new StatusStrip();
        _status = new ToolStripStatusLabel { Spring = true, TextAlign = ContentAlignment.MiddleLeft };
        _progress = new ToolStripProgressBar { Style = ProgressBarStyle.Marquee, Visible = false, Width = 150 };
        strip.Items.Add(_status); strip.Items.Add(_progress);
        Controls.Add(strip);
    }

    private async void Run()
    {
        if (_cts != null) return;
        S.MaxMarketCapUsd = (double)_numMaxMcap.Value;
        SettingsManager.Save(_settings);

        var filter = new GemFilter
        {
            Chain = "all",
            MaxMarketCapUsd = (double)_numMaxMcap.Value,
            MinLiquidityUsd = (double)_numMinLiq.Value,
            MinVolume24hUsd = 30_000,
            MaxAgeDays = (double)_numMaxAge.Value,
            Sources = GemSource.TopBoosts | GemSource.LatestBoosts | GemSource.Profiles,
            MaxResults = 80,
        };

        _cts = new CancellationTokenSource();
        SetBusy(true);
        _log.Clear();
        var prog = new Progress<string>(AppendLog);

        try
        {
            _status.Text = "Scoperta candidati...";
            var gemResult = await new GemScannerService().ScanAsync(filter, prog, _cts.Token);
            if (gemResult.Gems.Count == 0) { _status.Text = "Nessun candidato."; return; }

            AppendLog("Arricchimento segnali on-chain/sicurezza...");
            await new GemEnrichmentService().EnrichAsync(gemResult.Gems, _settings.GemHunter, S.DeepTopN, prog, _cts.Token);

            // Crescita holder (cap. 9.2): confronta con lo snapshot della scansione precedente
            var holderStore = new MemeHolderStore();
            int withGrowth = 0;
            foreach (var g in gemResult.Gems)
                if (g.HolderCount is > 0)
                {
                    g.HolderGrowthPct = holderStore.UpdateAndGetGrowth(g.Chain, g.TokenAddress, g.HolderCount.Value);
                    if (g.HolderGrowthPct.HasValue) withGrowth++;
                }
            AppendLog($"Crescita holder: {withGrowth} coin con confronto disponibile (snapshot precedenti).");

            // Momentum sociale (cap. 9.6): community/developer score e n. exchange da CoinGecko
            var social = await new MarketMetaClient().EnrichSocialAsync(gemResult.Gems, S.DeepTopN, prog, _cts.Token);

            var candidates = gemResult.Gems.Select(g => new MemeCandidate
            {
                Chain = g.Chain, TokenAddress = g.TokenAddress, Symbol = g.Symbol, Name = g.Name,
                Url = g.Url, MarketCapUsd = g.MarketCapUsd, AgeDays = g.AgeDays,
            }).ToList();

            var source = new GemBackedMemeSignalSource(gemResult.Gems, social);
            var scores = await new MemeScoringService(S).ScoreAsync(candidates, source, prog, _cts.Token);

            FillGrid(scores);
            int alto = scores.Count(s => s.State == MemeState.AltoPotenziale);
            int emer = scores.Count(s => s.State == MemeState.Emergente);
            _status.Text = $"Valutate {scores.Count} coin — ★ {alto} alto potenziale · ◆ {emer} emergenti.";
        }
        catch (OperationCanceledException) { _status.Text = "Interrotto."; AppendLog("** Interrotto **"); }
        catch (Exception ex)
        {
            _status.Text = "Errore."; AppendLog("ERRORE: " + ex.Message);
            MessageBox.Show(this, ex.Message, "Scoperta meme", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }
        finally { _cts.Dispose(); _cts = null; SetBusy(false); }
    }

    private void FillGrid(List<MemeScore> scores)
    {
        _grid.SuspendLayout();
        _grid.Rows.Clear();
        foreach (var s in scores)
        {
            int i = _grid.Rows.Add(s.StateSymbol, s.Candidate.Symbol, s.Candidate.Name,
                s.Composite, s.Liquidity, s.Adoption, s.Derivatives, s.Social,
                s.CoveragePct, s.RiskPenalty, s.Candidate.AgeDays, s.Candidate.MarketCapUsd);
            var row = _grid.Rows[i];
            row.Tag = s;
            row.Cells[0].Style.Font = UiFonts.Bold9;
            row.Cells[0].Style.ForeColor = s.State switch
            {
                MemeState.AltoPotenziale => Color.FromArgb(0, 130, 60),
                MemeState.Emergente => Color.FromArgb(46, 117, 182),
                MemeState.RischioElevato => Color.Firebrick,
                _ => Color.DimGray
            };
            row.DefaultCellStyle.BackColor = s.State switch
            {
                MemeState.AltoPotenziale => Color.FromArgb(220, 245, 225),
                MemeState.RischioElevato => Color.FromArgb(250, 228, 228),
                _ => Color.White
            };
            // null → cella vuota anziché 0
            foreach (var (col, val) in new[] { (4, s.Liquidity), (5, s.Adoption), (6, s.Derivatives), (7, s.Social) })
                if (!val.HasValue) row.Cells[col].Value = null;
        }
        _grid.ResumeLayout();
        WatchlistColumn.Refresh(_grid, WatchFromRow);   // spunta le coin già salvate
        if (_grid.Rows.Count > 0) { _grid.Rows[0].Selected = true; _breakdown.SetScore(scores[0]); }
    }

    /// <summary>Costruisce la voce di watchlist dalla riga (Tag = MemeScore): token on-chain con contratto.</summary>
    private static Services.WatchedCoin? WatchFromRow(DataGridViewRow row)
    {
        if (row.Tag is not MemeScore ms) return null;
        var c = ms.Candidate;
        return new Services.WatchedCoin
        {
            Key = Services.WatchedCoin.MakeKey(c.Chain, c.TokenAddress, c.Symbol),
            Symbol = c.Symbol, Name = c.Name, Chain = c.Chain, Contract = c.TokenAddress, Url = c.Url,
            Source = "Meme", Note = $"score {ms.Composite:N0}",
        };
    }

    private void SetBusy(bool busy)
    {
        _btnRun.Enabled = !busy; _numMaxMcap.Enabled = !busy; _numMinLiq.Enabled = !busy; _numMaxAge.Enabled = !busy;
        _btnStop.Enabled = busy; _progress.Visible = busy;
    }

    private void AppendLog(string msg)
    {
        if (_log.InvokeRequired) { _log.BeginInvoke(() => AppendLog(msg)); return; }
        _log.AppendText($"[{DateTime.Now:HH:mm:ss}] {msg}{Environment.NewLine}");
    }

    protected override void OnFormClosing(FormClosingEventArgs e) { _cts?.Cancel(); base.OnFormClosing(e); }
}
