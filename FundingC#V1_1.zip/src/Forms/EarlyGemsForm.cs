using System.Diagnostics;
using System.Globalization;
using System.Text;
using FundingRateScan.Gems;

namespace FundingRateScan.Forms;

/// <summary>
/// "Caccia gemme": cerca coin esplosive early-stage (potenziali nuove PEPE/BRETT)
/// con le migliori metriche di mercato/DEX, prima che arrivino a capitalizzazioni elevate.
/// </summary>
public sealed class EarlyGemsForm : AppForm
{
    private static readonly CultureInfo Ci = CultureInfo.InvariantCulture;
    private static readonly (string disp, string id)[] Chains =
    {
        ("Tutte", "all"), ("Ethereum", "ethereum"), ("Solana", "solana"), ("Base", "base"),
        ("BNB Chain", "bsc"), ("Arbitrum", "arbitrum"), ("Polygon", "polygon")
    };

    private CancellationTokenSource? _cts;
    private GemResult? _result;

    private ComboBox _cmbChain = null!;
    private NumericUpDown _numMaxMcap = null!, _numMinLiq = null!, _numMinVol = null!, _numMaxAge = null!;
    private CheckBox _chkBuy = null!, _chkTrending = null!, _chkBoosted = null!, _chkProfiles = null!;
    private TextBox _txtSearch = null!, _log = null!;
    private Button _btnScan = null!, _btnStop = null!, _btnExport = null!;
    private ToolStripStatusLabel _status = null!;
    private ToolStripProgressBar _progress = null!;
    private DataGridView _grid = null!;

    public EarlyGemsForm()
    {
        BuildUi();
    }

    private void BuildUi()
    {
        Text = "Caccia gemme — Coin esplosive early-stage (la prossima PEPE/BRETT)";
        StartPosition = FormStartPosition.CenterParent;
        ClientSize = new Size(1280, 760);
        MinimumSize = new Size(1040, 600);
        Font = new Font("Segoe UI", 9f);

        BuildGrid();        // Fill
        BuildIntro();       // Top
        BuildFilters();     // Top
        BuildLog();         // Bottom
        BuildStatusBar();   // Bottom
    }

    private void BuildFilters()
    {
        var p = new Panel { Dock = DockStyle.Top, Height = 86, Padding = new Padding(8, 6, 8, 4) };

        var lblChain = new Label { Text = "Chain:", Location = new Point(8, 11), AutoSize = true };
        _cmbChain = new ComboBox { Location = new Point(54, 7), Size = new Size(120, 24), DropDownStyle = ComboBoxStyle.DropDownList };
        foreach (var c in Chains) _cmbChain.Items.Add(c.disp);
        _cmbChain.SelectedIndex = 0;

        var lblMc = new Label { Text = "Max market cap $:", Location = new Point(186, 11), AutoSize = true };
        _numMaxMcap = Num(296, 8, 100_000, 1_000_000_000, 500_000, 5_000_000);

        var lblLiq = new Label { Text = "Min liquidità $:", Location = new Point(430, 11), AutoSize = true };
        _numMinLiq = Num(528, 8, 0, 100_000_000, 5_000, 20_000);

        var lblVol = new Label { Text = "Min volume 24h $:", Location = new Point(652, 11), AutoSize = true };
        _numMinVol = Num(764, 8, 0, 100_000_000, 25_000, 50_000);

        var lblAge = new Label { Text = "Max età (giorni):", Location = new Point(900, 11), AutoSize = true };
        _numMaxAge = Num(1004, 8, 0, 365, 1, 30);
        _numMaxAge.ThousandsSeparator = false;

        // riga 2
        _chkTrending = new CheckBox { Text = "Trending", Location = new Point(10, 50), AutoSize = true, Checked = true };
        _chkBoosted = new CheckBox { Text = "Boosted recenti", Location = new Point(96, 50), AutoSize = true, Checked = true };
        _chkProfiles = new CheckBox { Text = "Nuovi profili", Location = new Point(216, 50), AutoSize = true, Checked = true };
        _chkBuy = new CheckBox { Text = "Solo con pressione d'acquisto", Location = new Point(330, 50), AutoSize = true };

        var lblSearch = new Label { Text = "Ricerca:", Location = new Point(536, 51), AutoSize = true };
        _txtSearch = new TextBox { Location = new Point(592, 48), Size = new Size(150, 23) };
        _txtSearch.PlaceholderText = "simbolo/parola (opz.)";

        _btnScan = new Button { Text = "Cerca gemme", Location = new Point(760, 46), Size = new Size(120, 28) };
        _btnScan.Click += (_, _) => Run();
        _btnStop = new Button { Text = "Interrompi", Location = new Point(886, 46), Size = new Size(90, 28), Enabled = false };
        _btnStop.Click += (_, _) => _cts?.Cancel();
        _btnExport = new Button { Text = "Esporta CSV", Location = new Point(982, 46), Size = new Size(100, 28), Enabled = false };
        _btnExport.Click += (_, _) => ExportCsv();

        var btnDoc = new Button { Text = "ⓘ Come funziona (Word)", Location = new Point(1088, 46), Size = new Size(170, 28) };
        btnDoc.Click += (_, _) => Services.DocResources.OpenGemDoc(this);

        p.Controls.AddRange(new Control[] { lblChain, _cmbChain, lblMc, _numMaxMcap, lblLiq, _numMinLiq, lblVol, _numMinVol,
            lblAge, _numMaxAge, _chkTrending, _chkBoosted, _chkProfiles, _chkBuy, lblSearch, _txtSearch, _btnScan, _btnStop, _btnExport, btnDoc });
        Controls.Add(p);
    }

    private NumericUpDown Num(int x, int y, decimal min, decimal max, decimal inc, decimal val)
        => new() { Location = new Point(x, y), Size = new Size(120, 24), Minimum = min, Maximum = max, Increment = inc, Value = val, ThousandsSeparator = true };

    private void BuildIntro()
    {
        var lbl = new Label
        {
            Dock = DockStyle.Top, Height = 24, TextAlign = ContentAlignment.MiddleLeft, Padding = new Padding(10, 0, 0, 0),
            BackColor = Color.FromArgb(247, 248, 251), ForeColor = Color.DimGray, Font = new Font("Segoe UI", 8.5f),
            Text = "Score esplosivo = Momentum 25% · Volume (turnover+accelerazione) 25% · Pressione d'acquisto 20% · Salute liquidità 15% · Earliness (micro mcap + giovane) 15%.  Doppio clic = apri su DEX Screener."
        };
        Controls.Add(lbl);
    }

    private void BuildGrid()
    {
        _grid = new DataGridView
        {
            Dock = DockStyle.Fill, ReadOnly = true, AllowUserToAddRows = false, RowHeadersVisible = false,
            AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill, SelectionMode = DataGridViewSelectionMode.FullRowSelect,
            MultiSelect = false, BackgroundColor = SystemColors.Window, BorderStyle = BorderStyle.None, EnableHeadersVisualStyles = false
        };
        _grid.ColumnHeadersDefaultCellStyle.BackColor = Color.FromArgb(40, 44, 60);
        _grid.ColumnHeadersDefaultCellStyle.ForeColor = Color.White;
        _grid.ColumnHeadersDefaultCellStyle.Font = UiFonts.Bold9;

        AddCol("Score", 55, "N0");
        AddCol("Coin", 70, null);
        AddCol("Nome", 110, null);
        AddCol("Chain", 70, null);
        AddCol("Market Cap", 95, "N0");
        AddCol("Liquidità", 90, "N0");
        AddCol("Vol 24h", 95, "N0");
        AddCol("Vol/MC", 60, "N2");
        AddCol("Δ1h%", 60, "N0");
        AddCol("Δ6h%", 60, "N0");
        AddCol("Δ24h%", 60, "N0");
        AddCol("Buy%", 55, "N0");
        AddCol("Età g", 50, "N1");
        AddCol("Mom", 45, "N0");
        AddCol("Vol", 45, "N0");
        AddCol("Buy", 45, "N0");
        AddCol("Liq", 45, "N0");
        AddCol("Early", 50, "N0");
        AddCol("Rischio", 160, null);

        // Colonna watchlist « ★ »: salva permanentemente la gemma scelta.
        WatchlistColumn.Attach(_grid, WatchFromRow);

        _grid.CellDoubleClick += (_, e) => { if (e.RowIndex >= 0) OpenInBrowser(e.RowIndex); };
        Controls.Add(_grid);
    }

    /// <summary>Costruisce la voce di watchlist dalla riga (Tag = GemCandidate): token on-chain con contratto.</summary>
    private static Services.WatchedCoin? WatchFromRow(DataGridViewRow row)
    {
        if (row.Tag is not GemCandidate g) return null;
        return new Services.WatchedCoin
        {
            Key = Services.WatchedCoin.MakeKey(g.Chain, g.TokenAddress, g.Symbol),
            Symbol = g.Symbol, Name = g.Name, Chain = g.Chain, Contract = g.TokenAddress, Url = g.Url,
            Source = "Gemme", Note = $"score {g.Score:N0}",
        };
    }

    private void AddCol(string h, int w, string? fmt)
    {
        var c = new DataGridViewTextBoxColumn { HeaderText = h, FillWeight = w };
        if (fmt != null)
        {
            c.DefaultCellStyle.Format = fmt;
            c.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            c.DefaultCellStyle.FormatProvider = Ci;
        }
        _grid.Columns.Add(c);
    }

    private void BuildLog()
    {
        _log = new TextBox
        {
            Dock = DockStyle.Bottom, Multiline = true, ReadOnly = true, Height = 90, ScrollBars = ScrollBars.Vertical,
            BackColor = Color.FromArgb(20, 22, 30), ForeColor = Color.Gainsboro, Font = new Font("Consolas", 9f)
        };
        Controls.Add(_log);
    }

    private void BuildStatusBar()
    {
        var strip = new StatusStrip();
        _status = new ToolStripStatusLabel { Spring = true, TextAlign = ContentAlignment.MiddleLeft };
        _progress = new ToolStripProgressBar { Style = ProgressBarStyle.Marquee, Visible = false, Width = 150 };
        strip.Items.Add(_status); strip.Items.Add(_progress);
        Controls.Add(strip);
    }

    // ============================================================== Logica
    private async void Run()
    {
        if (_cts != null) return;
        var sources = GemSource.None;
        if (_chkTrending.Checked) sources |= GemSource.TopBoosts;
        if (_chkBoosted.Checked) sources |= GemSource.LatestBoosts;
        if (_chkProfiles.Checked) sources |= GemSource.Profiles;
        if (_txtSearch.Text.Trim().Length > 0) sources |= GemSource.Search;
        if (sources == GemSource.None)
        {
            MessageBox.Show(this, "Seleziona almeno una fonte o inserisci una ricerca.", "Caccia gemme", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            return;
        }

        var filter = new GemFilter
        {
            Chain = Chains[_cmbChain.SelectedIndex].id,
            MaxMarketCapUsd = (double)_numMaxMcap.Value,
            MinLiquidityUsd = (double)_numMinLiq.Value,
            MinVolume24hUsd = (double)_numMinVol.Value,
            MaxAgeDays = (double)_numMaxAge.Value,
            RequireBuyPressure = _chkBuy.Checked,
            Sources = sources,
            SearchQuery = _txtSearch.Text.Trim(),
        };

        _cts = new CancellationTokenSource();
        SetBusy(true);
        _log.Clear();
        var progress = new Progress<string>(AppendLog);
        var svc = new GemScannerService();

        try
        {
            _status.Text = "Ricerca gemme in corso...";
            _result = await svc.ScanAsync(filter, progress, _cts.Token);
            FillGrid(_result);
            _status.Text = $"Trovate {_result.Gems.Count} gemme (su {_result.Scanned} candidati).";
            _btnExport.Enabled = _result.Gems.Count > 0;
        }
        catch (OperationCanceledException) { _status.Text = "Interrotto."; AppendLog("** Interrotto **"); }
        catch (Exception ex)
        {
            _status.Text = "Errore."; AppendLog("ERRORE: " + ex.Message);
            MessageBox.Show(this, ex.Message, "Caccia gemme", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }
        finally { _cts.Dispose(); _cts = null; SetBusy(false); }
    }

    private void FillGrid(GemResult r)
    {
        _grid.SuspendLayout();
        _grid.Rows.Clear();
        foreach (var g in r.Gems)
        {
            int i = _grid.Rows.Add(g.Score, g.Symbol, g.Name, g.Chain,
                g.MarketCapUsd, g.LiquidityUsd, g.Volume24hUsd, g.TurnoverRatio,
                g.PriceChg1h, g.PriceChg6h, g.PriceChg24h, g.BuyRatio * 100,
                g.AgeDays, g.ScoreMomentum, g.ScoreVolume, g.ScoreBuy, g.ScoreLiquidity, g.ScoreEarly,
                g.Risk);
            var row = _grid.Rows[i];
            row.Tag = g;   // GemCandidate completo (serve a watchlist e quotazione)
            row.Cells[0].Style.Font = UiFonts.Bold9;
            row.Cells[0].Style.BackColor = g.Score >= 70 ? Color.FromArgb(214, 245, 214)
                : g.Score >= 50 ? Color.FromArgb(235, 248, 235) : Color.White;
            // momentum colori sui delta
            ColorDelta(row.Cells[8], g.PriceChg1h);
            ColorDelta(row.Cells[9], g.PriceChg6h);
            ColorDelta(row.Cells[10], g.PriceChg24h);
            if (g.Risk != "—") row.Cells[18].Style.ForeColor = Color.Firebrick;
        }
        _grid.ResumeLayout();
        WatchlistColumn.Refresh(_grid, WatchFromRow);   // spunta le gemme già salvate
    }

    private static void ColorDelta(DataGridViewCell c, double v)
        => c.Style.ForeColor = v > 0 ? Color.SeaGreen : v < 0 ? Color.Firebrick : Color.Gray;

    private void OpenInBrowser(int rowIndex)
    {
        // La riga porta il GemCandidate: si apre la pagina DEX Screener della gemma.
        if (_grid.Rows[rowIndex].Tag is FundingRateScan.Gems.GemCandidate g)
        {
            if (!string.IsNullOrWhiteSpace(g.Url)) Services.QuoteLinks.OpenDex(g.Url);
            else Services.QuoteLinks.OpenDexSearch(g.TokenAddress);
        }
    }

    private void ExportCsv()
    {
        if (_result == null || _result.Gems.Count == 0) return;
        using var sfd = new SaveFileDialog { Filter = "CSV (*.csv)|*.csv", FileName = $"gemme_{DateTime.Now:yyyyMMdd_HHmm}.csv" };
        if (sfd.ShowDialog(this) != DialogResult.OK) return;
        var sb = new StringBuilder();
        sb.AppendLine("score,symbol,name,chain,market_cap_usd,liquidity_usd,volume_24h_usd,turnover,chg_1h,chg_6h,chg_24h,buy_pct,age_days,mom,vol,buy,liq,early,risk,token,url");
        foreach (var g in _result.Gems)
            sb.AppendLine(string.Join(",",
                F(g.Score), Q(g.Symbol), Q(g.Name), g.Chain, F(g.MarketCapUsd), F(g.LiquidityUsd), F(g.Volume24hUsd),
                F(g.TurnoverRatio), F(g.PriceChg1h), F(g.PriceChg6h), F(g.PriceChg24h), F(g.BuyRatio * 100), F(g.AgeDays),
                F(g.ScoreMomentum), F(g.ScoreVolume), F(g.ScoreBuy), F(g.ScoreLiquidity), F(g.ScoreEarly), Q(g.Risk), g.TokenAddress, g.Url));
        try { File.WriteAllText(sfd.FileName, sb.ToString(), new UTF8Encoding(true)); _status.Text = "Esportato: " + sfd.FileName; }
        catch (Exception ex) { MessageBox.Show(this, ex.Message, "Export", MessageBoxButtons.OK, MessageBoxIcon.Error); }
    }

    private static string F(double v) => v.ToString("0.####", Ci);
    private static string Q(string s) => s.Contains(',') || s.Contains('"') ? $"\"{s.Replace("\"", "\"\"")}\"" : s;

    private void SetBusy(bool busy)
    {
        _btnScan.Enabled = !busy; _btnStop.Enabled = busy; _progress.Visible = busy;
        if (busy) _btnExport.Enabled = false;
    }

    private void AppendLog(string msg)
    {
        if (_log.InvokeRequired) { _log.BeginInvoke(() => AppendLog(msg)); return; }
        _log.AppendText($"[{DateTime.Now:HH:mm:ss}] {msg}{Environment.NewLine}");
    }

    protected override void OnFormClosing(FormClosingEventArgs e) { _cts?.Cancel(); base.OnFormClosing(e); }
}
