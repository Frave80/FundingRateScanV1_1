namespace FundingRateScan.OnChain.Models;

/// <summary>Tipologia di wallet/controparte di un movimento on-chain.</summary>
public enum WalletType
{
    Unknown,
    Exchange,
    LiquidityPool,
    Treasury,
    Contract,
    KnownWhale,
    UnknownWhale,
    SmartMoney,
    MarketMaker,
    Bridge,
    Burn
}

/// <summary>Tipo di evento on-chain normalizzato.</summary>
public enum OnChainEventType
{
    Transfer,
    SwapBuy,
    SwapSell,
    CexDeposit,
    CexWithdrawal,
    LpAdd,
    LpRemove,
    VestingUnlock,
    TreasuryMove,
    Mint,
    Burn
}

public enum AlertSeverity { Low, Medium, High, Critical }

/// <summary>Descrittore di una chain EVM supportata.</summary>
public sealed class ChainInfo
{
    public string Key { get; init; } = "";       // es. "ethereum"
    public string Display { get; init; } = "";    // es. "Ethereum"
    public int ChainId { get; init; }             // id numerico per Etherscan V2
    public bool HoldersSupported { get; init; }    // top holder disponibili (Ethplorer = solo Ethereum)
}

/// <summary>Parametri di interrogazione di un token.</summary>
public sealed class TokenQuery
{
    public string ChainKey { get; init; } = "";
    public int ChainId { get; init; }
    public string TokenAddress { get; init; } = "";
    public int MaxResults { get; init; } = 200;
    public DateTimeOffset? SinceUtc { get; init; }
}

/// <summary>Metadati di un token.</summary>
public sealed class TokenMetadata
{
    public string Address { get; init; } = "";
    public string Symbol { get; set; } = "";
    public string Name { get; set; } = "";
    public int Decimals { get; set; } = 18;
    public decimal TotalSupply { get; set; }
    public decimal PriceUsd { get; set; }
    public decimal LiquidityUsd { get; set; }
    public decimal Volume24hUsd { get; set; }
    public decimal PriceChange24hPct { get; set; }
    public int HoldersCount { get; set; }
    public List<string> PairAddresses { get; } = new();   // indirizzi LP (DEX)
}

/// <summary>Voce della classifica top holder.</summary>
public sealed class HolderInfo
{
    public string Address { get; init; } = "";
    public decimal Balance { get; set; }       // in token
    public decimal ValueUsd { get; set; }
    public double SharePct { get; set; }
    public WalletType Type { get; set; } = WalletType.Unknown;
    public string Label { get; set; } = "";
}

/// <summary>Trasferimento di token normalizzato (modello da salvare).</summary>
public sealed class TokenTransferEvent
{
    public string TxHash { get; init; } = "";
    public long BlockNumber { get; init; }
    public string ChainId { get; init; } = "";
    public string TokenAddress { get; init; } = "";
    public string FromAddress { get; init; } = "";
    public string ToAddress { get; init; } = "";
    public decimal TokenAmount { get; init; }
    public decimal AmountUsd { get; set; }
    public DateTimeOffset TimestampUtc { get; init; }

    public string FromLabel { get; set; } = "";
    public string ToLabel { get; set; } = "";
    public WalletType FromType { get; set; } = WalletType.Unknown;
    public WalletType ToType { get; set; } = WalletType.Unknown;
    public OnChainEventType EventType { get; set; } = OnChainEventType.Transfer;

    public bool IsWhaleMovement { get; set; }
    public bool IsExchangeRelated { get; set; }
    public bool IsMillionaireWalletMove { get; set; }

    public decimal FundingRateAtEvent { get; set; }
    public decimal PriceAtEvent { get; set; }
}

/// <summary>Swap su DEX (modello del contratto; v1 best-effort).</summary>
public sealed class TokenSwapEvent
{
    public string TxHash { get; init; } = "";
    public DateTimeOffset TimestampUtc { get; init; }
    public bool IsBuy { get; init; }
    public decimal TokenAmount { get; init; }
    public decimal AmountUsd { get; init; }
    public string Wallet { get; init; } = "";
}

/// <summary>Snapshot del saldo di un wallet a un istante.</summary>
public sealed class WalletSnapshot
{
    public string Address { get; init; } = "";
    public DateTimeOffset SnapshotTime { get; init; }
    public decimal TokenBalance { get; init; }
    public decimal TokenValueUsd { get; init; }
}

/// <summary>Aggregati di flusso su una finestra temporale.</summary>
public sealed class FlowSnapshot
{
    public int WindowMinutes { get; set; }
    public decimal NetInflowUsd { get; set; }
    public decimal NetOutflowUsd { get; set; }
    public decimal WhaleBuyUsd { get; set; }
    public decimal WhaleSellUsd { get; set; }
    public decimal CexInUsd { get; set; }
    public decimal CexOutUsd { get; set; }
    public int NewMillionaireWallets { get; set; }
    public double Top10HolderShareChangePct { get; set; }
    public int WhaleMovements { get; set; }

    public decimal NetWhaleBuyUsd => WhaleBuyUsd - WhaleSellUsd;
}

/// <summary>Contesto funding per lo scoring.</summary>
public sealed class FundingSnapshot
{
    public decimal Rate8h { get; init; }       // funding per intervallo (frazione)
    public decimal Apr { get; init; }
    public bool Available { get; init; }
}

/// <summary>Contesto di mercato per lo scoring.</summary>
public sealed class MarketSnapshot
{
    public decimal PriceUsd { get; init; }
    public decimal PriceChange24h { get; init; }
    public decimal LiquidityUsd { get; init; }
    public decimal Volume24hUsd { get; init; }
}

/// <summary>Esito dello scoring: punteggio + interpretazione + motivazioni.</summary>
public sealed class FlowSignal
{
    public int Score { get; init; }
    public string Bias { get; init; } = "Neutro";
    public List<string> Reasons { get; init; } = new();
}

/// <summary>Alert leggibile e salvabile.</summary>
public sealed class WhaleAlert
{
    public string Title { get; init; } = "";
    public string Description { get; init; } = "";
    public int Score { get; init; }
    public AlertSeverity Severity { get; init; } = AlertSeverity.Medium;
    public string? TxHash { get; init; }
    public decimal AmountUsd { get; init; }
    public DateTimeOffset CreatedAtUtc { get; init; } = DateTimeOffset.UtcNow;
}

/// <summary>Risultato completo di una sincronizzazione, consumato dalla UI.</summary>
public sealed class OnChainResult
{
    public TokenMetadata Token { get; set; } = new();
    public List<TokenTransferEvent> Transfers { get; set; } = new();
    public List<HolderInfo> Holders { get; set; } = new();
    public FlowSnapshot Flow { get; set; } = new();
    public List<FlowSnapshot> Windows { get; set; } = new();
    public FlowSignal Signal { get; set; } = new();
    public List<WhaleAlert> Alerts { get; set; } = new();
    public FundingSnapshot Funding { get; set; } = new();
    public MarketSnapshot Market { get; set; } = new();
}
