using FundingRateScan.OnChain.Models;

namespace FundingRateScan.OnChain.Services;

/// <summary>Calcola gli aggregati di flusso su finestre temporali e i delta degli holder.</summary>
public sealed class FlowAggregator
{
    public List<FlowSnapshot> Aggregate(IReadOnlyList<TokenTransferEvent> transfers, IEnumerable<int> windowsMinutes)
    {
        var now = DateTimeOffset.UtcNow;
        var list = new List<FlowSnapshot>();

        foreach (var w in windowsMinutes.OrderBy(x => x))
        {
            var cutoff = now.AddMinutes(-w);
            var inWin = transfers.Where(t => t.TimestampUtc >= cutoff).ToList();

            decimal buy = Sum(inWin, OnChainEventType.SwapBuy) + Sum(inWin, OnChainEventType.CexWithdrawal);
            decimal sell = Sum(inWin, OnChainEventType.SwapSell) + Sum(inWin, OnChainEventType.CexDeposit);

            list.Add(new FlowSnapshot
            {
                WindowMinutes = w,
                NetInflowUsd = buy,
                NetOutflowUsd = sell,
                CexInUsd = Sum(inWin, OnChainEventType.CexDeposit),
                CexOutUsd = Sum(inWin, OnChainEventType.CexWithdrawal),
                WhaleBuyUsd = inWin.Where(t => t.IsWhaleMovement && IsBuy(t.EventType)).Sum(t => t.AmountUsd),
                WhaleSellUsd = inWin.Where(t => t.IsWhaleMovement && IsSell(t.EventType)).Sum(t => t.AmountUsd),
                WhaleMovements = inWin.Count(t => t.IsWhaleMovement),
            });
        }
        return list;
    }

    /// <summary>Delta holder: nuovi wallet milionari e variazione quota top 10 (punti %).</summary>
    public (int newMillionaires, double top10ShareChange) HolderDelta(
        IReadOnlyList<HolderInfo> current, IReadOnlyList<HolderInfo>? previous, decimal millionaireUsd)
    {
        var curMillionaires = current.Where(h => h.ValueUsd >= millionaireUsd)
            .Select(h => h.Address).ToHashSet(StringComparer.OrdinalIgnoreCase);

        int newMill;
        if (previous == null || previous.Count == 0)
        {
            newMill = curMillionaires.Count;   // prima rilevazione: tutti "nuovi"
        }
        else
        {
            var prevMillionaires = previous.Where(h => h.ValueUsd >= millionaireUsd)
                .Select(h => h.Address).ToHashSet(StringComparer.OrdinalIgnoreCase);
            newMill = curMillionaires.Count(a => !prevMillionaires.Contains(a));
        }

        double curTop10 = current.OrderByDescending(h => h.SharePct).Take(10).Sum(h => h.SharePct);
        double prevTop10 = previous == null ? curTop10
            : previous.OrderByDescending(h => h.SharePct).Take(10).Sum(h => h.SharePct);

        return (newMill, curTop10 - prevTop10);
    }

    private static decimal Sum(IEnumerable<TokenTransferEvent> ts, OnChainEventType type)
        => ts.Where(t => t.EventType == type).Sum(t => t.AmountUsd);

    private static bool IsBuy(OnChainEventType e) => e is OnChainEventType.SwapBuy or OnChainEventType.CexWithdrawal;
    private static bool IsSell(OnChainEventType e) => e is OnChainEventType.SwapSell or OnChainEventType.CexDeposit;
}
