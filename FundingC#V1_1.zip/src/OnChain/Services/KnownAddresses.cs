using FundingRateScan.OnChain.Models;

namespace FundingRateScan.OnChain.Services;

/// <summary>
/// Etichette di indirizzi noti (Ethereum) per classificare le controparti.
/// Set volutamente compatto ed estendibile: per una copertura completa si usa
/// una wallet-intelligence API (Moralis/Bitquery) tramite il provider.
/// </summary>
public static class KnownAddresses
{
    public static readonly string ZeroAddress = "0x0000000000000000000000000000000000000000";
    public static readonly string DeadAddress = "0x000000000000000000000000000000000000dead";

    public static readonly IReadOnlyDictionary<string, (WalletType Type, string Label)> Map =
        new Dictionary<string, (WalletType, string)>(StringComparer.OrdinalIgnoreCase)
        {
            // Binance
            ["0x28c6c06298d514db089934071355e5743bf21d60"] = (WalletType.Exchange, "Binance"),
            ["0x21a31ee1afc51d94c2efccaa2092ad1028285549"] = (WalletType.Exchange, "Binance"),
            ["0xdfd5293d8e347dfe59e90efd55b2956a1343963d"] = (WalletType.Exchange, "Binance"),
            ["0x56eddb7aa87536c09ccc2793473599fd21a8b17f"] = (WalletType.Exchange, "Binance"),
            ["0x9696f59e4d72e237be84ffd425dcad154bf96976"] = (WalletType.Exchange, "Binance"),
            ["0x5a52e96bacdabb82fd05763e25335261b270efcb"] = (WalletType.Exchange, "Binance"),
            // Coinbase
            ["0x71660c4005ba85c37ccec55d0c4493e66fe775d3"] = (WalletType.Exchange, "Coinbase"),
            ["0x503828976d22510aad0201ac7ec88293211d23da"] = (WalletType.Exchange, "Coinbase"),
            ["0xddfabcdc4d8ffc6d5beaf154f18b778f892a0740"] = (WalletType.Exchange, "Coinbase"),
            ["0x3cd751e6b0078be393132286c442345e5dc49699"] = (WalletType.Exchange, "Coinbase"),
            // Kraken
            ["0x2910543af39aba0cd09dbb2d50200b3e800a63d2"] = (WalletType.Exchange, "Kraken"),
            ["0xae2d4617c862309a3d75a0ffb358c7a5009c673f"] = (WalletType.Exchange, "Kraken"),
            // OKX
            ["0x6cc5f688a315f3dc28a7781717a9a798a59fda7b"] = (WalletType.Exchange, "OKX"),
            ["0x236f9f97e0e62388479bf9e5ba4889e46b0273c3"] = (WalletType.Exchange, "OKX"),
            // Altri
            ["0x876eabf441b2ee5b5b0554fd502a8e0600950cfa"] = (WalletType.Exchange, "Bitfinex"),
            ["0x0d0707963952f2fba59dd06f2b425ace40b492fe"] = (WalletType.Exchange, "Gate.io"),
            ["0xf89d7b9c864f589bbf53a82105107622b35eaa40"] = (WalletType.Exchange, "Bybit"),
        };
}
