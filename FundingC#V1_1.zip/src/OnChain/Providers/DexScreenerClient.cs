using System.Text.Json;
using FundingRateScan.Services;
using FundingRateScan.OnChain.Models;

namespace FundingRateScan.OnChain.Providers;

/// <summary>
/// DEX Screener: prezzo, liquidità, volume e indirizzi dei pair (LP) di un token.
/// Endpoint pubblico, nessuna chiave richiesta.
/// </summary>
public sealed class DexScreenerClient
{
    private const string Base = "https://api.dexscreener.com/latest/dex/tokens/";

    /// <summary>Arricchisce i metadati del token con i dati di mercato e gli indirizzi LP.</summary>
    public async Task EnrichMarketAsync(TokenMetadata token, string chainKey, CancellationToken ct)
    {
        if (string.IsNullOrWhiteSpace(token.Address)) return;
        using var doc = await HttpHelper.GetJsonAsync(Base + token.Address, ct);
        if (doc == null || !doc.RootElement.TryGetProperty("pairs", out var pairs)
            || pairs.ValueKind != JsonValueKind.Array)
            return;

        JsonElement best = default;
        double bestLiq = -1;

        foreach (var p in pairs.EnumerateArray())
        {
            var chain = HttpHelper.GetString(p, "chainId");
            if (!MatchesChain(chain, chainKey)) continue;

            // Raccoglie l'indirizzo del pair (LP) per la classificazione wallet
            var pairAddr = HttpHelper.GetString(p, "pairAddress");
            if (pairAddr.Length > 0) token.PairAddresses.Add(pairAddr.ToLowerInvariant());

            double liq = 0;
            if (p.TryGetProperty("liquidity", out var l) && l.ValueKind == JsonValueKind.Object)
                liq = HttpHelper.GetDouble(l, "usd");
            if (liq > bestLiq) { bestLiq = liq; best = p; }
        }

        if (bestLiq < 0) return;

        token.PriceUsd = (decimal)HttpHelper.GetDouble(best, "priceUsd");
        if (best.TryGetProperty("liquidity", out var bl) && bl.ValueKind == JsonValueKind.Object)
            token.LiquidityUsd = (decimal)HttpHelper.GetDouble(bl, "usd");
        if (best.TryGetProperty("volume", out var v) && v.ValueKind == JsonValueKind.Object)
            token.Volume24hUsd = (decimal)HttpHelper.GetDouble(v, "h24");
        if (best.TryGetProperty("priceChange", out var pc) && pc.ValueKind == JsonValueKind.Object)
            token.PriceChange24hPct = (decimal)HttpHelper.GetDouble(pc, "h24");
        if (best.TryGetProperty("baseToken", out var bt) && bt.ValueKind == JsonValueKind.Object)
        {
            if (token.Symbol.Length == 0) token.Symbol = HttpHelper.GetString(bt, "symbol");
            if (token.Name.Length == 0) token.Name = HttpHelper.GetString(bt, "name");
        }
    }

    private static bool MatchesChain(string dexChain, string chainKey) => chainKey switch
    {
        "ethereum" => dexChain == "ethereum",
        "bsc" => dexChain == "bsc",
        "polygon" => dexChain == "polygon",
        "arbitrum" => dexChain == "arbitrum",
        "base" => dexChain == "base",
        "optimism" => dexChain == "optimism",
        _ => true
    };
}
