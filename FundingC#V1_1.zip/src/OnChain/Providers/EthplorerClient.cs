using System.Text.Json;
using FundingRateScan.Services;
using FundingRateScan.OnChain.Models;

namespace FundingRateScan.OnChain.Providers;

/// <summary>
/// Ethplorer (solo Ethereum): info token e top holder. Funziona con la chiave
/// pubblica "freekey" (limitata) o una chiave personale.
/// </summary>
public sealed class EthplorerClient
{
    private const string Base = "https://api.ethplorer.io";
    private readonly string _apiKey;

    public EthplorerClient(string apiKey)
        => _apiKey = string.IsNullOrWhiteSpace(apiKey) ? "freekey" : apiKey;

    public async Task EnrichTokenInfoAsync(TokenMetadata token, CancellationToken ct)
    {
        using var doc = await HttpHelper.GetJsonAsync(
            $"{Base}/getTokenInfo/{token.Address}?apiKey={_apiKey}", ct);
        if (doc == null) return;
        var r = doc.RootElement;

        var name = HttpHelper.GetString(r, "name");
        var symbol = HttpHelper.GetString(r, "symbol");
        if (name.Length > 0 && token.Name.Length == 0) token.Name = name;
        if (symbol.Length > 0 && token.Symbol.Length == 0) token.Symbol = symbol;

        if (r.TryGetProperty("holdersCount", out _))
            token.HoldersCount = (int)HttpHelper.GetDouble(r, "holdersCount");

        // Prezzo (se DEX Screener non l'ha fornito)
        if (token.PriceUsd == 0 && r.TryGetProperty("price", out var price) && price.ValueKind == JsonValueKind.Object)
            token.PriceUsd = (decimal)HttpHelper.GetDouble(price, "rate");
    }

    /// <summary>Top holder con quota %. USD stimato da supply * quota * prezzo.</summary>
    public async Task<List<HolderInfo>> GetTopHoldersAsync(TokenMetadata token, int limit, CancellationToken ct)
    {
        var holders = new List<HolderInfo>();
        using var doc = await HttpHelper.GetJsonAsync(
            $"{Base}/getTopTokenHolders/{token.Address}?apiKey={_apiKey}&limit={Math.Clamp(limit, 1, 100)}", ct);
        if (doc == null || !doc.RootElement.TryGetProperty("holders", out var arr)
            || arr.ValueKind != JsonValueKind.Array)
            return holders;

        // supply in token per stima USD via quota
        decimal supplyTokens = await GetSupplyTokensAsync(token, ct);

        foreach (var h in arr.EnumerateArray())
        {
            double share = HttpHelper.GetDouble(h, "share");
            decimal balanceTokens = supplyTokens > 0
                ? supplyTokens * (decimal)(share / 100.0)
                : 0m;
            holders.Add(new HolderInfo
            {
                Address = HttpHelper.GetString(h, "address").ToLowerInvariant(),
                SharePct = share,
                Balance = balanceTokens,
                ValueUsd = balanceTokens * token.PriceUsd,
            });
        }
        return holders;
    }

    private async Task<decimal> GetSupplyTokensAsync(TokenMetadata token, CancellationToken ct)
    {
        using var doc = await HttpHelper.GetJsonAsync(
            $"{Base}/getTokenInfo/{token.Address}?apiKey={_apiKey}", ct);
        if (doc == null) return 0m;
        var r = doc.RootElement;
        int decimals = (int)HttpHelper.ParseDouble(GetProp(r, "decimals"));
        if (decimals <= 0) decimals = 18;
        return EtherscanClient.RawToDecimal(HttpHelper.GetString(r, "totalSupply"), decimals);
    }

    private static JsonElement GetProp(JsonElement el, string name)
        => el.TryGetProperty(name, out var v) ? v : default;
}
