namespace FundingRateScan.Gems;

/// <summary>
/// Caccia gemme: scopre token early-stage dal feed DEX Screener e li classifica con
/// uno score esplosivo multi-metrica (momentum, accelerazione volume, pressione di
/// acquisto, salute della liquidità, "earliness"), con flag di rischio anti-scam.
/// L'obiettivo è individuare potenziali nuove PEPE/BRETT prima del large cap.
/// </summary>
public sealed class GemScannerService
{
    private readonly DexScreenerDiscovery _dex = new();

    public async Task<GemResult> ScanAsync(GemFilter f, IProgress<string> log, CancellationToken ct)
    {
        var raw = new List<GemCandidate>();

        // 1) Ricerca testuale (se richiesta)
        if (f.Sources.HasFlag(GemSource.Search) && f.SearchQuery.Trim().Length > 0)
        {
            log.Report($"Ricerca DEX Screener: \"{f.SearchQuery}\"...");
            raw.AddRange(await _dex.SearchAsync(f.SearchQuery, ct));
        }

        // 2) Feed di scoperta (boosts / profili)
        var feedSources = f.Sources & (GemSource.TopBoosts | GemSource.LatestBoosts | GemSource.Profiles);
        if (feedSources != GemSource.None)
        {
            log.Report("Recupero feed candidati (boosted / trending / profili)...");
            var addrs = await _dex.GetFeedAddressesAsync(feedSources, ct);
            if (f.Chain != "all")
                addrs = addrs.Where(a => a.chain.Equals(f.Chain, StringComparison.OrdinalIgnoreCase)).ToList();
            log.Report($"  {addrs.Count} token candidati. Recupero dati di mercato...");
            raw.AddRange(await _dex.FetchPairsAsync(addrs, ct));
        }

        // 3) Dedup per token, tenendo il pair con liquidità maggiore
        var byToken = raw
            .Where(g => g.TokenAddress.Length > 0)
            .GroupBy(g => (g.Chain.ToLowerInvariant(), g.TokenAddress))
            .Select(grp => grp.OrderByDescending(x => x.LiquidityUsd).First())
            .ToList();

        int scanned = byToken.Count;

        // 4) Filtri
        var filtered = byToken.Where(g =>
            (f.Chain == "all" || g.Chain.Equals(f.Chain, StringComparison.OrdinalIgnoreCase)) &&
            g.MarketCapUsd > 0 && g.MarketCapUsd <= f.MaxMarketCapUsd &&
            g.LiquidityUsd >= f.MinLiquidityUsd &&
            g.Volume24hUsd >= f.MinVolume24hUsd &&
            (f.MaxAgeDays <= 0 || g.AgeHours <= 0 || g.AgeDays <= f.MaxAgeDays) &&
            (!f.RequireBuyPressure || g.BuyRatio > 0.5)
        ).ToList();

        // 5) Score + ordinamento
        foreach (var g in filtered) Score(g);
        var gems = filtered.OrderByDescending(g => g.Score).Take(f.MaxResults).ToList();

        log.Report($"Trovate {gems.Count} gemme (su {scanned} candidati analizzati).");
        return new GemResult { Gems = gems, Scanned = scanned, Discarded = scanned - filtered.Count };
    }

    // ----------------------------------------------------- Scoring esplosivo
    private static void Score(GemCandidate g)
    {
        // Momentum: variazioni 6h e 1h (logistico), con penalità da esaurimento
        double mom = 0.55 * Logistic(g.PriceChg6h, 40) + 0.45 * Logistic(g.PriceChg1h, 40);
        if (g.PriceChg1h > 300) mom *= 0.65;     // pump probabilmente esaurito
        g.ScoreMomentum = R(mom);

        // Volume: turnover (vol/mcap) + accelerazione (vol1h*24 vs vol24)
        double turnover = Clamp01(Math.Log10(1 + g.TurnoverRatio) / Math.Log10(11));   // turnover ~0..10 → 0..1
        double accel = Clamp01((g.VolumeAccel - 0.5) / 1.5);                            // >2x → ~1
        double volScore = 0.6 * turnover + 0.4 * accel;
        g.ScoreVolume = R(volScore);

        // Pressione di acquisto
        double buy = Clamp01((g.BuyRatio - 0.45) / 0.35);                               // 0.45→0, 0.8→1
        g.ScoreBuy = R(buy);

        // Salute liquidità: assoluta (log) + banda sana del rapporto liq/mcap
        double liqAbs = Clamp01(Math.Log10(Math.Max(1, g.LiquidityUsd) / 10_000.0) / 2.0);  // 10k→0, 1M→1
        double band = LiqBand(g.LiqToMcap);
        double liqScore = 0.5 * liqAbs + 0.5 * band;
        g.ScoreLiquidity = R(liqScore);

        // Earliness: micro market cap + giovane età = più "prima del large cap"
        double mcapScore = Clamp01((7.0 - Math.Log10(Math.Max(1, g.MarketCapUsd))) / 4.0); // 1k→1, 10M→0
        double ageScore = g.AgeHours <= 0 ? 0.6 : Clamp01((30.0 - g.AgeDays) / 28.0);       // <2g→~1, 30g→0
        double early = 0.6 * mcapScore + 0.4 * ageScore;
        g.ScoreEarly = R(early);

        double total = 0.25 * mom + 0.25 * volScore + 0.20 * buy + 0.15 * liqScore + 0.15 * early;
        g.Score = R(total);

        g.Risk = BuildRisk(g);
    }

    private static string BuildRisk(GemCandidate g)
    {
        var notes = new List<string>();
        if (g.LiquidityUsd < 15_000) notes.Add("liquidità bassa");
        if (g.LiqToMcap > 0 && g.LiqToMcap < 0.02) notes.Add("liquidità sottile vs mcap");
        if (g.Sells24 > g.Buys24 * 1.3 && (g.Buys24 + g.Sells24) > 20) notes.Add("pressione di vendita");
        if (g.AgeHours > 0 && g.AgeHours < 2) notes.Add("appena creata");
        if (g.PriceChg1h > 300) notes.Add("possibile pump esaurito");
        if (g.PriceChg24h < -40) notes.Add("in forte ribasso");
        return notes.Count == 0 ? "—" : string.Join(", ", notes);
    }

    // ----------------------------------------------------- Helper numerici
    private static double Logistic(double pctChange, double scale) => 1.0 / (1.0 + Math.Exp(-pctChange / scale));
    private static double Clamp01(double v) => Math.Max(0, Math.Min(1, v));
    private static double R(double unit01) => Math.Round(unit01 * 100.0, 0);

    /// <summary>Punteggio "banda sana" del rapporto liquidità/market cap (picco ~0.08–0.20).</summary>
    private static double LiqBand(double ratio)
    {
        if (ratio <= 0) return 0;
        if (ratio < 0.02) return ratio / 0.02 * 0.3;        // troppo sottile
        if (ratio <= 0.20) return 1.0;                       // sana
        if (ratio <= 0.60) return 1.0 - (ratio - 0.20) / 0.40 * 0.5; // molto alta vs mcap → meno upside
        return 0.4;
    }
}
