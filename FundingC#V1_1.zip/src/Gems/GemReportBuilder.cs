using System.Text;

namespace FundingRateScan.Gems;

/// <summary>
/// Genera il "dossier" di approfondimento di una gemma: documento (Markdown) che
/// spiega ogni parametro usato nella selezione, le motivazioni dei possibili rialzi
/// (catalizzatori), la matematica del multiplo verso 10x/100x/200x e i rischi.
/// </summary>
public static class GemReportBuilder
{
    public static string Build(GemCandidate g)
    {
        var sb = new StringBuilder();
        var ci = System.Globalization.CultureInfo.InvariantCulture;
        string M(double v) => v >= 1_000_000_000 ? (v / 1_000_000_000).ToString("N2", ci) + " mld $"
                            : v >= 1_000_000 ? (v / 1_000_000).ToString("N2", ci) + " M$"
                            : v.ToString("N0", ci) + " $";

        // ===================================================== Intestazione
        sb.AppendLine($"# Dossier gemma — {g.Symbol} ({g.Name})");
        sb.AppendLine();
        sb.AppendLine($"- **Chain:** {g.Chain}");
        sb.AppendLine($"- **Contratto:** `{g.TokenAddress}`");
        sb.AppendLine($"- **Pair DEX:** `{g.PairAddress}`  ·  [DEX Screener]({g.Url})");
        sb.AppendLine($"- **Generato:** {DateTime.Now:dd/MM/yyyy HH:mm}");
        sb.AppendLine($"- **Fonti dati:** DEX Screener{(g.SecuritySources.Length > 0 ? " + " + g.SecuritySources : "")}");
        sb.AppendLine();

        // ===================================================== Sintesi
        sb.AppendLine("## 1. Sintesi");
        sb.AppendLine();
        sb.AppendLine($"| Indicatore | Valore |");
        sb.AppendLine($"|---|---|");
        sb.AppendLine($"| **MoonScore** (mercato + sicurezza) | **{g.MoonScore:N0} / 100** |");
        sb.AppendLine($"| Score esplosivo di mercato | {g.Score:N0} / 100 |");
        sb.AppendLine($"| Punteggio sicurezza | {(g.SecurityScore.HasValue ? g.SecurityScore.Value.ToString("N0") + " / 100" : "non disponibile")} |");
        sb.AppendLine($"| Potenziale teorico | {g.PotentialLabel} |");
        sb.AppendLine($"| Prezzo | {g.PriceUsd.ToString("G6", ci)} $ |");
        sb.AppendLine($"| Market cap | {M(g.MarketCapUsd)} |");
        sb.AppendLine($"| Flag di rischio | {g.Risk} |");
        sb.AppendLine();

        // ===================================================== Parametri
        sb.AppendLine("## 2. Tutti i parametri di selezione (spiegati)");
        sb.AppendLine();
        sb.AppendLine("### 2.1 Capitalizzazione ed earliness");
        sb.AppendLine();
        sb.AppendLine($"- **Market cap: {M(g.MarketCapUsd)}** (FDV {M(g.FdvUsd)}) — la capitalizzazione è il fattore n.1 del " +
                      "potenziale moltiplicatore: PEPE, BONK e TURBO hanno fatto 100x+ partendo da capitalizzazioni di poche " +
                      "centinaia di migliaia / pochi milioni di dollari. Più la mcap è piccola, più \"strada\" c'è verso l'alto " +
                      "(a parità di rischio, che però cresce).");
        sb.AppendLine($"- **Età: {g.AgeDays:N1} giorni** — i grandi multipli si fanno quasi solo entrando presto. Sotto i 30 giorni " +
                      "il token è in fase di scoperta del prezzo; sotto le 48 ore è rischiosissimo ma con upside massimo.");
        sb.AppendLine($"- **Punteggio earliness: {g.ScoreEarly:N0}/100** (micro market cap 60% + giovane età 40%).");
        sb.AppendLine();
        sb.AppendLine("### 2.2 Momentum");
        sb.AppendLine();
        sb.AppendLine($"- **Variazioni prezzo:** 5m {g.PriceChg5m:+0.0;-0.0}% · 1h {g.PriceChg1h:+0.0;-0.0}% · 6h {g.PriceChg6h:+0.0;-0.0}% · 24h {g.PriceChg24h:+0.0;-0.0}%");
        sb.AppendLine("  Il momentum positivo su 1h e 6h indica che la corsa è in atto ORA. Un +300% in 1h, però, segnala un " +
                      "pump probabilmente già esaurito (penalizzato nello score).");
        sb.AppendLine($"- **Punteggio momentum: {g.ScoreMomentum:N0}/100** (variazione 6h pesata 55%, 1h 45%, funzione logistica).");
        sb.AppendLine();
        sb.AppendLine("### 2.3 Volume e accelerazione");
        sb.AppendLine();
        sb.AppendLine($"- **Volume 24h: {M(g.Volume24hUsd)}** · volume 1h: {M(g.Volume1hUsd)}");
        sb.AppendLine($"- **Turnover (volume/mcap): {g.TurnoverRatio:N2}** — sopra 1 significa che in 24h è passato di mano più " +
                      "dell'intera capitalizzazione: tipico delle meme in fase esplosiva.");
        sb.AppendLine($"- **Accelerazione (vol 1h proiettato vs 24h): {g.VolumeAccel:N2}** — sopra 1 il volume sta accelerando " +
                      "adesso; è uno dei segnali più predittivi della continuazione del movimento.");
        sb.AppendLine($"- **Punteggio volume: {g.ScoreVolume:N0}/100** (turnover 60% + accelerazione 40%).");
        sb.AppendLine();
        sb.AppendLine("### 2.4 Pressione di acquisto");
        sb.AppendLine();
        sb.AppendLine($"- **Transazioni 24h:** {g.Buys24:N0} acquisti vs {g.Sells24:N0} vendite → **buy ratio {g.BuyRatio * 100:N0}%**");
        sb.AppendLine("  Sopra il 55-60% di acquisti la domanda supera l'offerta: è il carburante dei rialzi. " +
                      $"Punteggio: **{g.ScoreBuy:N0}/100**.");
        sb.AppendLine();
        sb.AppendLine("### 2.5 Salute della liquidità");
        sb.AppendLine();
        sb.AppendLine($"- **Liquidità pool: {M(g.LiquidityUsd)}** · **liq/mcap: {g.LiqToMcap * 100:N1}%**");
        sb.AppendLine("  La banda sana è 8–20%: liquidità troppo sottile = manipolabile e difficile da vendere; " +
                      "troppo alta rispetto alla mcap = poco spazio di apprezzamento. " +
                      $"Punteggio: **{g.ScoreLiquidity:N0}/100**.");
        sb.AppendLine();

        // ===================================================== Sicurezza
        sb.AppendLine("## 3. Sicurezza del contratto (anti-scam)");
        sb.AppendLine();
        if (g.SecurityScore.HasValue)
        {
            sb.AppendLine($"Punteggio sicurezza: **{g.SecurityScore:N0}/100** (fonti: {g.SecuritySources})");
            sb.AppendLine();
            sb.AppendLine($"| Controllo | Esito |");
            sb.AppendLine($"|---|---|");
            sb.AppendLine($"| Honeypot (vendita bloccata) | {YN(g.IsHoneypot, "SÌ — NON COMPRARE", "no, vendita ok", "non testato")} |");
            sb.AppendLine($"| Tassa acquisto / vendita | {(g.BuyTaxPct.HasValue || g.SellTaxPct.HasValue ? $"{g.BuyTaxPct ?? 0:N1}% / {g.SellTaxPct ?? 0:N1}%" : "n.d.")} |");
            sb.AppendLine($"| Contratto verificato | {YN(g.IsOpenSource, "sì", "NO", "n.d.")} |");
            sb.AppendLine($"| Supply mintabile | {YN(g.IsMintable, "SÌ (rischio diluizione)", "no", "n.d.")} |");
            sb.AppendLine($"| Numero holders | {(g.HolderCount.HasValue ? g.HolderCount.Value.ToString("N0") : "n.d.")} |");
            sb.AppendLine($"| Concentrazione top 10 | {(g.Top10HoldersPct.HasValue ? g.Top10HoldersPct.Value.ToString("N1") + "%" : "n.d.")} |");
            sb.AppendLine($"| LP bloccata | {(g.LpLockedPct.HasValue ? g.LpLockedPct.Value.ToString("N0") + "%" : "n.d.")} |");
            sb.AppendLine($"| Censita su CoinGecko | {YN(g.CoinGeckoListed, "sì", "no", "n.d.")} |");
            sb.AppendLine($"| Possibile spam | {YN(g.PossibleSpam, "SÌ (Moralis)", "no", "n.d.")} |");
            sb.AppendLine();
            if (g.SecurityNotes.Count > 0)
            {
                sb.AppendLine("Note di sicurezza:");
                sb.AppendLine();
                foreach (var n in g.SecurityNotes) sb.AppendLine($"- {n}");
                sb.AppendLine();
            }
        }
        else
            sb.AppendLine("Nessun controllo di sicurezza disponibile per questa coin (provider disabilitati, " +
                          "chain non supportata o fuori dalle prime N analizzate). **Verifica manualmente** prima di operare.\n");

        // ===================================================== Motivazioni rialzo
        sb.AppendLine("## 4. Motivazioni dei possibili rialzi (catalizzatori)");
        sb.AppendLine();
        int n2 = 0;
        void Cat(string s) => sb.AppendLine($"{++n2}. {s}");

        if (g.MarketCapUsd > 0 && g.MarketCapUsd < 2_000_000)
            Cat($"**Micro-capitalizzazione ({M(g.MarketCapUsd)})**: bastano flussi di acquisto modesti per multipli " +
                "importanti; è la stessa condizione di partenza di PEPE/BONK/TURBO prima dell'esplosione.");
        else if (g.MarketCapUsd < 10_000_000)
            Cat($"**Capitalizzazione ancora piccola ({M(g.MarketCapUsd)})**: ampio margine prima delle soglie " +
                "psicologiche (100M, 1B) dove i meme-coin di successo si fermano.");
        if (g.VolumeAccel > 1.2)
            Cat($"**Volume in accelerazione ({g.VolumeAccel:N1}× il ritmo delle 24h)**: l'attenzione sta crescendo " +
                "proprio adesso — i grandi rialzi partono quasi sempre da un'accelerazione dei volumi.");
        if (g.TurnoverRatio > 1)
            Cat($"**Turnover {g.TurnoverRatio:N1}** (volume > market cap in 24h): partecipazione altissima, " +
                "tipica della fase di scoperta/viralità.");
        if (g.BuyRatio > 0.55)
            Cat($"**Pressione d'acquisto {g.BuyRatio * 100:N0}%**: più compratori che venditori — domanda netta positiva.");
        if (g.PriceChg6h > 10 && g.PriceChg1h < 300)
            Cat($"**Trend in corso (+{g.PriceChg6h:N0}% in 6h)** senza segnali di esaurimento immediato.");
        if (g.AgeDays < 14)
            Cat($"**Token giovane ({g.AgeDays:N1} giorni)**: non ancora scoperto dal grande pubblico né dai listing " +
                "principali — l'eventuale listing CEX/aggregatori è un catalizzatore futuro.");
        if (g.LiqToMcap >= 0.05 && g.LiqToMcap <= 0.25)
            Cat($"**Liquidità sana ({g.LiqToMcap * 100:N1}% della mcap)**: si può entrare/uscire senza slippage " +
                "estremo, condizione necessaria perché i capitali più grandi possano entrare.");
        if (g.LpLockedPct >= 80)
            Cat($"**LP bloccata ({g.LpLockedPct:N0}%)**: rischio rug-pull ridotto, più fiducia per nuovi compratori.");
        if (g.HolderCount >= 1000)
            Cat($"**Community in crescita ({g.HolderCount:N0} holders)**: distribuzione che alimenta il passaparola.");
        if (g.CoinGeckoListed == true)
            Cat("**Già su CoinGecko**: visibilità sugli screener retail; il flusso da aggregatori è un acceleratore.");
        if (n2 == 0)
            Cat("Nessun catalizzatore forte rilevato al momento: la coin è in watch-list solo per i parametri early-stage.");
        sb.AppendLine();

        // ===================================================== Matematica del multiplo
        sb.AppendLine("## 5. La matematica del 100x");
        sb.AppendLine();
        if (g.MarketCapUsd > 0)
        {
            sb.AppendLine($"| Scenario | Market cap implicita | Riferimento |");
            sb.AppendLine($"|---|---|---|");
            sb.AppendLine($"| 10x | {M(g.MarketCapUsd * 10)} | meme di nicchia riuscita |");
            sb.AppendLine($"| 50x | {M(g.MarketCapUsd * 50)} | piccola meme virale |");
            sb.AppendLine($"| **100x** | **{M(g.MarketCapUsd * 100)}** | classe TURBO (~250M$ al picco) |");
            sb.AppendLine($"| 200x | {M(g.MarketCapUsd * 200)} | classe BONK (miliardi al picco) |");
            sb.AppendLine();
            sb.AppendLine($"Perché un 100x sia *fisicamente possibile*, la market cap implicita ({M(g.MarketCapUsd * 100)}) deve " +
                          "restare sotto i livelli raggiunti dalle meme di successo (TURBO ~250M$, BONK/PEPE in area miliardi). " +
                          $"Per questa coin il multiplo teorico verso la classe TURBO è **~{g.PotentialX:N0}x**.");
            sb.AppendLine();
            sb.AppendLine("Cosa servirebbe concretamente: crescita costante di holders e volume, liquidità in aumento " +
                          "(ora " + M(g.LiquidityUsd) + "), narrativa/meme virale, listing su CEX e aggregatori, " +
                          "assenza di unlock/mint che diluiscano i compratori.");
        }
        sb.AppendLine();

        // ===================================================== Rischi
        sb.AppendLine("## 6. Rischi e red flag");
        sb.AppendLine();
        sb.AppendLine($"- Flag rilevati dallo scanner: **{g.Risk}**");
        if (g.IsHoneypot == true) sb.AppendLine("- **HONEYPOT confermato: non acquistare.**");
        if (g.IsOpenSource == false) sb.AppendLine("- Contratto non verificato: codice non ispezionabile.");
        if (g.IsMintable == true) sb.AppendLine("- Supply mintabile: il deployer può diluire i possessori.");
        if (g.Top10HoldersPct >= 60) sb.AppendLine($"- Top10 holders al {g.Top10HoldersPct:N0}%: pochi wallet possono scaricare sul mercato.");
        if (g.LpLockedPct < 20 && g.LpLockedPct.HasValue) sb.AppendLine("- LP quasi non bloccata: rischio rug-pull elevato.");
        sb.AppendLine("- Rischio generale micro-cap: scam, rug pull, illiquidità, -90% in poche ore. " +
                      "Le probabilità di 100x sono basse per definizione: posizioni piccole, mai fondi necessari.");
        sb.AppendLine();
        sb.AppendLine("---");
        sb.AppendLine("*Documento generato automaticamente da FundingRateScan — strumento di ricerca probabilistico, " +
                      "non consulenza finanziaria. Verifica sempre contratto, liquidità e team prima di qualunque operazione.*");

        return sb.ToString();
    }

    private static string YN(bool? v, string yes, string no, string na)
        => v == true ? yes : v == false ? no : na;
}
