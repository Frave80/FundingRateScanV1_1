namespace FundingRateScan.Gems;

/// <summary>Fonti di scoperta dei candidati (feed DEX Screener).</summary>
[Flags]
public enum GemSource
{
    None = 0,
    TopBoosts = 1,      // token con più "boost" (attenzione/marketing attivo)
    LatestBoosts = 2,   // boost più recenti
    Profiles = 4,       // ultimi profili token pubblicati
    Search = 8          // ricerca testuale libera
}

/// <summary>Filtri di ricerca delle gemme.</summary>
public sealed class GemFilter
{
    public string Chain { get; set; } = "all";          // "all" o chainId DexScreener (ethereum, solana, base, bsc...)
    public double MaxMarketCapUsd { get; set; } = 5_000_000;   // early stage: sotto questa soglia
    public double MinLiquidityUsd { get; set; } = 20_000;
    public double MinVolume24hUsd { get; set; } = 50_000;
    public double MaxAgeDays { get; set; } = 30;
    public bool RequireBuyPressure { get; set; } = false;
    public GemSource Sources { get; set; } = GemSource.TopBoosts | GemSource.LatestBoosts | GemSource.Profiles;
    public string SearchQuery { get; set; } = "";
    public int MaxResults { get; set; } = 80;
}

/// <summary>Candidato "gemma" con metriche e scomposizione del punteggio.</summary>
public sealed class GemCandidate
{
    public string Chain { get; set; } = "";
    public string Symbol { get; set; } = "";
    public string Name { get; set; } = "";
    public string TokenAddress { get; set; } = "";
    public string PairAddress { get; set; } = "";
    public string Url { get; set; } = "";

    public double PriceUsd { get; set; }
    public double MarketCapUsd { get; set; }
    public double FdvUsd { get; set; }
    public double LiquidityUsd { get; set; }
    public double Volume24hUsd { get; set; }
    public double Volume1hUsd { get; set; }

    public int Buys24 { get; set; }
    public int Sells24 { get; set; }
    public double PriceChg5m { get; set; }
    public double PriceChg1h { get; set; }
    public double PriceChg6h { get; set; }
    public double PriceChg24h { get; set; }
    public double AgeHours { get; set; }

    // Metriche derivate
    public double TurnoverRatio => MarketCapUsd > 0 ? Volume24hUsd / MarketCapUsd : 0;     // volume/mcap
    public double VolumeAccel => Volume24hUsd > 0 ? (Volume1hUsd * 24.0) / Volume24hUsd : 0; // >1 = in accelerazione
    public double BuyRatio => (Buys24 + Sells24) > 0 ? (double)Buys24 / (Buys24 + Sells24) : 0;
    public double LiqToMcap => MarketCapUsd > 0 ? LiquidityUsd / MarketCapUsd : 0;
    public double AgeDays => AgeHours / 24.0;

    // Punteggio (0..100) e componenti (0..100)
    public double Score { get; set; }
    public double ScoreMomentum { get; set; }
    public double ScoreVolume { get; set; }
    public double ScoreBuy { get; set; }
    public double ScoreLiquidity { get; set; }
    public double ScoreEarly { get; set; }

    public string Risk { get; set; } = "";

    // ---- Arricchimento PRO: sicurezza contratto / holders -----------------
    public bool? IsHoneypot { get; set; }
    public double? BuyTaxPct { get; set; }
    public double? SellTaxPct { get; set; }
    public bool? IsOpenSource { get; set; }
    public bool? IsMintable { get; set; }
    public long? HolderCount { get; set; }
    public double? HolderGrowthPct { get; set; }   // crescita vs snapshot precedente (cap. 9.2)
    public double? Top10HoldersPct { get; set; }
    public double? LpLockedPct { get; set; }
    public bool? CoinGeckoListed { get; set; }
    public bool? PossibleSpam { get; set; }

    /// <summary>Punteggio sicurezza 0..100 (null = nessun dato disponibile).</summary>
    public double? SecurityScore { get; set; }
    public string SecuritySources { get; set; } = "";
    public List<string> SecurityNotes { get; set; } = new();

    // ---- Potenziale "moonshot" --------------------------------------------
    /// <summary>Punteggio finale 0..100 (mercato + sicurezza).</summary>
    public double MoonScore { get; set; }
    /// <summary>Multiplo teorico verso la capitalizzazione benchmark (TURBO-class ~250M$).</summary>
    public double PotentialX { get; set; }
    public string PotentialLabel { get; set; } = "";
}

/// <summary>Configurazione di un provider dati per la caccia gemme PRO (chiave abbinata).</summary>
public sealed class GemProviderConfig
{
    public string Name { get; set; } = "";
    public bool Enabled { get; set; } = true;
    public string ApiKey { get; set; } = "";
}

/// <summary>Impostazioni della caccia gemme PRO (persistite in settings.json).</summary>
public sealed class GemHunterSettings
{
    public List<GemProviderConfig> Providers { get; set; } = new();
    public int DeepSecurityTopN { get; set; } = 25;   // quante gemme arricchire con i controlli di sicurezza
}

/// <summary>Catalogo dei provider supportati dalla caccia gemme PRO.</summary>
public static class GemProviders
{
    public const string DexScreener = "DEX Screener";
    public const string GeckoTerminal = "GeckoTerminal";
    public const string GoPlus = "GoPlus Security";
    public const string Honeypot = "Honeypot.is";
    public const string Birdeye = "Birdeye";
    public const string Moralis = "Moralis";

    /// <summary>(nome, richiede chiave, descrizione) — l'ordine è quello mostrato nella form.</summary>
    public static readonly (string Name, bool RequiresKey, string Note)[] Catalog =
    {
        (DexScreener,   false, "Gratuito — scoperta token e dati DEX in tempo reale (sempre attivo)"),
        (GeckoTerminal, false, "Gratuito — verifica market cap/FDV e presenza su CoinGecko"),
        (GoPlus,        false, "Gratuito — sicurezza contratto: honeypot, tasse, mint, holders (chiave opzionale)"),
        (Honeypot,      false, "Gratuito — test honeypot ETH/BSC/Base (fallback, nessuna chiave)"),
        (Birdeye,       true,  "API key — dati avanzati Solana: numero holders, overview token"),
        (Moralis,       true,  "API key — metadata EVM: contratto verificato, segnalazione spam"),
    };
}

public sealed class GemResult
{
    public List<GemCandidate> Gems { get; set; } = new();
    public int Scanned { get; set; }
    public int Discarded { get; set; }
}
