# Debug — Verdetto coin (checklist da eseguire alla fine)

Checklist di verifica della funzionalità "verdetto buona/squeeze/trappola". Spuntare ogni voce e annotare
l'esito in `avanzamento.md`.

## D1 — Compilazione
- [ ] `dotnet build src/FundingRateScan.csproj` → 0 warning / 0 errori.

## D2 — Logica del verdetto (casi limite)
- [ ] **Trappola**: funding ≥ 150% APR → verdetto Trappola con motivazione "reversal/liquidazione a cascata".
- [ ] **Trappola + cascata**: funding estremo **e** ΔOI ≥ 25% → motivazione esplicita OI concorde.
- [ ] **Trappola + liquidità**: funding estremo con volume 24h < 2× minimo → motivazione manipolabilità + fonte [7].
- [ ] **Buona**: funding moderato (≥ soglia, < 150%), persistente, ΔVolume e ΔOI sopra soglia, liquidità ok.
- [ ] **Squeeze probabile**: persistente + ΔOI in crescita + funding elevato (≥ max(30, 2× soglia)) ma non estremo.
- [ ] **Incerta**: coin solo-Colab (Enriched=false) oppure segnali parziali.
- [ ] Cambiando gli **indicatori regolabili** (soglie funding/persistenza/Δvol/ΔOI) il verdetto si ricalcola
      coerentemente al ricarico della tabella (Applica filtro).

## D3 — Finestra Dettagli
- [ ] Il banner del verdetto compare sopra le motivazioni con il colore corretto (verde/arancio/rosso/grigio).
- [ ] Il blocco VERDETTO in cima alle MOTIVAZIONI riporta esplosività breve/lungo, motivazioni e fonti.
- [ ] La sezione "MOTIVAZIONI (volatilità)" e la NOTA/disclaimer restano presenti e leggibili.
- [ ] Tutti i campi sono visibili (nessun testo tagliato dalle schede/altri controlli).

## D4 — Tabella principale
- [ ] La colonna "Giudizio" compare dopo "Stato", leggibile, con badge colorato.
- [ ] Il tooltip della cella "Giudizio" mostra la prima motivazione.
- [ ] Le righe solo-Colab mostrano un verdetto coerente (Incerta o Trappola se funding estremo).
- [ ] L'export CSV include la colonna "Giudizio" col valore corretto.

## D5 — Regressione
- [ ] La classificazione di funding (Pattern attivo / Da osservare / Neutra) è invariata.
- [ ] Le altre finestre e l'apertura a pieno schermo continuano a funzionare.

## D6 — Documentazione
- [ ] Il nuovo `.docx` dedicato si apre correttamente (XML ben formato, accenti/«»/— corretti).
- [ ] `modifica.md`, `task.md`, `avanzamento.md` aggiornati.
